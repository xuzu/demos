# Api-test 文件夹

保存常用测试Api接口的http文件

## 使用方法
首先确保项目启动成功

如果使用intellij idea编辑器，可以直接点击绿色三角图标执行网络请求