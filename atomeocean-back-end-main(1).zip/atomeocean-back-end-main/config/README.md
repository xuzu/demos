# Config repo
Save the configuration

## Purpose
- application.yml - This is the main configuration file. This is the default profile that runs when no other profile is active. It might contain default configurations for your application. The default is now set to application-remote.yml so that the project can run without configuring any local databases.
- application-local.yml - This file typically contains configurations that are specific to a local development environment. For example, this might include connection details for a local database or local API URLs.
- application-test.yml - This file typically contains configurations that are specific to a testing environment. This might include connection details for a testing database, testing API URLs, or settings related to test execution.
- application-docker.yml - This file is typically used when your application is running inside a Docker container. This might include settings that are specific to the Docker environment, such as specific network settings, container settings, etc.
- application-remote.yml - This file is typically used for settings that are specific to a remote or production environment. This might include connection details for a production database, real API URLs, etc.