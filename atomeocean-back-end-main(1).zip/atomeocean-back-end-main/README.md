# Foo backend
Foo 后端代码

[![release information](https://img.shields.io/badge/release_version-2.0.0-blue)](https://github.com/foo-tech/foo-back-end)

## 配置项目

在根目录，复制config-example文件夹到同级目录，并将其重命名为config，这样文件夹中的`application.yml`会选取`application-local.yml`文件中的配置，保证本地front-end和back-end可以顺利连接。

## 如何在本地运行后端程序

### 1. 安装Java11，安装并运行MongoDB

### 2. 使用Maven启动程序
```
mvn spring-boot:run
```
### 3. 访问本地8080端口查看程序是否启动成功 
可以在该文件中测试`Api-test/health-check.http`，也可以直接在浏览器中发起请求
```
(推荐postman)
http://localhost:8080/actuator/health
```
返回内容为
```json
{
    "status": 100,
    "message": "操作成功",
    "data": {
        "status": "UP",
        "components": {
            "diskSpace": {
                "status": "UP",
                "details": {
                    "total": 494384795648,
                    "free": 13483982848,
                    "threshold": 10485760,
                    "exists": true
                }
            },
            "mongo": {
                "status": "UP",
                "details": {
                    "version": "6.0.0"
                }
            },
            "ping": {
                "status": "UP"
            }
        }
    },
    "timestamp": 1234567890
}
```

### 4.运行测试
```
mvn clean test
```
pom.xml内配置的`jacoco`插件在测试运行完毕后会自动生成html格式的覆盖率报告，报告的位置在`target/site/jacoco/index.html`。


## TroubleShooting
- 启动失败，报错例如
```text
o.s.w.c.s.GenericWebApplicationContext   : Exception encountered during context initialization - cancelling refresh attempt: org.springframework.beans.factory.BeanCreationException: Error creating bean with name 'securityConfig': Injection of autowired dependencies failed; nested exception is java.lang.IllegalArgumentException: Could not resolve placeholder 'spring.secure.allowed.urls.frontEnd' in value "${spring.secure.allowed.urls.frontEnd}"
```
**解决办法**
检查根目录的config文件夹，可能没有重命名`config-example` --> `config`导致项目没有找到配置文件


## 备注


```
文件结构参考
|_annotation：放置项目自定义注解
|_aspect：放置切面代码
|_config：放置配置类
|_constant：放置常量、枚举等定义
    |__consist：存放常量定义
    |__enums：存放枚举定义
|_controller：放置控制器代码
|_filter：放置一些过滤、拦截相关的代码
|_mapper：放置数据访问层代码接口
|_model：放置数据模型代码
    |__entity：放置数据库实体对象定义
    |__dto：存放数据传输对象定义
    |__vo：存放显示层对象定义
|_service：放置具体的业务逻辑代码（接口和实现分离）
    |__intf：存放业务逻辑接口定义
    |__impl：存放业务逻辑实际实现
|_utils：放置工具类和辅助代码
```
