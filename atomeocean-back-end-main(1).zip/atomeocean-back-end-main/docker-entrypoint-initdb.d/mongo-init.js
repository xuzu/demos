print('>--- Start setting up mongodb');

db = db.getSiblingDB("fooffer")

db.createCollection('userRoles', { capped: false })
db.createCollection('dynamicRoutes', { capped: false })


// 添加用户身份
db.userRoles.insert({
    roleId: 100,
    roleName: "ROLE_MEMBER",
    dynamicRouteIds:[1,2]
});

// 添加动态路由表
db.dynamicRoutes.insert([{
    dynamicRouteId: 1,
    path: "/editor",
    name: "editor",
},{
    dynamicRouteId: 2,
    path: "/about",
    name: "about",
}])

print('END setting up mongodb ---<');