## resources 文件结构

|_mapper：存放mybatis的XML映射文件（如果是mybatis项目）
|_static：存放网页静态资源，比如下面的js/css/img
    |__js：
    |__css：
    |__img：
    |__font：
    |__等等
|_template：存放网页模板，比如thymeleaf/freemarker模板等
    |__header
    |__sidebar
    |__bottom
    |__XXX.html等等
|_application.yml       基本配置文件
|_application-dev.yml   开发环境配置文件
|_application-test.yml  测试环境配置文件
|_application-prod.yml  生产环境配置文件