package com.fooffer.fooBackEnd.handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fooffer.fooBackEnd.constant.ReturnCode;
import com.fooffer.fooBackEnd.model.ResultData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AccountExpiredException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 处理登录失败的反馈
 */
@Component
@Slf4j
public class CustomAuthenticationFailureHandler implements AuthenticationFailureHandler {

    @Override
    public void onAuthenticationFailure(
            HttpServletRequest request,
            HttpServletResponse response,
            AuthenticationException exception
    ) throws IOException, ServletException {
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType("text/json;charset=utf-8");
        ResultData<Object> resultJson = null;
        String errorMessage = exception.getMessage();
        // 遍历多个自带的错误原因
        if (exception instanceof BadCredentialsException) {
            if (errorMessage.equals("密码错误")) {
                resultJson = new ResultData<>(ReturnCode.INVALID_PASSWORD);
            }
            else if (errorMessage.equals("用户不存在")) {
                resultJson = new ResultData<>(ReturnCode.INVALID_EMAIL);
            }
            else {
                resultJson = new ResultData<>(ReturnCode.CLIENT_AUTHENTICATION_FAILED);
            }
        }
        else {
            resultJson = new ResultData<>(ReturnCode.CLIENT_AUTHENTICATION_FAILED);
        }
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.writeValue(response.getWriter(), resultJson);
    }
}