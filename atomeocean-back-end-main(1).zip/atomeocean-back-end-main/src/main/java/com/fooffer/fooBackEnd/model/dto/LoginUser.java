package com.fooffer.fooBackEnd.model.dto;

import lombok.Data;

/**
 * 保存已登录用户的信息
 */
@Data
public class LoginUser {
    private String userEmail;
    private String password;
    private Integer rememberMe;

}
