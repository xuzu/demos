package com.fooffer.fooBackEnd.service.impl;

import com.fooffer.fooBackEnd.constant.ErrorReason;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.exception.cause.ExceptionCause;
import com.fooffer.fooBackEnd.mapper.UserMapper;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.dto.UserDto;
import com.fooffer.fooBackEnd.model.entity.UserDao;
import com.fooffer.fooBackEnd.model.vo.UserVo;
import com.fooffer.fooBackEnd.repository.EmailAuthRepository;
import com.fooffer.fooBackEnd.repository.UserRepository;
import com.fooffer.fooBackEnd.security.JwtUserDetails;
import com.fooffer.fooBackEnd.service.intf.UserAuthenticationService;
import com.fooffer.fooBackEnd.utils.EmailSenderUtil;
import com.fooffer.fooBackEnd.utils.RedisUtil;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import static com.fooffer.fooBackEnd.constant.ReturnCode.CODE_EXPIRED;

@Service
@AllArgsConstructor
@Slf4j
public class UserAuthServiceImpl implements UserAuthenticationService {

    private final UserRepository userRepository;

    private final EmailAuthRepository emailAuthRepository;

    private final UserMapper userMapper;

    private final BCryptPasswordEncoder bCryptPasswordEncoder;
    /**
     * 根据用户邮箱返回UserVo
     * @param userEmail userEmail用户邮箱
     * @return 用户名对应的user Vo
     */
    @Override
    public UserVo getUserVoByUserEmail(String userEmail) {
        UserDao userDao = userRepository.findUserDaoByUserEmail(userEmail);

        UserDto userDto = userMapper.dao2dto(userDao);

        UserVo userVo = userMapper.dto2vo(userDto);

        return userVo;
    }

    /**
     * 登录过程根据用户邮箱获取用户信息
     * @param userId 用户身份认证信息
     * @return UserDetails object
     */
    @Override
    public JwtUserDetails loadUserDetailsByUserId(Long userId) {

        UserDao userDao;
        try{
            userDao = userRepository.findUserDaoByUserId(userId);
        }
        catch(Exception e){ //用户不存在
            log.error("user not found");
            //UsernameNotFoundException会被springboot默认隐藏。
            throw new BadCredentialsException("用户不存在");
        }

        return new JwtUserDetails(userDao);
    }

    /**
     * 重新发送验证码
     * @param email 用户邮箱
     * @return ResultData
     */
    @Override
    public ResultData resendCode(String email) throws BaseException {
        //缓存中查找当前邮箱对应的验证码
        String code = (String) RedisUtil.get(email);
        //邮箱信息过期或不正确，抛出异常
        if (!StringUtils.hasLength(code)) {
            ExceptionCause exceptionCause = new ExceptionCause("verify", ErrorReason.CODE_EXPIRED);
            throw new BaseException(CODE_EXPIRED, exceptionCause);
        }
        //发送邮件，返回提示
        EmailSenderUtil.sendVerificationEmail(email, code, "verification");
        return ResultData.success("验证邮件已发送到您的邮箱，请验证您的账号，验证邮件有效期为15分钟");
    }

}
