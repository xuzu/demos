package com.fooffer.fooBackEnd.mapper;


import com.fooffer.fooBackEnd.model.dto.EducationDto;
import com.fooffer.fooBackEnd.model.entity.EducationDao;
import com.fooffer.fooBackEnd.model.vo.EducationVo;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * Education vo, dto, dao 映射
 */
@Mapper(componentModel = "spring")
public interface EducationMapper {

    EducationDto vo2dto(EducationVo educationVo);

    EducationVo dto2vo(EducationDto educationDto);

    EducationDao dto2dao(EducationDto educationDto);

    EducationDto dao2dto(EducationDao educationDao);
}
