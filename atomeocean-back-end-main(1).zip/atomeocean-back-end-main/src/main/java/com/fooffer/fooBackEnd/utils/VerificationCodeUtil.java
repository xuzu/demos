package com.fooffer.fooBackEnd.utils;

import com.fooffer.fooBackEnd.constant.ErrorReason;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.exception.cause.ExceptionCause;
import com.fooffer.fooBackEnd.model.vo.EmailAuthVo;
import java.util.concurrent.TimeUnit;
import static com.fooffer.fooBackEnd.constant.ReturnCode.*;


//验证码相关的utils
public class VerificationCodeUtil {

    //生成验证码存入redis并发送邮件
    public static void sendVerificationCodeEmail(EmailAuthVo emailAuthVo, Integer time, TimeUnit timeUnit, String template){
        //生成验证码
        String code = CaptchaGenerator.generateValidateCode();

        //存入Redis
        RedisUtil.set(emailAuthVo.getUserEmail(), code, time, timeUnit);
        RedisUtil.set(emailAuthVo.getUserEmail() + " " + code, emailAuthVo, time, timeUnit);

        //发送email
        EmailSenderUtil.sendVerificationEmail(emailAuthVo.getUserEmail(), code, template);
    }



    //根据redis中的email和code信息检查验证码是否正确
    public static EmailAuthVo verifyCode(String email, String code, String domain){

        //保证验证码中字母全部为大写字母
        code = code.toUpperCase();

        //查看验证码是否在缓存中，如果不在提示验证码已过期
        String cacheCode = (String) RedisUtil.get(email);
        if(cacheCode == null){
            ExceptionCause exceptionCause = new ExceptionCause(domain, ErrorReason.CODE_EXPIRED);
            throw new BaseException(CODE_EXPIRED, exceptionCause);
        }

        //查看验证码是否正确
        if(!code.equals(cacheCode)){
            ExceptionCause exceptionCause = new ExceptionCause(domain, ErrorReason.INVALID_CODE);
            throw new BaseException(INVALID_CODE, exceptionCause);
        }

        EmailAuthVo emailAuthVo = (EmailAuthVo) RedisUtil.get(email + " " + cacheCode);
        //防止极小概率Redis中验证码通过后，保存的注册信息过期导致NullPointerException
        if(emailAuthVo == null){
            ExceptionCause exceptionCause = new ExceptionCause("sign up", ErrorReason.REGISTRATION_EXPIRED);
            throw new BaseException(REGISTRATION_EXPIRED, exceptionCause);
        }

        //删除用户注册信息，避免重复验证
        RedisUtil.delete(email);
        RedisUtil.delete(email + " " + cacheCode);
        return emailAuthVo;
    }
}
