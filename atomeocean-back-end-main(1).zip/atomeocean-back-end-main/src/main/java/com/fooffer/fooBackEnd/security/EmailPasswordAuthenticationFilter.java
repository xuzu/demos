package com.fooffer.fooBackEnd.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fooffer.fooBackEnd.model.vo.EmailPasswordLoginVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Slf4j
public class EmailPasswordAuthenticationFilter extends
        AbstractAuthenticationProcessingFilter {

    private static final String EMAIL_KEY = "userEmail";
    private static final String PASSWORD_KEY = "password";

    // request中的参数
    private String emailParameter = EMAIL_KEY;
    private String passwordParameter = PASSWORD_KEY;

    private final AuthenticationManager authenticationManager;

    private static final AntPathRequestMatcher EMAIL_ANT_PATH_REQUEST_MATCHER = new AntPathRequestMatcher(
            "/auth/emailLogin",
            "POST"
    );

    public EmailPasswordAuthenticationFilter(
            AuthenticationManager authenticationManager
    ) {
        super(
                EMAIL_ANT_PATH_REQUEST_MATCHER,
                authenticationManager
        );
        this.authenticationManager = authenticationManager;
    }

    /**
     * Filter获得邮箱和密码，封装进token
     * @param request
     * @param response
     * @return 返回封装的authentication token
     * @throws AuthenticationException
     * @throws IOException
     * @throws ServletException
     */
    @Override
    public Authentication attemptAuthentication(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws AuthenticationException, IOException, ServletException {

        try {
            EmailPasswordLoginVo emailPasswordLoginVo = new ObjectMapper().readValue(request.getInputStream(), EmailPasswordLoginVo.class);
            String userEmail = emailPasswordLoginVo.getUserEmail();
            String password = emailPasswordLoginVo.getPassword();

            log.info("Email login filter -- email = {}, password = {}", userEmail, password);

            // 传给 authentication manager验证
            return authenticationManager.authenticate(
                    new EmailPasswordAuthenticationToken(
                            userEmail,
                            password
                    )
            );
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
