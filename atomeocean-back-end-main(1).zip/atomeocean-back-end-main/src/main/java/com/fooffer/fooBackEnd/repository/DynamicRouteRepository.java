package com.fooffer.fooBackEnd.repository;

import com.fooffer.fooBackEnd.model.entity.DynamicRouteDao;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

/**
 * 从DB中读取动态路由数据
 */
@Repository
public interface DynamicRouteRepository extends MongoRepository<DynamicRouteDao, Long> {

    // 根据id读取到对应的动态路由
    DynamicRouteDao findDynamicRouteDaoByDynamicRouteId(Integer dynamicRouteId);
}
