package com.fooffer.fooBackEnd.model.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * 存放文章分类
 */
@Data
@Document(collection = "articleCategories")
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ArticleCategoryDao {
    @Id
    private ObjectId _id;

    private Long articleCategoryId;

    /**
     * 分类名称
     */
    private String name;
}
