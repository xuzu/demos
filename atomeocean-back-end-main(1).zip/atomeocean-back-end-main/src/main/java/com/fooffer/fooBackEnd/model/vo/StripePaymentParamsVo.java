package com.fooffer.fooBackEnd.model.vo;

import com.fooffer.fooBackEnd.constant.stripe.Currency;
import lombok.Data;

import javax.validation.constraints.Min;

@Data
public class StripePaymentParamsVo {
    //金额最少为50cents
    @Min(50)
    private Integer amount;

    private Currency currency;

    private String stripeToken;
}
