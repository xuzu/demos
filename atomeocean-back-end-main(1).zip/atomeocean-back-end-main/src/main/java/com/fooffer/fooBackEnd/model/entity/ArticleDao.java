package com.fooffer.fooBackEnd.model.entity;


import com.fooffer.fooBackEnd.constant.articles.ArticleVisibility;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.List;


/**
 * 这里存放的是文章，在mongo里面是articles collection
 *
 * 对应article
 *
 * 文章内容长文本放在 Article Content中
 */
@Data
@Document(collection = "articles")
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ArticleDao {

    @Id
    private ObjectId _id;

    // 逻辑主键，需要雪花Id生成
    //    @Field("articleId")
    @Indexed
    private Long articleId;

    /**
     * Key of title.
     */
    private String title;

    /**
     * 对应users collection -> userId
     */
    private Long authorId;

    /**
     * 保存作者的用户名
     */
    private String authorName;

    /**
     * Key of article abstract.
     * 在仅展示文章前一小段话时使用
     */
    private String collapsedContent;

    /**
     * 文章全文的id
     */
    private Long contentId;

    /**
     * 文章创建的时间
     */
    private LocalDateTime createTime;

    /**
     * 文章最近一次更新时间
     */
    private LocalDateTime latestUpdateTime;

    /**
     * 总浏览次数
     */
    private Integer viewCount = 0;

    /**
     * 词数统计信息
     */
    private Integer wordCount;

    /**
     * 是否已经删除
     */
    private Boolean isDeleted = false;

    /**
     * 所属分类的名字
     */
    private String categoryName;

    /**
     * 文章可阅读的权限
     */
    private ArticleVisibility visibility;

    /**
     * 文章tags id list
     */
    private List<ArticleTagDao> articleTagList;

    /**
     * 文章封面图的链接
     */
    private String articleCoverImageLink;

    @Override
    public String toString() {
        return "Article { title= " + title
                + ", collapsedContent= "+ collapsedContent;
    }
}
