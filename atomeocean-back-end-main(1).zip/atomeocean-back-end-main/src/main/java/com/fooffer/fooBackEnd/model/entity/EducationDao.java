package com.fooffer.fooBackEnd.model.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;



/**
 * 对应数据库中的education collection
 * 保存用户的教育经历信息，每个education对应一段经历
 */
@Data
@Document(collection = "education")
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EducationDao {
    @Id
    private ObjectId _id;

    //逻辑主键
    @Indexed
    private Long educationId;

    //本段教育经历所对应用户的userId
    private Long userId;

    //学校名
    private String institutionName;

    /**学位名
     * 0：high school
     * 1：bachelor
     * 2：master
     * 3：doctor
     * 4：postdoc
     */
    private Integer degreeLevel;
    
    //专业名
    private String major;

    //开始日期
    private LocalDate startDate;    

    //结束日期
    private LocalDate endDate;
    
    //是否已经完成，如果是false那么前端显示结束日期为“至今”
    private Boolean isCompleted;
}
