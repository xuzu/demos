package com.fooffer.fooBackEnd.utils;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;

public class TimeConvertUtil {

    /**
     * 将unix epoch second转为对应的localDateTime
     * unix epoch起始时间为1970/01/01 00:00:00 UTC
     * @param epochTime epoch开始的秒数
     */
    public static LocalDateTime epochSecond2LocalDateTime(Long epochTime){
        return Instant.ofEpochSecond(epochTime)
                .atZone(ZoneId.of("UTC"))
                .toLocalDateTime();
    }
}
