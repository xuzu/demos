package com.fooffer.fooBackEnd.service.intf;

import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.vo.UserVo;
import com.fooffer.fooBackEnd.security.JwtUserDetails;
import org.springframework.stereotype.Service;
import org.springframework.security.core.Authentication;

/**
 * 处理User Dao相关逻辑
 */
@Service
public interface UserAuthenticationService {

    UserVo getUserVoByUserEmail(String userEmail);

    /**
     * 根据邮箱读取用户的UserDetails信息
     * @param userId userDao中的userId
     * @return 用户的UserDetails信息
     */
    JwtUserDetails loadUserDetailsByUserId(Long userId);

    ResultData resendCode(String email) throws BaseException;
}
