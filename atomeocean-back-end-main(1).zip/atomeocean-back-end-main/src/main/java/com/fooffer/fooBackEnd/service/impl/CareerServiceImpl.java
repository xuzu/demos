package com.fooffer.fooBackEnd.service.impl;

import com.fooffer.fooBackEnd.constant.ErrorReason;
import com.fooffer.fooBackEnd.constant.ResourceOperationType;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.exception.cause.ExceptionCause;
import com.fooffer.fooBackEnd.mapper.CareerMapper;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.dto.CareerDto;
import com.fooffer.fooBackEnd.model.entity.CareerDao;
import com.fooffer.fooBackEnd.model.entity.UserInformationDao;
import com.fooffer.fooBackEnd.model.vo.CareerVo;
import com.fooffer.fooBackEnd.repository.CareerRepository;
import com.fooffer.fooBackEnd.repository.UserInformationRepository;
import com.fooffer.fooBackEnd.service.intf.CareerService;
import com.fooffer.fooBackEnd.service.intf.UserInformationService;
import com.fooffer.fooBackEnd.utils.SnowflakeIdWorker;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;

import static com.fooffer.fooBackEnd.constant.ReturnCode.*;

@Service
@Slf4j
@AllArgsConstructor
public class CareerServiceImpl implements CareerService {

    private final CareerRepository careerRepository;
    private final UserInformationRepository userInformationRepository;
    private final CareerMapper careerMapper;
    private final SnowflakeIdWorker snowflakeIdWorker = new SnowflakeIdWorker(7L, 6L);
    private final UserInformationService userInformationService;

    /**
     * 检查用户输入的工作经历信息，如果符合要求则创建新的工作经历并存入数据库
     */
    @Override
    public ResultData createCareer(CareerVo careerVo) throws BaseException{
        Long userId = (Long) SecurityContextHolder.getContext().getAuthentication().getDetails();
        Long careerId = careerVo.getCareerId();
        UserInformationDao userInformationDao = userInformationService.getUserInformationDaoByUserId(userId);

        //用户已经输入了工作经历id
        if (careerId != null){
            ExceptionCause exceptionCause = new ExceptionCause("career", ErrorReason.BAD_REQUEST);
            throw new BaseException(CAREER_EXIST, exceptionCause);
        }

        //为新工作经历生成独特的careerId
        CareerDto careerDto = careerMapper.vo2dto(careerVo);
        careerDto.setUserId(userId);
        CareerDao careerDao = careerMapper.dto2dao(careerDto);
        careerId= snowflakeIdWorker.nextId();
        careerDao.setCareerId(careerId);

        //保存至数据库
        careerRepository.save(careerDao);

        //用户信息里的careerId set添加新的careerId
        Set<Long> careerIdSet = userInformationDao.getCareerIdSet();
        if(careerIdSet == null)
            careerIdSet = new HashSet<>();
        careerIdSet.add(careerId);
        userInformationDao.setCareerIdSet(careerIdSet);
        userInformationRepository.save(userInformationDao);

        //操作成功返回生成的careerId
        return ResultData.success(careerId);
    };



    /**
     * 检查用户输入的工作经历信息，如果符合要求则修改对应的工作经历(修改内容或删除)
     * operationType patch：修改内容
     * operationType delete：删除经历
     */
    @Override
    public ResultData modifyCareer(CareerVo careerVo, ResourceOperationType operationType) throws BaseException{
        Long userId = (Long) SecurityContextHolder.getContext().getAuthentication().getDetails();
        Long careerId = careerVo.getCareerId();
        UserInformationDao userInformationDao = userInformationService.getUserInformationDaoByUserId(userId);
        
        CareerDao old_careerDao = careerRepository.findCareerDaoByCareerId(careerId).orElseThrow(
                () -> new BaseException(
                        CAREER_NOT_EXIST,
                        ExceptionCause.builder()
                                .domain("career")
                                .errorReason(ErrorReason.BAD_REQUEST)
                                .build()
                )
        );

        //如果userId和用户提交的工作经历里记录的userId不同，抛出异常（用户试图修改属于其他人的工作经历）
        if (!old_careerDao.getUserId().equals(userId)){
            ExceptionCause exceptionCause = new ExceptionCause("career", ErrorReason.BAD_REQUEST);
            throw new BaseException(ACCESS_DENIED, exceptionCause);
        }

        switch (operationType) {
            // 修改工作经历
            case Patch:
                CareerDto careerDto = careerMapper.vo2dto(careerVo);
                careerDto.setUserId(userId);
                CareerDao new_careerDao = careerMapper.dto2dao(careerDto);
                new_careerDao.set_id(old_careerDao.get_id());

                //保存新工作信息至数据库
                careerRepository.save(new_careerDao);

                return ResultData.success("工作经历修改成功！");
            // 删除工作经历
            case Delete:

                //删除数据库中的工作信息
                careerRepository.delete(old_careerDao);
                
                //修改用户信息里的careerId set
                Set<Long> careerIdSet = userInformationDao.getCareerIdSet();
                careerIdSet.remove(careerId);
                userInformationDao.setCareerIdSet(careerIdSet);
                userInformationRepository.save(userInformationDao);

                return ResultData.success("工作经历删除成功！");

            // 否则operationType错误，抛出错误(创建career需要用createCareer)
            default:
                ExceptionCause exceptionCause = new ExceptionCause("career", ErrorReason.BAD_REQUEST);
                throw new BaseException(CAREER_EXIST, exceptionCause);
        } 
    };

}
