package com.fooffer.fooBackEnd.config;


import com.fooffer.fooBackEnd.filter.RecaptchaFilter;
import com.fooffer.fooBackEnd.handler.CustomAuthenticationFailureHandler;
import com.fooffer.fooBackEnd.handler.CustomAuthenticationSuccessHandler;
import com.fooffer.fooBackEnd.handler.CustomLogoutSuccessHandler;
import com.fooffer.fooBackEnd.security.EmailPasswordAuthenticationFilter;
import com.fooffer.fooBackEnd.security.EmailPasswordAuthenticationProvider;
import com.fooffer.fooBackEnd.security.EmailPasswordAuthorizationFilter;
import com.fooffer.fooBackEnd.service.intf.RecaptchaService;
import com.google.common.collect.ImmutableList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.logout.LogoutFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import javax.annotation.Resource;
import java.util.Arrays;


/**
 * Spring-security配置
 */
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

    @Autowired
    // 设置注入的实现类
    @Qualifier("userDetailsServiceImpl")
    private UserDetailsService userDetailsService;

    @Autowired
    @Qualifier("recaptchaServiceImpl")
    private RecaptchaService recaptchaService;

    @Autowired
    private RecaptchaFilterPaths recaptchaFilterPaths;

    @Autowired
    private EmailPasswordAuthenticationProvider emailPasswordAuthenticationProvider;

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userDetailsService);
        authProvider.setPasswordEncoder(bCryptPasswordEncoder);
        return authProvider;
    }

    @Bean
    public AuthenticationManager authenticationManager() throws Exception {
        return new ProviderManager(
                Arrays.asList(
                        authenticationProvider(),
                        emailPasswordAuthenticationProvider
                )
        );
    }

    @Resource
    private final CustomAuthenticationSuccessHandler successHandler;

    @Resource
    private final CustomAuthenticationFailureHandler failureHandler;

    private final CustomLogoutSuccessHandler logoutSuccessHandler;

    @Value("${spring.secure.allowed.urls.frontEnd}")
    private String allowedUrl;

    public SecurityConfig(
            CustomAuthenticationSuccessHandler successHandler,
            CustomAuthenticationFailureHandler failureHandler,
            CustomLogoutSuccessHandler logoutSuccessHandler
    ){
        this.successHandler = successHandler;
        this.failureHandler = failureHandler;
        this.logoutSuccessHandler = logoutSuccessHandler;
    }

    @Bean
    public EmailPasswordAuthenticationFilter emailPasswordAuthenticationFilter() throws Exception {
        EmailPasswordAuthenticationFilter emailPasswordAuthenticationFilter = new EmailPasswordAuthenticationFilter(authenticationManager());

        emailPasswordAuthenticationFilter.setAuthenticationSuccessHandler(successHandler);
        emailPasswordAuthenticationFilter.setAuthenticationFailureHandler(failureHandler);

        return emailPasswordAuthenticationFilter;
    }


    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        http.cors().configurationSource(corsConfigurationSource())

                // 退出登录
                .and()
                .logout()
                .logoutUrl("/auth/logout")
                .logoutSuccessHandler(logoutSuccessHandler) // 登出处理器

                // 关闭csrf认证
                .and().csrf().disable()
                .authorizeRequests()
                // 测试用资源，需要验证了的用户才能访问
                .antMatchers("/tasks/**").authenticated()
                // 需要角色为ADMIN才能删除该资源
                .antMatchers(HttpMethod.DELETE, "/tasks/**").hasAuthority("ROLE_ADMIN")
                .antMatchers("/staff/**").hasAuthority("ROLE_MANAGER")
                // 放行其他资源
                .anyRequest().permitAll()
                // 添加Email-Password验证
                .and()
                //添加recaptcha filter
                .addFilterBefore(
                        new RecaptchaFilter(recaptchaService, recaptchaFilterPaths)
                        , UsernamePasswordAuthenticationFilter.class
                )
                .authenticationProvider(emailPasswordAuthenticationProvider)
                .addFilterBefore(
                        emailPasswordAuthenticationFilter(),
                        EmailPasswordAuthorizationFilter.class
                )
                .addFilter(new EmailPasswordAuthorizationFilter(authenticationManager()))

                // 不需要session
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
        return http.build();
    }

    @Bean
    CorsConfigurationSource corsConfigurationSource() {
        final CorsConfiguration corsConfiguration = new CorsConfiguration();
        corsConfiguration.setAllowedOrigins(ImmutableList.of(allowedUrl));
        corsConfiguration.setAllowedMethods(
                ImmutableList.of("HEAD", "GET", "POST", "PUT", "DELETE", "PATCH")
        );
        // important
        corsConfiguration.setAllowCredentials(true);
        corsConfiguration.setAllowedHeaders(ImmutableList.of("Authorization", "Cache-Control", "Content-Type", "Recaptcha"));
        final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", corsConfiguration);
        return source;
    }
}

