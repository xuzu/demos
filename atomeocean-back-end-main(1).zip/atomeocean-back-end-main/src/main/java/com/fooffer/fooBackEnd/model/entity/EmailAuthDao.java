package com.fooffer.fooBackEnd.model.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * 对应使用邮箱注册方式的用户
 */
@Data
@Document(collection = "emailAuthUser")
@AllArgsConstructor
@NoArgsConstructor
public class EmailAuthDao {

    @Id
    private ObjectId _id;

    /**
     * 逻辑主键
     */
    private Long emailAuthId;

    /**
     * 用户邮箱
     */
    @Indexed(unique = true)
    private String userEmail;

    /**
     * 用户密码
     */
    private String password;

    /**
     * 对应UserDao id
     */
    private Long userId;
}
