package com.fooffer.fooBackEnd.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.fooffer.fooBackEnd.model.entity.EducationDao;


@Repository
public interface EducationRepository extends MongoRepository<EducationDao, Long> {

    // 通过EducationId获取教育经历信息
    Optional<EducationDao> findEducationDaoByEducationId(Long educationId);
}
