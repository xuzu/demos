package com.fooffer.fooBackEnd.constant;

public enum ResourceOperationType {
    Post,
    Patch,
    Delete
}
