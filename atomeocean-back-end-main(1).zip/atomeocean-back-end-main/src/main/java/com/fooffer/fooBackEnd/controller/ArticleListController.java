package com.fooffer.fooBackEnd.controller;

import com.fooffer.fooBackEnd.model.vo.ArticleListRequestParams;
import com.fooffer.fooBackEnd.model.vo.ArticleResponseVo;
import com.fooffer.fooBackEnd.model.vo.articleList.ArticleListResponseVo;
import com.fooffer.fooBackEnd.service.intf.ArticleListService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

/**
 * 构建前端的article文章列表并返回json
 */
@RestController
@AllArgsConstructor
@RequestMapping("/articles")
@Slf4j
public class ArticleListController {

    private final ArticleListService articleListService;

    /**
     * 读取符合要求的所有的文章
     * @param articleListRequestParams 封装请求参数
     * @param paginationToken 包含分页相关的信息
     * @return 返回文章列表
     */
    @GetMapping("")
    public ArticleListResponseVo getArticleList(
          ArticleListRequestParams articleListRequestParams,
          @RequestParam("paginationToken") Optional<String> paginationToken
    ) {

        // todo: convert pagination token to page number & size

        List<ArticleResponseVo> articleList = articleListService.getArticleResponseVoList(articleListRequestParams);


        ArticleListResponseVo articleListResponseVo = ArticleListResponseVo.builder()
                .articleList(articleList)
                .build();

        // todo: 更新paginationToken
        articleListResponseVo.setPaginationToken("updated-pagination-token");

        return articleListResponseVo;
    }
}
