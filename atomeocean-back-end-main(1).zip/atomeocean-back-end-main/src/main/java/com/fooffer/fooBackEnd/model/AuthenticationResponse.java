package com.fooffer.fooBackEnd.model;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * 验证后发给前端的model
 */
@Data
@AllArgsConstructor
public class AuthenticationResponse {
    private final String userId;
    private final String token;
}
