package com.fooffer.fooBackEnd.aspect.converter;

import java.util.Arrays;
import java.util.Map;
import java.util.Optional;

import com.fooffer.fooBackEnd.constant.ErrorReason;
import com.fooffer.fooBackEnd.constant.baseEnum.IdBaseEnum;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.exception.CauseOnlyException;
import com.fooffer.fooBackEnd.exception.cause.ExceptionCause;
import org.springframework.core.convert.converter.Converter;

import com.google.common.collect.Maps;

public class IdToEnumConverter<T extends IdBaseEnum> implements Converter<String, T> {
    private final Map<String, T> idEnumMap = Maps.newHashMap();

    public IdToEnumConverter(Class<T> enumType) {
        Arrays.stream(enumType.getEnumConstants())
                .forEach(targetEnum -> idEnumMap.put(targetEnum.getId().toString(), targetEnum));
    }

    @Override
    public T convert(String source) {
        return Optional.of(source)
                .map(idEnumMap::get)
                .orElseThrow(() -> new CauseOnlyException(
                        ExceptionCause.builder()
                                .domain("converter")
                                .errorReason(ErrorReason.PARAM_INVALID).
                                build()
                ));
    }
}
