package com.fooffer.fooBackEnd.service.intf;

import com.fooffer.fooBackEnd.constant.ResourceOperationType;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.vo.CareerVo;
import org.springframework.stereotype.Service;

/**
 * 用户工作经历相关Service
 */
@Service
public interface CareerService {
    /**
     * 检查用户输入的工作经历信息，如果符合要求则创建工作经历并存入数据库
     */
    ResultData createCareer(CareerVo careerVo) throws BaseException;

    /**
     * 检查用户输入的工作经历信息，如果符合要求则修改对应的工作经历(修改内容或删除)
     * operation post：修改内容
     * operation delete：删除经历
     */
    ResultData modifyCareer(CareerVo careerVo, ResourceOperationType operation) throws BaseException;

}
