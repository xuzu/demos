package com.fooffer.fooBackEnd.model.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * 保存文章的tag标签
 */
@Document(collection = "articleTags")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ArticleTagDao {
    @Id
    private ObjectId _id;

    /**
     * 标签文本内容
     */
    private String title;
}
