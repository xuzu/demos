package com.fooffer.fooBackEnd.repository.creditSet;

import com.fooffer.fooBackEnd.model.entity.creditSet.ShellTransactionStatementDao;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ShellTransactionStatementRepository extends MongoRepository<ShellTransactionStatementDao, Long> {
    //根据交易单号查询交易记录
    Optional<ShellTransactionStatementDao> findShellTransactionStatementDaoByShellTransactionStatementId(Long shellTransactionStatementId);

    //根据用户id分页查询该用户最近的交易记录
    Page<ShellTransactionStatementDao> findShellTransactionStatementDaoByUserId(Long userId, Pageable pageable);
}
