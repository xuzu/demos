package com.fooffer.fooBackEnd.service.intf;

import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.vo.CommentVo;

import java.util.List;

import org.springframework.stereotype.Service;

/**
 * 评论系统相关Service
 */
@Service
public interface CommentService {
    /**
     * 检查用户输入的评论信息，如果符合要求则创建评论并存入数据库
     */
    ResultData createComment(CommentVo commentVo) throws BaseException;

    /**
     * 检查用户输入的评论，如果符合要求则修改评论
     */
    ResultData modifyComment(CommentVo commentVo) throws BaseException;

    /**
     * 根据输入的userId和parentId读取该用户能看到的评论list，并且对content进行visibility filter
     */
    List<CommentVo> getCommentList(Long userId, Long parentId) throws BaseException;

}
