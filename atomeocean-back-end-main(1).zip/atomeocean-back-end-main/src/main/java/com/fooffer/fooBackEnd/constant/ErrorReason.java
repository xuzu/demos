package com.fooffer.fooBackEnd.constant;

public enum ErrorReason {
    /**
     * General error reason
     */
    JSON_PROCESSING_ERROR("Json转换异常"),
    RECAPTCHA_VERIFICAITON_FAILED("recaptcha-token 验证失败"),
    BAD_REQUEST("异常请求"),
    IO_EXCEPTION("IO异常"),
    FILE_ERROR("文件异常"),
    FILE_UPLOAD_ERROR("文件上传失败"),
    TOKEN_EXPIRED("token过期"),
    NOT_LOG_IN("未登录"),

    /**
     * sign up error reason
     */
    PARAM_INVALID("invalid parameters"),
    PARAM_MISSING("参数缺失"),
    ACCOUNT_EXIST("注册账户已存在"),
    EMAIL_SEND_FAILED("邮件发送失败"),
    INVALID_REFER("邀请链接不存在"),
    CODE_EXPIRED("验证码已过期"),
    INVALID_CODE("验证码错误"),
    REGISTRATION_EXPIRED("注册信息过期"),
    ARTICLE_INVALID("invalid article ID"),

    /**
     * profile error reason
     */
    ACCOUNT_NOT_EXIST("账户不存在"),
    PERMISSION_DENIED("无查看权限"),
    MODIFY_NAME_TOO_OFTEN("两次修改名字之间需间隔至少60天");


    private final String message;

    ErrorReason(String message){
        this.message = message;
    }

    public String getMessage() {
        return this.message;
    }
}
