package com.fooffer.fooBackEnd.constant.userInformation;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fooffer.fooBackEnd.constant.baseEnum.IdCodeBaseEnum;

import java.util.stream.Stream;

public enum UserInformationVisibility implements IdCodeBaseEnum {
    EVERY_ONE_CAN_SEE(1, "EveryoneCanSee"),
    NEED_SIGN_IN(2, "NeedSignIn"),
    ONLY_SELF_CAN_SEE(5, "OnlySelfCanSee");

    private final Integer id;
    private final String code;

    UserInformationVisibility(Integer id, String code) {
        this.id = id;
        this.code = code;
    }

    @Override
    public String getCode() {
        return this.code;
    }

    @JsonValue
    @Override
    public Integer getId() {
        return this.id;
    }

    @JsonCreator
    public static UserInformationVisibility decode(Integer value) {
        return Stream.of(UserInformationVisibility.values()).filter(targetEnum -> targetEnum.id.equals(value)).findFirst().orElse(null);
    }
}
