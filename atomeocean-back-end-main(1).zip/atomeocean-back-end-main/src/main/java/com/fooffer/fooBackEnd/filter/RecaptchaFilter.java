package com.fooffer.fooBackEnd.filter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fooffer.fooBackEnd.config.RecaptchaFilterPaths;
import com.fooffer.fooBackEnd.model.RecaptchaResponse;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.service.intf.RecaptchaService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static com.fooffer.fooBackEnd.constant.ErrorReason.BAD_REQUEST;
import static com.fooffer.fooBackEnd.constant.ErrorReason.JSON_PROCESSING_ERROR;
import static com.fooffer.fooBackEnd.constant.ReturnCode.RECAPTCHA_VERIFICAITON_FAILED;

@Slf4j
public class RecaptchaFilter extends OncePerRequestFilter {

    private RecaptchaService recaptchaService;
    private RecaptchaFilterPaths recaptchaFilterPaths;

    private final double threshold = 0.5;

    public RecaptchaFilter(RecaptchaService recaptchaService, RecaptchaFilterPaths recaptchaFilterPaths){
        this.recaptchaService = recaptchaService;
        this.recaptchaFilterPaths = recaptchaFilterPaths;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException{
        //获取recaptcha token
        String recaptchaToken = request.getHeader("recaptcha");
        if(StringUtils.hasLength(recaptchaToken)){
            try {
                //获取响应结果
                RecaptchaResponse recaptchaResponse = recaptchaService.validateToken(recaptchaToken);
                //验证失败，拦截请求
                if(!recaptchaResponse.getSuccess()){
                    //打印验证失败原因
                    log.error("Error Domain: general error");
                    StringBuilder errorReason = new StringBuilder();
                    for(String reason : recaptchaResponse.getErrorCodes()){
                        errorReason.append(reason + " ");
                    }
                    log.error("Error Reason: " + errorReason.toString());
                    generateResponse(response);
                }
                else if(recaptchaResponse.getScore() < threshold){
                    log.error("Error Domain: general error");
                    log.error("Error Reason: " + RECAPTCHA_VERIFICAITON_FAILED.getMessage());
                    generateResponse(response);
                }
                else{
                    //验证通过，请求放行
                    filterChain.doFilter(request,response);
                }
                return;
            } catch (JsonProcessingException e) {
                //打印异常信息，拦截请求
                log.error("Error Domain: general error");
                log.error("Error Reason: " + JSON_PROCESSING_ERROR.getMessage());
                log.error(e.getCause().getMessage());
                generateResponse(response);
                return;
            }
        }

        //打印异常信息，拦截请求
        log.error("Error Domain: general error");
        log.error("Error Reason: " + BAD_REQUEST.getMessage());
        generateResponse(response);
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException {
        // 如果请求路径不需要过滤，则放行
        return recaptchaFilterPaths.ignorePath(request.getRequestURI());
    }

    private void generateResponse(HttpServletResponse response) throws IOException {
        String body = new ObjectMapper().writeValueAsString(ResultData.fail(RECAPTCHA_VERIFICAITON_FAILED.getCode(), "recaptcha验证失败"));
        response.setContentType("application/json;charset=UTF-8");
        response.getWriter().write(body);
    }
}
