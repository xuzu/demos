package com.fooffer.fooBackEnd.model.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * user在数据传输过程中的封装类
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {

    private Long userId;

    /**
     * 用户名
     */
    private String username;

    /**
     * 用户身份
     */
    private List<UserRoleDto> userRoleDtoList;

    /**
     * 用户发表过的文章id list
     */
    private List<Long> articleIds;

    /**
     * 对应的用户Info
     */
    private Long userInformationId;

    /**
     * 使用Email注册的用户的注册信息
     */
    private Long emailAuthId;

    /**
     * 对应的邀请人id
     * 若该账号为自己注册，则值为-1
     */
    private Long referUserId;
}
