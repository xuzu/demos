package com.fooffer.fooBackEnd.config;

import lombok.extern.slf4j.Slf4j;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Data
@Slf4j
@ConfigurationProperties(prefix = "recaptcha")
public class RecaptchaFilterPaths {

    /**
     * 从配置文件中读取所有需要recaptcha filter过滤的路径
     * 用于比对请求路径是否需要被过滤
     */
    private List<String> paths;

    public boolean ignorePath(String path){
        return !paths.contains(path);
    }
}
