package com.fooffer.fooBackEnd.service.impl;

import com.fooffer.fooBackEnd.constant.ErrorReason;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.exception.cause.ExceptionCause;
import com.fooffer.fooBackEnd.mapper.CommentMapper;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.dto.CommentDto;
import com.fooffer.fooBackEnd.model.entity.CommentDao;
import com.fooffer.fooBackEnd.model.entity.ImageDao;
import com.fooffer.fooBackEnd.model.entity.UserInformationDao;
import com.fooffer.fooBackEnd.model.vo.CommentVo;
import com.fooffer.fooBackEnd.repository.CommentRepository;
import com.fooffer.fooBackEnd.repository.ImageRepository;
import com.fooffer.fooBackEnd.repository.UserInformationRepository;
import com.fooffer.fooBackEnd.service.intf.CommentService;
import com.fooffer.fooBackEnd.utils.SnowflakeIdWorker;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


import static com.fooffer.fooBackEnd.constant.ReturnCode.*;

@Service
@Slf4j
@AllArgsConstructor
public class CommentServiceImpl implements CommentService {
    private final CommentRepository commentRepository;
    private final CommentMapper commentMapper;
    private final UserInformationRepository userInformationRepository;
    private final ImageRepository imageRepository;
    private final SnowflakeIdWorker snowflakeIdWorker = new SnowflakeIdWorker(7L, 6L);

    /**
     * 创建新的评论并存入数据库，同时增加父评论的childrenNumber
     */
    @Override
    public ResultData createComment(CommentVo commentVo) throws BaseException {
        CommentDto commentDto = commentMapper.vo2dto(commentVo);
        CommentDao commentDao = commentMapper.dto2dao(commentDto);
        Long commentId = snowflakeIdWorker.nextId();
        commentDao.setCommentId(commentId);

        // parentId 不等于文章id，说明该评论为某评论的子评论，需要增加父评论的childrenNumber
        if (!commentDao.getArticleId().equals(commentDao.getParentId())) {
            CommentDao parentCommentDao = commentRepository.findCommentDaoByCommentId(commentDao.getParentId())
                    .orElseThrow(
                            () -> new BaseException(
                                    COMMENT_NOT_EXIST,
                                    ExceptionCause.builder()
                                            .domain("comment")
                                            .errorReason(ErrorReason.BAD_REQUEST)
                                            .build()));
            parentCommentDao.setChildrenNumber(parentCommentDao.getChildrenNumber() + 1);
            commentRepository.save(parentCommentDao);
        }
        commentRepository.save(commentDao);

        return ResultData.success("评论发布成功");
    };

    /**
     * 检查用户输入的评论，如果符合要求则修改评论
     * 根据contract，可能会修改以下内容
        "content": "修改后的评论内容",
        "isWhisper": "是否是悄悄话",
        "isDeleted": "是否删除"
        并修改modifyTime
     */
    @Override
    public ResultData modifyComment(CommentVo commentVo) throws BaseException {
        Long commentId = commentVo.getCommentId();
        CommentDao commentDao = commentRepository.findCommentDaoByCommentId(commentId).orElseThrow(
                () -> new BaseException(
                        COMMENT_NOT_EXIST,
                        ExceptionCause.builder()
                                .domain("comment")
                                .errorReason(ErrorReason.BAD_REQUEST)
                                .build()));
        commentDao.setContent(commentVo.getContent());
        commentDao.setIsDeleted(commentVo.getIsDeleted());
        commentDao.setIsWhisper(commentVo.getIsWhisper());
        commentDao.setModifyTime(commentVo.getModifyTime());
        commentRepository.save(commentDao);
        return ResultData.success("评论修改成功");
    };

    /**
     * 根据输入的userId和parentId读取该用户能看到的评论list，并且对content进行visibility filter
     */
    @Override
    public List<CommentVo> getCommentList(Long userId, Long parentId) throws BaseException{
        List<CommentDao> commentList = commentRepository.findCommentDaoListByParentId(parentId);
        List<CommentVo> commentVoList = new ArrayList<>();
        for (CommentDao comment : commentList){
            CommentDto commentDto = convertCommentDaoToDto(comment);
            CommentVo commentVo = commentMapper.dto2vo(commentDto);
            //如果评论被删除，或评论为悄悄话、且用户不是发起或接收方，返回时删除评论内容
            if (commentVo.getIsDeleted() || 
                (commentVo.getIsWhisper() && 
                    !(commentVo.getFromId().equals(userId) || commentVo.getToId().equals(userId)))){
                commentVo.setContent("");
            }
            commentVoList.add(commentVo);
        }
        return commentVoList;
    };

    //把CommentDao转化成Dto,同时填充用户名和头像信息
    private CommentDto convertCommentDaoToDto(CommentDao commentDao) {
        CommentDto commentDto = commentMapper.dao2dto(commentDao);
        Long fromUserId = commentDto.getFromId();
        Long toUserId = commentDto.getToId();

        //找到两位user的userInformation
        UserInformationDao fromUserInformationDao = userInformationRepository.findUserInformationDaoByUserId(fromUserId).orElseThrow(
                () -> new BaseException(
                        ACCOUNT_NOT_EXIST,
                        ExceptionCause.builder()
                                .domain("user profile")
                                .errorReason(ErrorReason.ACCOUNT_NOT_EXIST)
                                .build()
                )
        );
        UserInformationDao toUserInformationDao = userInformationRepository.findUserInformationDaoByUserId(toUserId).orElseThrow(
                () -> new BaseException(
                        ACCOUNT_NOT_EXIST,
                        ExceptionCause.builder()
                                .domain("user profile")
                                .errorReason(ErrorReason.ACCOUNT_NOT_EXIST)
                                .build()
                )
        );
        
        //set 两位user的userName和头像link
        commentDto.setFromName(fromUserInformationDao.getNickname());
        commentDto.setToName(toUserInformationDao.getNickname());
        if(fromUserInformationDao.getAvatarId() != null){
            Optional<ImageDao> optionalImageDao = imageRepository.findImageDaoByImageId(fromUserInformationDao.getAvatarId());
            optionalImageDao.ifPresent(imageDao -> commentDto.setFromAvaterLink(imageDao.getUrl()));
        }
        if(toUserInformationDao.getAvatarId() != null){
            Optional<ImageDao> optionalImageDao = imageRepository.findImageDaoByImageId(toUserInformationDao.getAvatarId());
            optionalImageDao.ifPresent(imageDao -> commentDto.setToAvaterLink(imageDao.getUrl()));
        }
        return commentDto;
    }
}
