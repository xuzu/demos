package com.fooffer.fooBackEnd.repository;

import com.fooffer.fooBackEnd.model.entity.CareerDao;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;


@Repository
public interface CareerRepository extends MongoRepository<CareerDao, Long> {

    // 通过EducationId获取工作经历信息
    Optional<CareerDao> findCareerDaoByCareerId(Long careerId);
}
