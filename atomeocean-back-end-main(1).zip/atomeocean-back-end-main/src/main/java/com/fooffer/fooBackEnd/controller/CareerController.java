package com.fooffer.fooBackEnd.controller;

import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.vo.CareerVo;
import com.fooffer.fooBackEnd.service.intf.CareerService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * 工作经历接口
 * 包括添加、修改、删除工作经历等操作
 */
@RestController
@AllArgsConstructor
@RequestMapping("/career")
@Slf4j
public class CareerController {

     private final CareerService careerService;

    /**
     * 创建、修改、删除工作经历
     * @param careerVo
     * @return 创建、修改、删除工作经历的操作结果
     */
    @PostMapping("")
    public ResultData operateCareer(@RequestBody CareerVo careerVo) {

        ResultData result;
        // 根据操作类型决定调用哪个service
        switch (careerVo.getOperationType()) {

            // 创建新的工作经历
            case Post:
                result = careerService.createCareer(careerVo);
                break;

            // 修改已有的工作经历/删除工作经历
            case Patch: case Delete:
                result = careerService.modifyCareer(careerVo, careerVo.getOperationType());
                break;

            // 缺失按照post处理
            default:
                result = careerService.createCareer(careerVo);
                log.info("no operation type provided");
        }

        return result;
    }
}
