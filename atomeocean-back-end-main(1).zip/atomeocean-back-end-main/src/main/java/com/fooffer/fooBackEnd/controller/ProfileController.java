package com.fooffer.fooBackEnd.controller;

import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.vo.ModifyProfileParamsVo;
import com.fooffer.fooBackEnd.model.vo.UserInformationVo;
import com.fooffer.fooBackEnd.service.intf.UserInformationService;
import com.fooffer.fooBackEnd.utils.NumConvertUtil;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

/**
 * 用于显示用户的profile页面
 */
@RestController
@RequestMapping("/profile")
@AllArgsConstructor
@Slf4j
public class ProfileController {

    private final UserInformationService userInformationService;

    private final NumConvertUtil numConvertUtil;

    /**
     * 目前这个api没有被使用
     * Get API 根据给定的encodedUserId获取用户信息
     * @param encodedUserId 通过10to62工具将uid转化而来的62进制字符串
     * @return 用户信息的Vo
     */

    @GetMapping("/info")
    public ResultData<UserInformationVo> showUserInfo(
            @RequestParam(name = "encodedUserId") String encodedUserId
    ) {
        //使用62to10工具还原uid
        long userId = numConvertUtil.decode62To10(encodedUserId);
        
        // 根据userId来找到相应的userInformationVo
        UserInformationVo userInformationVo = userInformationService.getUserInformationVoByUserId(userId);

        return ResultData.success(userInformationVo);
    }

    @PostMapping("/avatar/update")
    public ResultData<String> updateAvatar(
            @RequestParam(name = "avatar") MultipartFile avatarImage,
            @RequestParam(name = "hash") String imageHash
    ) throws BaseException {

        //更新用户头像
        String avatarLink = userInformationService.updateAvatar(avatarImage, imageHash);

        //返回更新后的用户头像链接
        return ResultData.success(avatarLink);
    }


    @PostMapping("/update")
    public ResultData updateProfile(
            @RequestBody @Validated ModifyProfileParamsVo modifyProfileParamsVo
    ) throws NoSuchFieldException, IllegalAccessException {

        userInformationService.updateUserInformation(
                modifyProfileParamsVo
        );

        return ResultData.success("user profile updated");
    }
}
