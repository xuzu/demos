package com.fooffer.fooBackEnd.model.vo;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

import com.fooffer.fooBackEnd.constant.ResourceOperationType;


/**
 * 前端发送用户教育经历的封装类
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EducationVo {

    private Long educationId;
    
    private ResourceOperationType operationType;

    //学校名
    private String institutionName;

    /**学位名
     * 0：high school
     * 1：bachelor
     * 2：master
     * 3：doctor
     * 4：postdoc
     */
    private Integer degreeLevel;
    
    //专业名
    private String major;

    //开始日期
    private LocalDate startDate;    

    //结束日期
    private LocalDate endDate;
    
    //是否已经完成，如果是false那么前端显示结束日期为“至今”
    private Boolean isCompleted;
}
