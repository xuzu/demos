package com.fooffer.fooBackEnd.constant.file;

import java.util.HashSet;
import java.util.Set;

public class FileType {
    public final static String IMAGE_TYPE = "image/";
    public final static String AUDIO_TYPE = "audio/";
    public final static String VIDEO_TYPE = "video/";
    public final static String APPLICATION_TYPE = "application/";
    public final static String TXT_TYPE = "text/";

    //所有文件类型均为uppercase
    private final static Set<String> imageType = new HashSet<>(Set.of("JPG", "JPEG", "GIF", "PNG", "BMP", "PCX", "TGA", "PSD", "TIFF"));
    private final static Set<String> audioType = new HashSet<>(Set.of("MP3", "OGG", "WAV", "REAL", "APE", "MODULE", "MIDI", "VQF", "CD"));
    private final static Set<String> videoType = new HashSet<>(Set.of("MP4", "AVI", "MPEG-1", "RM", "ASF", "WMV", "QLV", "MPEG-2", "MPEG4", "MOV", "3GP"));
    private final static Set<String> applicationType = new HashSet<>(Set.of("DOC", "DOCX", "PPT", "PPTX", "XLS", "XLSX", "ZIP", "JAR"));
    private final static Set<String> txtType = new HashSet<>(Set.of("TXT"));

    public static boolean isImageType(String type){
        return imageType.contains(type);
    }

    public static boolean isAudioType(String type){
        return audioType.contains(type);
    }

    public static boolean isVideoType(String type){
        return videoType.contains(type);
    }

    public static boolean isApplicationType(String type){
        return applicationType.contains(type);
    }

    public static boolean isTxtType(String type){
        return txtType.contains(type);
    }
}
