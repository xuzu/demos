package com.fooffer.fooBackEnd.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.extern.slf4j.Slf4j;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "success", "score", "action", "challenge_ts", "hostname", "error-codes"})
@Slf4j
public class RecaptchaResponse {
    @JsonProperty("success")
    private Boolean success;
    @JsonProperty("score")
    private Double score;
    @JsonProperty("action")
    private String action;
    @JsonProperty("challenge_ts")
    private String challenge_ts;
    @JsonProperty("hostname")
    private String hostname;
    @JsonProperty("error-codes")
    private String[] errorCodes;
}
