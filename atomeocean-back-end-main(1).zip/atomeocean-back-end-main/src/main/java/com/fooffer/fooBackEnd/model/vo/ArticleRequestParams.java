package com.fooffer.fooBackEnd.model.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 请求单个文章的参数
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ArticleRequestParams {
    // 文章的id
    private String articleId;
}
