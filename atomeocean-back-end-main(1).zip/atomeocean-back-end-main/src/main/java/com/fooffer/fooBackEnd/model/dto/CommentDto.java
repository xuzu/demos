package com.fooffer.fooBackEnd.model.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CommentDto {

    //评论id
    private Long commentId;

    //本条评论对应的父评论id,对于第一层评论则保存文章id作为parentId
    private Long parentId;

    //本条评论所在的文章id
    private Long articleId;

    //评论者id
    private Long fromId;

    //评论者用户名
    private String fromName;

    //评论者头像链接
    private String fromAvaterLink;

    //被评论者id
    private Long toId;

    //被评论者用户名
    private String toName;

    //被评论者头像链接
    private String toAvaterLink;
    
    //点赞数量
    private Integer likes;

    //评论内容
    private String content;

    //评论创建时间
    private LocalDateTime createTime;

    //评论修改时间
    private LocalDateTime modifyTime;

    //是否被删除
    private Boolean isDeleted;

    //是否悄悄话
    private Boolean isWhisper;

    //子评论数量
    private Integer childrenNumber;
}
