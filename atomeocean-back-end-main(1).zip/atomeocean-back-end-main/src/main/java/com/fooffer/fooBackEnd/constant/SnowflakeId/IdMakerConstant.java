package com.fooffer.fooBackEnd.constant.SnowflakeId;

/**
 * Snowflake Id maker常量
 */
public class IdMakerConstant {
    public static final Integer datacenterId = 7;
    public static final Integer machineId = 6;
}
