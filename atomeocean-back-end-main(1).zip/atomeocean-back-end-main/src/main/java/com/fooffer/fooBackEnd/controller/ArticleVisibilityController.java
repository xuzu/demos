package com.fooffer.fooBackEnd.controller;

import com.fooffer.fooBackEnd.constant.articles.ArticleVisibility;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 接收和article visibility相关请求
 */
@RestController
@Slf4j
public class ArticleVisibilityController {

    @Autowired
    public ArticleVisibilityController() {
    }

    @GetMapping("/visibility")
    public String visibilityIdCode(@RequestParam("visibility") ArticleVisibility articleVisibility) {

        return articleVisibility.name();
    }
}
