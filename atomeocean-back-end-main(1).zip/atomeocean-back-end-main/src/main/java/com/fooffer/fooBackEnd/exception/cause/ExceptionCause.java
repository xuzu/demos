package com.fooffer.fooBackEnd.exception.cause;

import com.fooffer.fooBackEnd.constant.ErrorReason;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

/**
 * 异常的原因描述
 */
@Data
@AllArgsConstructor
@Builder
public class ExceptionCause {
    /**
     * 发生异常的位置
     */
    private String domain;

    /**
     * 异常产生的原因
     */
    private ErrorReason errorReason;
}
