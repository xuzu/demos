package com.fooffer.fooBackEnd.constant.baseEnum;

/**
 * Enum 接口，同时具备id和code
 */
public interface IdCodeBaseEnum extends IdBaseEnum, CodeBaseEnum {
}
