package com.fooffer.fooBackEnd.service.intf.creditSet;

import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.vo.StripePaymentParamsVo;
import com.stripe.exception.StripeException;
import org.springframework.stereotype.Service;

/*
 * stripe支付工具相关服务
 */
@Service
public interface StripeService {
    ResultData pay(StripePaymentParamsVo stripePaymentParamsVo) throws StripeException;
}
