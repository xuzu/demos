package com.fooffer.fooBackEnd.service.impl;

import com.fooffer.fooBackEnd.service.intf.UploadFileService;
import com.fooffer.fooBackEnd.utils.FileStorageUtil;
import io.minio.messages.Bucket;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.List;
import java.util.UUID;

@Service
@Slf4j
public class UploadFileServiceImpl implements UploadFileService {

    @Value("${file-storage.endpoint}")
    private String endpoint;

    @Value("${file-storage.bucket-name}")
    private String bucketName;

    @Override
    public boolean bucketExists(String bucketName) throws Exception {
        return FileStorageUtil.bucketExists(bucketName);
    }

    @Override
    public void makeBucket(String bucketName) throws Exception {
        FileStorageUtil.makeBucket(bucketName);
    }

    @Override
    public List<String> listBucketName() throws Exception {
        return FileStorageUtil.listBucketNames();
    }

    @Override
    public List<Bucket> listBuckets() throws Exception {
        return FileStorageUtil.listBuckets();
    }

    @Override
    public boolean removeBucket(String bucketName) throws Exception {
        return FileStorageUtil.removeBucket(bucketName);
    }

    @Override
    public List<String> listObjectNames(String bucketName) throws Exception {
        return FileStorageUtil.listObjectNames(bucketName);
    }

    @Override
    public String putObject(MultipartFile multipartFile, String bucketName, String fileType) {
        try {
            bucketName = StringUtils.hasLength(bucketName) ? bucketName : this.bucketName;
            String fileName = multipartFile.getOriginalFilename();

            String objectName = UUID.randomUUID().toString().replaceAll("-", "")
                    + fileName.substring(fileName.lastIndexOf("."));
            boolean success = FileStorageUtil.putObject(bucketName, multipartFile, objectName,fileType);
            if(success)
                return endpoint+"/"+bucketName+"/"+objectName;
            else
                return "上传失败";
        } catch (Exception e) {
            e.printStackTrace();
            return "上传失败";
        }
    }

    @Override
    public InputStream downloadObject(String bucketName, String objectName) throws Exception {
        return FileStorageUtil.getObject(bucketName, objectName);
    }

    @Override
    public boolean removeObject(String bucketName, String objectName) throws Exception {
        return FileStorageUtil.removeObject(bucketName, objectName);
    }

    @Override
    public String getObjectUrl(String bucketName, String objectName) throws Exception {
        return FileStorageUtil.getObjectUrl(bucketName, objectName);
    }
}
