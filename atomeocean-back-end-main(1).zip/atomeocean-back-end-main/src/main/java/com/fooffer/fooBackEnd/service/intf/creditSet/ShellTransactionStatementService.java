package com.fooffer.fooBackEnd.service.intf.creditSet;

import com.fooffer.fooBackEnd.model.entity.creditSet.ShellTransactionStatementDao;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public interface ShellTransactionStatementService {
    /**
     *  生成一条贝壳交易记录
     */
    ShellTransactionStatementDao generateShellTransactionStatement(Long userId, Long amount, LocalDateTime timestamp, String description);
}
