package com.fooffer.fooBackEnd.model.entity;

import com.fooffer.fooBackEnd.constant.userInformation.UserInformationVisibility;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.Set;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;

/**
 * 保存用户信息
 * 与登录/权限无关的信息
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document(collection = "userInformation")
public class UserInformationDao {


    @Id
    private ObjectId _id;
    /**
     * 逻辑主键
     */
    private Long userInformationId;

    /**
     * 对应的用户Id
     */
    private Long userId;

    /**
     * 用户的教育经历Id
     */
    private Set<Long> educationIdSet;
    /**
     * 用户的工作经历Id
     */
    private Set<Long> careerIdSet;
    /**
     * 用户昵称
     */
    private String nickname;

    private Long avatarId;

    private String motto;

    private String selfIntroduction;

    private LocalDateTime nicknameLastModifyTime;

    /**
     * 用户信息可见性
     */
    private UserInformationVisibility userInformationVisibility;

    @Override
    public String toString() {
        return "UserInformation { nickname" + nickname + "motto" + motto + "selfIntroduction" + selfIntroduction
                + ", avatarId" + avatarId + "}";
    }
}