package com.fooffer.fooBackEnd.mapper;

import com.fooffer.fooBackEnd.model.dto.ImageDto;
import com.fooffer.fooBackEnd.model.entity.ImageDao;
import org.mapstruct.Mapper;

/**
 * Image vo, dto, dao 映射
 */
@Mapper(componentModel = "spring")
public interface ImageMapper {
    ImageDao dto2dao(ImageDto imageDto);
}
