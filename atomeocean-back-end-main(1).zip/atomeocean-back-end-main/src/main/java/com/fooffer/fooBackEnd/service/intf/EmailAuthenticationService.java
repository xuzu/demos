package com.fooffer.fooBackEnd.service.intf;

import com.fooffer.fooBackEnd.model.entity.EmailAuthDao;
import org.springframework.stereotype.Service;

@Service
public interface EmailAuthenticationService {

    /**
     * 根据用户邮箱信息，返回对应的用户信息
     * @param userEmail 登录用的邮箱
     * @return EmailAuthDao
     */
    EmailAuthDao loadEmailAuthDaoByUserEmail(String userEmail);
}
