package com.fooffer.fooBackEnd.model;

import com.fooffer.fooBackEnd.constant.ReturnCode;
import groovy.util.logging.Slf4j;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 后端返回给前端的结果封装类
 * @param <T> 返回的数据类型
 *
 * 在Controller层通过ResultData.success()对返回结果进行包装后返回前端
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class ResultData<T> {
    // 结果状态码
    private int status;
    private String message;
    private T data;
    private long timestamp = System.currentTimeMillis();

    public ResultData(ReturnCode returnCode) {
        status = returnCode.getCode();
        message = returnCode.getMessage();
    }

    /**
     * 请求成功时调用
     * @param data response中data部分
     * @return 通知前端请求成功
     * @param <T>
     */
    public static <T> ResultData<T> success(T data) {
        ResultData<T> resultData = new ResultData<>();
        resultData.setStatus(ReturnCode.RC100.getCode());
        resultData.setMessage(ReturnCode.RC100.getMessage());
        resultData.setData(data);

        return  resultData;
    }

    public static <T> ResultData<T> fail(int code, String message) {
        ResultData<T> resultData = new ResultData<>();
        resultData.setStatus(code);
        resultData.setMessage(message);

        return  resultData;
    }
}
