package com.fooffer.fooBackEnd.repository;

import com.fooffer.fooBackEnd.model.entity.ArticleTagDao;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ArticleTagRepository extends MongoRepository<ArticleTagDao, String> {

    // 根据tagId进行查询
    ArticleTagDao findArticleTagDaoBy_id(String tagId);
}
