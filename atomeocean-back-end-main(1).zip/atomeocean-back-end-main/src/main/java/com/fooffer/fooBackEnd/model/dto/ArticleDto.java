package com.fooffer.fooBackEnd.model.dto;

import com.fooffer.fooBackEnd.constant.articles.ArticleVisibility;
import com.fooffer.fooBackEnd.model.dto.article.ArticleAuthor;
import com.fooffer.fooBackEnd.model.dto.article.ArticleTagDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 在service里面将DO转换成DTO，而且准备把DTO转换成VO
 * 再发送给前端
 *
 * 这里Dto看情况来读取需要的field
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ArticleDto {

    private Long articleId;

    private String title;

    private String collapsedContent;

    private ArticleAuthor articleAuthor;

    private Long contentId;

    // 文章内容
    private String content;

    private LocalDateTime createTime;

    private LocalDateTime latestUpdateTime;

    private Integer viewCount;

    private Integer wordCount;

    private Boolean isDeleted;

    private String categoryName;

    private ArticleVisibility visibility;

    private List<ArticleTagDto> articleTagList;

    private String articleCoverImageLink;

    @Override
    public String toString() {
        return "Article dto { title" + title
                 + ", createTime" + getCreateTime().toString();
    }
}
