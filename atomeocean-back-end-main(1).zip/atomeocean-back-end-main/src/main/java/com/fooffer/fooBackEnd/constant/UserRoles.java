package com.fooffer.fooBackEnd.constant;

/**
 * 保存User Role 常量
 */
public class UserRoles {

    public static Integer ROLE_MEMBER_ID = 100;

    public static Integer ROLE_MANAGER_ID = 10000;

    public static Integer ROLE_ADMIN_ID = 1000000;

}
