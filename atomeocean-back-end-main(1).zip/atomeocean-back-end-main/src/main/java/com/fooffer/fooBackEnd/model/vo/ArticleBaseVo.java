package com.fooffer.fooBackEnd.model.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * article vo 基础类
 */

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public abstract class ArticleBaseVo {

    /**
     * 文章词数统计
     */
    public Integer wordCount;
}
