package com.fooffer.fooBackEnd.service.intf;

import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.vo.EmailAuthVo;
import org.springframework.stereotype.Service;

/**
 * 用户注册相关Service
 */
@Service
public interface ResetPasswordService {

    /**
     * 检查用户输入的邮箱是否满足重置密码的要求，如果符合则发送验证码邮件
     */
    ResultData verifyUserEmail(EmailAuthVo emailAuthVo) throws BaseException;

    /**
     * 检查用户输入的验证码是否正确，如果正确则修改用户密码
     */
    ResultData verifyCode(String email, String code) throws BaseException;
}
