package com.fooffer.fooBackEnd.constant.user;

/**
 * 和注册相关的常量
 */
public class RegisterConstant {
    public static final int EXPIRED_TIME = 900;
}
