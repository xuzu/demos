package com.fooffer.fooBackEnd.repository;

import com.fooffer.fooBackEnd.model.entity.UserInformationDao;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * 对数据库中userInformation collection进行操作
 */
@Repository
public interface UserInformationRepository extends MongoRepository<UserInformationDao, Long> {

    // 通过用户名获取UserInformation
    Optional<UserInformationDao> findUserInformationDaoByUserId(Long userId);
}
