package com.fooffer.fooBackEnd.aspect.converter;

import com.fooffer.fooBackEnd.constant.ErrorReason;
import com.fooffer.fooBackEnd.constant.baseEnum.CodeBaseEnum;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.exception.CauseOnlyException;
import com.fooffer.fooBackEnd.exception.cause.ExceptionCause;
import com.google.common.collect.Maps;
import org.springframework.core.convert.converter.Converter;

import java.util.Arrays;
import java.util.Map;
import java.util.Optional;

public class CodeToEnumConverter<T extends CodeBaseEnum> implements Converter<String, T> {
    private final Map<String, T> codeEnumMap = Maps.newHashMap();

    public CodeToEnumConverter(Class<T> enumType) {
        Arrays.stream(enumType.getEnumConstants())
                .forEach(targetEnum -> codeEnumMap.put(targetEnum.getCode(), targetEnum));
    }

    @Override
    public T convert(String source) {
        return Optional.of(source)
                .map(codeEnumMap::get)
                .orElseThrow(() -> new CauseOnlyException(
                        ExceptionCause.builder()
                                .domain("converter")
                                .errorReason(ErrorReason.PARAM_INVALID).
                                build()
                ));
    }
}
