package com.fooffer.fooBackEnd.model.dto.creditSet;

import com.fooffer.fooBackEnd.constant.stripe.Currency;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class StripeTransactionStatementDto {

    private Long userId;

    private String stripeTransactionStatementId;

    private Long amount;

    private Currency currency;

    private LocalDateTime timestamp;

    private String receiptUrl;
}
