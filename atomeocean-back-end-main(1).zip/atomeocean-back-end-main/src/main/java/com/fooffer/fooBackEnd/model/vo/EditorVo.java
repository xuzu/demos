package com.fooffer.fooBackEnd.model.vo;

import com.fooffer.fooBackEnd.constant.ResourceOperationType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 接收Editor上传文章时的参数
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@Builder
public class EditorVo extends ArticleBaseVo {

    private ResourceOperationType operationType;

    /**
     * web需要把过长的Long id变成string类型
     * todo:base64压缩long id
     */
    private String articleId;

    /**
     * Key of title.
     */
    private String title;

    /**
     * Key of article author id.
     */
    private String authorId;

    /**
     * 作者的名字
     */
    private String authorName;

    /**
     * Key of article collapsed content.
     */
    private String collapsedContent;

    private Long contentId;
    /**
     * 文章的文本字符串
     */
    private String content;

    /**
     * Key of create date.
     * 转换成日期
     */
    @Builder.Default
    private LocalDateTime createTime = LocalDateTime.now();

    private LocalDateTime latestUpdateTime;

    /**
     * 文章是否已经被删除
     * 默认文章存在，即false
     */
    @Builder.Default
    private Boolean isDeleted = false;

    /**
     * 文章标签
     */
    private List<ArticleTagVo> addTagArray;

    /**
     * 文章所属分类名称
     */
    private String categoryName;

    /**
     * 文章可见权限
     */
    private Integer visibilityId;

    /**
     * 文章封面图的链接
     */
    private String articleCoverImageLink;

    @Override
    public String toString() {
        return "Article vo { title" + title
                + ", createTime" + getCreateTime().toString();
    }
}
