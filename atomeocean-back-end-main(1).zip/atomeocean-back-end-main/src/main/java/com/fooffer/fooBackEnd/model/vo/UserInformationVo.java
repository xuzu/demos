package com.fooffer.fooBackEnd.model.vo;

import java.util.Set;

import com.fooffer.fooBackEnd.constant.ResourceOperationType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 与前端交互时使用的 User info model
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserInformationVo {

    private ResourceOperationType operationType;

    private String nickname;

    private String avatarLink;

    private String motto;

    private String selfIntroduction;

    private int visibilityId;

    private Set<EducationVo> educationVoSet;

    private Set<CareerVo> careerVoSet;
}
