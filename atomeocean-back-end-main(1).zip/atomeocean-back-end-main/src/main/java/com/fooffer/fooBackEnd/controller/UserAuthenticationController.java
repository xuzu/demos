package com.fooffer.fooBackEnd.controller;

import com.fooffer.fooBackEnd.constant.ErrorReason;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.exception.cause.ExceptionCause;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.entity.UserRoleDao;
import com.fooffer.fooBackEnd.model.vo.DynamicRouteVo;
import com.fooffer.fooBackEnd.service.intf.DynamicRouteService;
import com.fooffer.fooBackEnd.service.intf.UserAuthenticationService;
import com.fooffer.fooBackEnd.service.intf.UserRoleService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.fooffer.fooBackEnd.constant.ReturnCode.MISSING_PARAMETER;

/**
 * 用户账号状态管理
 * 注册，登入，登出
 */
@RestController
@RequestMapping("/auth")
@AllArgsConstructor
@Slf4j
public class UserAuthenticationController {

    private final UserRoleService userRoleService;

    private final UserAuthenticationService userAuthenticationService;

    private final DynamicRouteService dynamicRouteService;

    /**
     * 根据用户的权限(jwt token信息)，请求动态路由表
     * @return 符合权限的动态路由表数据List
     */
    @PostMapping("/permission")
    public List<DynamicRouteVo> getDynamicRoutes() {

        Authentication authentication =  SecurityContextHolder.getContext().getAuthentication();
        // 对路由表去重
        Set<Integer> dynamicRouteIdSet = new HashSet<>();

        // 遍历角色列表，读取所有合法的动态路由表
        for (GrantedAuthority authority: authentication.getAuthorities()) {
            UserRoleDao roleDao = userRoleService.findRoleByRoleName(authority.getAuthority());
            if (roleDao == null) continue;
            List<Integer> dynamicRouteIdList = roleDao.getDynamicRouteIds();

            dynamicRouteIdSet.addAll(dynamicRouteIdList);
        }

        List<DynamicRouteVo> dynamicRouteVos = new ArrayList<>();
        for (Integer dynamicRouteId: dynamicRouteIdSet) {
            // 读取到路由表
            DynamicRouteVo dynamicRouteVo = dynamicRouteService.getDynamicRoutesByDynamicRouteId(dynamicRouteId);
            if (dynamicRouteVo != null) {
                dynamicRouteVos.add(dynamicRouteVo);
            }
        }

        return dynamicRouteVos;
    }

    @PostMapping("/resendCode")
    public ResultData resendCode(
            @RequestParam(name = "email") String email
    ) throws BaseException {
        //验证前端传递参数是否完整
        if(!StringUtils.hasLength(email)){
            ExceptionCause exceptionCause = new ExceptionCause("verify", ErrorReason.PARAM_MISSING);
            throw new BaseException(MISSING_PARAMETER, exceptionCause);
        }

        return userAuthenticationService.resendCode(email);
    }
}
