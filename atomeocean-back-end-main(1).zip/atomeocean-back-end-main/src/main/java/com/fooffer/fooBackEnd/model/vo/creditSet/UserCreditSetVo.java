package com.fooffer.fooBackEnd.model.vo.creditSet;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Builder;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserCreditSetVo {

    private Long userId;

    private Long shell;
}
