package com.fooffer.fooBackEnd.utils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.concurrent.TimeUnit;

@Component
@Slf4j
public class RedisUtil {

    public static RedisTemplate redisTemplate;

    @Autowired
    public RedisUtil(RedisTemplate redisTemplate){
        this.redisTemplate = redisTemplate;
    }


    public static void increment(String key, long delta) {
        if (key == null) {
            throw new IllegalArgumentException("Key cannot be null");
        }
        if (delta < 0) {
            throw new IllegalArgumentException("Delta must be greater than or equal to 0");
        }
        redisTemplate.opsForValue().increment(key, delta);
    }

    /**
     * 将<key, value>持久保存到Redis中
     * @param key  需要保存的key
     * @param value  需要保存的value
     */
    public static void set(String key, Object value) {
        redisTemplate.opsForValue().set(key, value);
    }

    /**
     * 将<key, value>保存到Redis中，并设置过期时间
     * @param key  需要保存的key
     * @param value  需要保存的value
     * @param time  redis中保存的时间数值
     * @param timeUnit  redis中保存的时间单位
     */
    public static void set(String key, Object value, Integer time, TimeUnit timeUnit){
        redisTemplate.opsForValue().set(key, value);
        redisTemplate.expire(key, time, timeUnit);
    }

    /**
     * 添加一条hyperloglog的记录
     * @param key
     * @param value 增长的数值
     */
    public static void addHyperloglog(String key, String value) {
        redisTemplate.opsForHyperLogLog().add(key, value);
    }

    /**
     * 统计特定key值的hyperloglog记录数
     * @param key 查询的key值
     * @return 共多少条记录
     */
    public static Long countHyperloglog(String key) {
        return redisTemplate.opsForHyperLogLog().size(key);
    }

    /**
     * 获取redis指定key对应的value
     * @param key
     * @return 参数key对应的value
     */
    public static Object get(String key) {
        return key == null ? null : redisTemplate.opsForValue().get(key);
    }

    /**
     * 查找redis中是否存在指定的key
     * @param key
     * @return
     */
    public static boolean hasKey(String key) {
        return redisTemplate.hasKey(key);
    }

    /**
     * 在redis中删除指定key对应的<key, value>
     * @param key
     */
    public static void delete(String key){
        redisTemplate.delete(key);
    }

    /**
     * 在redis中批量删除指定的keys
     * @param keys 需要删除的key的集合
     */
    public static void deleteAll(Collection<String> keys){
        redisTemplate.delete(keys);
    }
}
