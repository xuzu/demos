package com.fooffer.fooBackEnd.model.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Max;
import javax.validation.constraints.Size;

import static com.fooffer.fooBackEnd.constant.userInformation.DataValidationConstant.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ModifyProfileParamsVo {

    private String[] fieldsModified;

    @Size(
            min = NICKNAME_MIN_LENGTH,
            message = NICKNAME_MIN_LENGTH_MESSAGE
    )
    @Size(
            max = NICKNAME_MAX_LENGTH,
            message = NICKNAME_MAX_LENGTH_MESSAGE
    )
    private String nickname;

    @Size(
            max = MOTTO_MAX_LENGTH,
            message = MOTTO_MAX_LENGTH_MESSAGE
    )
    private String motto;

    @Size(
            max = SELF_INTRODUCTION_MAX_LENGTH,
            message = SELF_INTRODUCTION_MAX_LENGTH_MESSAGE
    )
    private String selfIntroduction;
}
