package com.fooffer.fooBackEnd.service.impl;

import com.fooffer.fooBackEnd.constant.ErrorReason;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.exception.cause.ExceptionCause;
import com.fooffer.fooBackEnd.model.entity.ImageDao;
import com.fooffer.fooBackEnd.repository.ImageRepository;
import com.fooffer.fooBackEnd.service.intf.ImageService;
import com.fooffer.fooBackEnd.utils.FileStorageUtil;
import com.fooffer.fooBackEnd.utils.FileTypeUtils;
import com.fooffer.fooBackEnd.utils.SnowflakeIdWorker;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

import static com.fooffer.fooBackEnd.constant.ReturnCode.FILE_UPLOAD_FAILED;

@Service
@Slf4j
public class ImageServiceImpl implements ImageService {

    @Value("${file-storage.endpoint}")
    private String endpoint;

    @Value("${file-storage.bucket-name}")
    private String bucketName;

    private ImageRepository imageRepository;

    private SnowflakeIdWorker snowflakeIdWorker;

    @Autowired
    public ImageServiceImpl(ImageRepository imageRepository) {
        this.imageRepository = imageRepository;
        this.snowflakeIdWorker = new SnowflakeIdWorker(7L, 6L);
    }

    /**
     * 根据图片的id获取图片的信息
     * @param imageId 图片id，可以是avatarId
     * @return ImageDao
     */
    @Override
    public ImageDao getImageDaoByImageId(Long imageId) {
         return imageRepository.findImageDaoByImageId(imageId).orElseThrow();
    }

    /**
     * 根据上传的文件对数据库进行更新
     *
     * @param image 用户上传的图片
     * @param hash 图片hash值
     * @return ImageDao
     */
    @Override
    public ImageDao uploadImage(MultipartFile image, String hash) throws BaseException {
        //查看上传图片是否已存在
        Optional<ImageDao> optionalImageDao = imageRepository.findImageDaoByHash(hash);
        //如果图片已经存在
        if(optionalImageDao.isPresent()){
            //增加新图片引用量
            ImageDao imageDao = optionalImageDao.get();
            imageDao.setCitation(imageDao.getCitation() + 1);
            imageRepository.save(imageDao);
            return imageDao;
        }
        else{
            //上传图片
            String originalImageName = null, s3ImageName = null;
            String imageType = null;
            String imageUrl = null;
            try {
                originalImageName = image.getOriginalFilename();
                s3ImageName = UUID.randomUUID().toString().replaceAll("-", "")
                        + originalImageName.substring(originalImageName.lastIndexOf("."));

                imageType = FileTypeUtils.getFileType(image);
                boolean success = FileStorageUtil.putObject(bucketName, image, s3ImageName, imageType);
                if(success){
                    imageUrl = endpoint+"/"+bucketName+"/"+s3ImageName;
                }
                else {
                    ExceptionCause exceptionCause = new ExceptionCause("file update", ErrorReason.FILE_UPLOAD_ERROR);
                    throw new BaseException(FILE_UPLOAD_FAILED, exceptionCause);
                }
            }catch (BaseException e) {
                throw e;
            } catch (Exception e) {
                ExceptionCause exceptionCause = new ExceptionCause("file update", ErrorReason.FILE_UPLOAD_ERROR);
                throw new BaseException(FILE_UPLOAD_FAILED, exceptionCause, e.getMessage(), e.getCause());
            }

            //保存新图片
            Long imageId = snowflakeIdWorker.nextId();
            ImageDao newImageDao = ImageDao.builder()
                    .imageId(imageId)
                    .originalImageName(originalImageName)
                    .bucketName(bucketName)
                    .s3ImageName(s3ImageName)
                    .url(imageUrl)
                    .imageType(imageType)
                    .imageSize(image.getSize())
                    .timestamp(LocalDateTime.now())
                    .hash(hash)
                    .citation(1)
                    .build();
            imageRepository.save(newImageDao);
            return newImageDao;
        }
    }

    /**
     * 根据输入的id更新对应图片文件的引用次数
     *
     * @param imageId 图片Id
     * @param citationCounter 该图片引用次数的变化量
     */
    @Override
    public void updateCitation(Long imageId, int citationCounter) {
        Optional<ImageDao> optionalImageDao = imageRepository.findImageDaoByImageId(imageId);
        optionalImageDao.ifPresent((imageDao) -> {
            imageDao.setCitation(imageDao.getCitation() + citationCounter);
            imageRepository.save(imageDao);
        });
    }
}
