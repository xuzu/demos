package com.fooffer.fooBackEnd.controller;

import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.vo.UserRoleVo;
import com.fooffer.fooBackEnd.service.intf.UserRoleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 用于角色授权，后台用户管理
 */
@RestController
@Slf4j
@RequestMapping("/staff")
public class RoleController {

    private final UserRoleService userRoleService;

    @Autowired
    public RoleController(UserRoleService userRoleService) {
        this.userRoleService = userRoleService;
    }

    /**
     * 显示都有哪些角色
     * @return 角色列表
     */
    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_MANAGER')")
    @GetMapping("/roles")
    public List<UserRoleVo> listRoles() {
        List<UserRoleVo> userRoleVoList = userRoleService.findAllRoles();

        return userRoleVoList;
    }

    /**
     * 添加一个新的Role
     * @param userRoleVo 关于user role请求参数
     * @return 返回消息通知
     */
    @PostMapping("/roles")
    public ResultData<String> createRole(
            @RequestBody UserRoleVo userRoleVo
    ) {
        userRoleService.createRole(userRoleVo);

        return ResultData.success("a new role created");
    }
}
