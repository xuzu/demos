package com.fooffer.fooBackEnd.service.impl.creditSet;

import com.fooffer.fooBackEnd.constant.stripe.Currency;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.entity.creditSet.StripeTransactionStatementDao;
import com.fooffer.fooBackEnd.model.vo.StripePaymentParamsVo;
import com.fooffer.fooBackEnd.repository.creditSet.StripeTransactionStatementRepository;
import com.fooffer.fooBackEnd.service.intf.creditSet.StripeService;
import com.fooffer.fooBackEnd.utils.TimeConvertUtil;
import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.Charge;
import org.springframework.beans.factory.annotation.Value;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

import static com.fooffer.fooBackEnd.constant.credits.ShellConstants.*;
import static com.fooffer.fooBackEnd.constant.stripe.StripeConstants.*;

@Service
@Slf4j
public class StripeServiceImpl implements StripeService {

    @Value("${payment.privateKey:}")
    private String stripePrivateKey;

    private final UserCreditSetServiceImpl userCreditSetService;

    private final StripeTransactionStatementRepository stripeTransactionStatementRepository;

    public StripeServiceImpl(
            UserCreditSetServiceImpl userCreditSetService,
            StripeTransactionStatementRepository stripeTransactionStatementRepository
    ){
        this.userCreditSetService = userCreditSetService;
        this.stripeTransactionStatementRepository = stripeTransactionStatementRepository;
    }

    @PostConstruct
    public void init() {
        Stripe.apiKey = stripePrivateKey;
    }

    /**
     * Stripe付款接口
     */
    @Override
    public ResultData pay(StripePaymentParamsVo stripePaymentParamsVo) throws StripeException {
        // 获取当前用户的user id
        Long currentUserId = (Long) SecurityContextHolder.getContext().getAuthentication().getDetails();

        //设置支付参数
        Map<String, Object> paymentParams = setStripeParams(stripePaymentParamsVo);

        //请求支付
        Charge chargeResult = Charge.create(paymentParams);

        //TODO: 支付失败cases处理

        //1. 支付成功后添加stripe明细记录
        StripeTransactionStatementDao stripeTransactionStatementDao = generateStripeTransactionStatement(chargeResult, currentUserId);
        stripeTransactionStatementRepository.save(stripeTransactionStatementDao);

        //TODO: 发送邮件通知

        //2. 调用修改积分接口
        Long actualAmount = calculateAmount(chargeResult.getAmount());
        return userCreditSetService.modifyCredit(currentUserId, actualAmount, RECHARGE);
    }

    /**
     * 封装Stripe付款相关参数
     */
    private Map<String, Object> setStripeParams(StripePaymentParamsVo stripePaymentParamsVo){
        Map<String, Object> paymentParams = new HashMap<>();
        paymentParams.put("amount", stripePaymentParamsVo.getAmount());
        paymentParams.put("currency", stripePaymentParamsVo.getCurrency());
        paymentParams.put("source", stripePaymentParamsVo.getStripeToken());

        return paymentParams;
    }

    /**
     * 生成stripe交易明细data object
     */
    private StripeTransactionStatementDao generateStripeTransactionStatement(Charge charge, Long userId) throws StripeException {

        Charge.PaymentMethodDetails.Card card = charge.getPaymentMethodDetails().getCard();

        return StripeTransactionStatementDao.builder()
                .stripeTransactionStatementId(charge.getId())
                .amount(charge.getAmount())
                .currency(Currency.USD)
                .timestamp(TimeConvertUtil.epochSecond2LocalDateTime(charge.getCreated()))
                .receiptUrl(charge.getReceiptUrl())
                .cardLastFourDigits(card.getLast4())
                .cardExpiredDate(card.getExpMonth().toString() + "/" + card.getExpYear().toString())
                .userId(userId)
                .build();
    }

    /**
     * 计算扣除手续费后实际充值金额
     * @param totalAmount 用户扣款总金额
     * @return 扣除手续费后用户在网站的实际充值金额
     */
    private Long calculateAmount(Long totalAmount){
        return (long) Math.floor(totalAmount * FEE_RATE - CONSTANT_FEE);
    }
}
