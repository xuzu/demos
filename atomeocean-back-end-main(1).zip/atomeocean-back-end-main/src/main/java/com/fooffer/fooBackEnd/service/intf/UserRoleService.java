package com.fooffer.fooBackEnd.service.intf;

import com.fooffer.fooBackEnd.model.entity.UserRoleDao;
import com.fooffer.fooBackEnd.model.vo.UserRoleVo;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 定义关于User role的操作
 */


@Service
public interface UserRoleService {

    /**
     * 创建一个新的角色
     */
    void createRole(UserRoleVo userRoleVo);

    /**
     * 根据用户的角色读取相应的Dao
     * @param authority 用户的角色名称
     * @return 这个角色的Dao
     */
    UserRoleDao findRoleByRoleName(String authority);

    /**
     * 返回所有的用户角色
     */
    List<UserRoleVo> findAllRoles();

}
