package com.fooffer.fooBackEnd.handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fooffer.fooBackEnd.model.AuthenticationResponse;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.security.EmailPasswordAuthenticationToken;
import com.fooffer.fooBackEnd.security.JwtUserDetails;
import com.fooffer.fooBackEnd.utils.JwtTokenUtils;
import com.fooffer.fooBackEnd.utils.NumConvertUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static com.fooffer.fooBackEnd.constant.security.JwtTokenConstant.TOKEN_PREFIX;

/**
 * 处理登录成功的反馈
 * 返回标志着登录成功的json响应数据
 */
@Component
@Slf4j
public class CustomAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

    /**
     * 认证成功，封装jwt token
     * @param request
     * @param response
     * @param authResult Email注册时类型为EmailPasswordAuthenticationToken
     * @throws IOException
     * @throws ServletException
     */
    @Override
    public void onAuthenticationSuccess(
            HttpServletRequest request,
            HttpServletResponse response,
            Authentication authResult
    ) throws IOException, ServletException {
        EmailPasswordAuthenticationToken emailPasswordAuthenticationToken = (EmailPasswordAuthenticationToken)authResult;

        JwtUserDetails userDetails = (JwtUserDetails) emailPasswordAuthenticationToken.getDetails();

        List<String> roles = new ArrayList<>();
        Collection<? extends GrantedAuthority> authorities = userDetails.getAuthorities();
        for (GrantedAuthority authority: authorities) {
            roles.add(authority.getAuthority());
        }

        // 封装jwt token
        String token = JwtTokenUtils.createToken(
                (String) emailPasswordAuthenticationToken.getPrincipal(),
                userDetails.getUserId(),
                roles,
                false
        );
        // 返回创建成功的token
        // 按照jwt的规定，请求的格式应该是 `Bearer token`
        response.setHeader("token", TOKEN_PREFIX + token);
        response.setContentType("text/json; charset=utf-8"); // 返回格式json

        AuthenticationResponse authenticationResponse = new AuthenticationResponse(
                NumConvertUtil.encode10To62(userDetails.getUserId()),
                TOKEN_PREFIX + token
        );

        // 封装验证结果
        String body = new ObjectMapper().writeValueAsString(ResultData.success(authenticationResponse));

        response.getWriter().write(body);

    }
}
