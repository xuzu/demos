package com.fooffer.fooBackEnd.exception;

import com.fooffer.fooBackEnd.constant.ReturnCode;
import com.fooffer.fooBackEnd.exception.cause.ExceptionCause;

public class CauseOnlyException extends BaseException {

    public CauseOnlyException(final ExceptionCause exceptionCause) {
        this(null, exceptionCause);
    }
    public CauseOnlyException(ReturnCode returnCode, ExceptionCause exceptionCause) {
        super(returnCode, exceptionCause);
    }

    public CauseOnlyException(ReturnCode returnCode, ExceptionCause exceptionCause, String message) {
        super(returnCode, exceptionCause, message);
    }

    public CauseOnlyException(ReturnCode returnCode, ExceptionCause exceptionCause, String message, Throwable cause) {
        super(returnCode, exceptionCause, message, cause);
    }
}
