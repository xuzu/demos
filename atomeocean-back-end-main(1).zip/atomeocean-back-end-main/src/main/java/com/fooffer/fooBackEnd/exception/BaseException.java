package com.fooffer.fooBackEnd.exception;

import com.fooffer.fooBackEnd.constant.ReturnCode;
import com.fooffer.fooBackEnd.exception.cause.ExceptionCause;

/**
*  作为所有业务异常的base class
*/
public class BaseException extends RuntimeException{

    private ReturnCode returnCode;
    private ExceptionCause exceptionCause;

    public BaseException(ReturnCode returnCode, ExceptionCause exceptionCause) {
        this.returnCode = returnCode;
        this.exceptionCause = exceptionCause;
    }

    public BaseException(ReturnCode returnCode, ExceptionCause exceptionCause, String message) {
        super(message);
        this.returnCode = returnCode;
        this.exceptionCause = exceptionCause;
    }

    public BaseException(ReturnCode returnCode, ExceptionCause exceptionCause, String message, Throwable cause) {
        super(message, cause);
        this.returnCode = returnCode;
        this.exceptionCause = exceptionCause;
    }

    public void setReturnCode(ReturnCode returnCode) {
        this.returnCode = returnCode;
    }

    public ReturnCode getReturnCode() {
        return returnCode;
    }

    public ExceptionCause getExceptionCause() {
        return exceptionCause;
    }

    public void setExceptionCause(ExceptionCause exceptionCause) {
        this.exceptionCause = exceptionCause;
    }

}
