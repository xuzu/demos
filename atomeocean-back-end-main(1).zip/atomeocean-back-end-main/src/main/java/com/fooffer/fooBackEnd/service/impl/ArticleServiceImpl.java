package com.fooffer.fooBackEnd.service.impl;

import com.fooffer.fooBackEnd.aspect.errorHandler.articleGeneral.InvalidArticleIdException;
import com.fooffer.fooBackEnd.mapper.ArticleMapper;
import com.fooffer.fooBackEnd.model.dto.ArticleDto;
import com.fooffer.fooBackEnd.model.dto.UserInformationDto;
import com.fooffer.fooBackEnd.model.dto.article.ArticleAuthor;
import com.fooffer.fooBackEnd.model.entity.ArticleContentDao;
import com.fooffer.fooBackEnd.model.entity.ArticleDao;
import com.fooffer.fooBackEnd.model.entity.ArticleTagDao;
import com.fooffer.fooBackEnd.model.vo.ArticleResponseVo;
import com.fooffer.fooBackEnd.repository.ArticleContentRepository;
import com.fooffer.fooBackEnd.repository.ArticleRepository;
import com.fooffer.fooBackEnd.repository.ArticleTagRepository;
import com.fooffer.fooBackEnd.service.intf.ArticleService;
import com.fooffer.fooBackEnd.service.intf.UserInformationService;
import com.fooffer.fooBackEnd.utils.RedisUtil;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.fooffer.fooBackEnd.constant.articles.ArticleRequestConstant.ARTICLE_VIEW_EXPIRED_TIME;
import static com.fooffer.fooBackEnd.utils.NumConvertUtil.encode10To62;


/**
 * 实现Article Service接口的方法
 */
@Service
@AllArgsConstructor
@Slf4j
public class ArticleServiceImpl implements ArticleService {

    private final ArticleRepository articleRepository;

    private final ArticleContentRepository articleContentRepository;

    private final ArticleTagRepository articleTagRepository;

    private final ArticleMapper articleMapper;

    private final UserInformationService userInformationService;


    @Override
    public ArticleResponseVo getArticle(String articleId) throws InvalidArticleIdException {
        return null;
    }

    @Override
    public ArticleResponseVo getArticle(
            String articleId,
            String ip
    ) throws InvalidArticleIdException {

        //check whether articleId contain invalid character
        if (!isArticleIdValid(articleId)) {
            throw new InvalidArticleIdException(articleId);
        }

        Long dbId = Long.parseLong(articleId);

        String ipArticleIdKey = String.format("%s :article: %s", ip, articleId);

        //  在Redis 中检查是否存在:IP+文章ID
        if(!RedisUtil.hasKey(ipArticleIdKey)){
            incrementService(ipArticleIdKey, articleId, ip);
        }

        ArticleDao articleDao = articleRepository.findArticleDaoByArticleIdAndIsDeletedIsFalse(dbId);
        if (articleDao == null || articleDao.getIsDeleted()) {
            return null;
        }

        ArticleContentDao contentDao = articleContentRepository.findArticleContentDaoByContentId(articleDao.getContentId());

        List<ArticleTagDao> tagDaoList = new ArrayList<>();

        // article + articleContent dao填充article dto
        ArticleDto assembledArticleDto = assembleArticleDto(articleDao, contentDao, tagDaoList);

        // 转换成vo
        return articleMapper.dto2vo(assembledArticleDto);
    }

    /**
     * 将多个dao拼装起来放在article dto中返回
     * @param articleDao
     * @param articleContentDao
     * @param tagDaoList
     * @return 具备所有信息的Article Dto
     */
    private ArticleDto assembleArticleDto(
            ArticleDao articleDao,
            ArticleContentDao articleContentDao,
            List<ArticleTagDao> tagDaoList
    ) {
        ArticleDto assembledArticleDto = articleMapper.mergeDao2dto(
                articleDao,
                articleContentDao,
                tagDaoList
        );

        // 获得作者的信息
        assembledArticleDto.setArticleAuthor(
                getArticleAuthorByAuthorId(articleDao.getAuthorId())
        );

        return assembledArticleDto;
    }

    /**
     * 根据作者的id获取到作者其他信息
     * @param authorId 作者id
     * @return 文章中作者的dto
     */
    @Override
    public ArticleAuthor getArticleAuthorByAuthorId(
            Long authorId
    ) {
        UserInformationDto userInformationDto = userInformationService.getUserInformationDtoByUserId(authorId);

        return ArticleAuthor.builder()
                .authorId(encode10To62(authorId, 10))
                .nickname(userInformationDto.getNickname())
                .avatarLink(userInformationDto.getAvatarLink())
                .motto(userInformationDto.getMotto())
                .build();
    }

    public void incrementService(String ipArticleIdKey, String articleId, String ip) {
        RedisUtil.set(ipArticleIdKey,"true", ARTICLE_VIEW_EXPIRED_TIME, TimeUnit.SECONDS);
        String viewCountKey = String.format("viewCount: %s", articleId);
        // 统计总浏览量（包括重复的访问）
        if (!RedisUtil.hasKey(viewCountKey)) {
            RedisUtil.set(viewCountKey, 1, ARTICLE_VIEW_EXPIRED_TIME, TimeUnit.SECONDS);
        } else {
            // 在 Redis 中递增浏览量
            RedisUtil.increment(viewCountKey, 1);
        }
        // 添加一条view count记录，值为ip， 统计独特访客数量（不计算重复的访问）
        String viewCountHyperloglogKey = String.format("viewCountHLL:%s", articleId);
        RedisUtil.addHyperloglog(viewCountHyperloglogKey, ip);
    }
    @Override
    public long getUniqViewCount(String viewCountKey) {
        return RedisUtil.countHyperloglog(viewCountKey);
    }

    /**
     * 同步redis中的文章浏览量到mongodb
     *
     */
    @Override
    @Scheduled(cron = "0 0 0 * * *")// Run every day
    @Transactional(rollbackFor = Exception.class)
    @Retryable(value = Throwable.class, maxAttempts = 3, backoff = @Backoff(delay = 1000))
    public void synchronizeViewCounts() {
        List<ArticleDao> articles = articleRepository.findAll();
        for (ArticleDao article : articles) {
            String viewCountKey = "viewCount:" + article.getArticleId();
            Integer viewCount = (Integer) RedisUtil.get(viewCountKey);
            if (viewCount != null) {
                article.setViewCount(article.getViewCount()+viewCount);
                articleRepository.save(article);
                // Delete data from Redis
                RedisUtil.delete(viewCountKey);
            }
        }
    }

    /**
     * 根据ArticleDao里面的数据获得文章所属所有标签dao的数据
     * @param articleDao dao的数据
     * @return List<ArticleTagDao>
     */
    public List<ArticleTagDao> getTagDaoList(ArticleDao articleDao){
        // get tag DAOs by tag id list
        List<ArticleTagDao> tagDaoList = articleDao.getArticleTagList();

        return tagDaoList;
    }

    /**
     * 检验articleId是否有效
     * @param articleId 请求文章的id
     * @return boolean，true表示有效
     */
    private boolean isArticleIdValid(String articleId) {
        if (!articleId.matches("\\d+")) {
            return false;
        }
        return true;
    }

}
