package com.fooffer.fooBackEnd.model.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Builder;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 对应数据库中的users collection
 * 用户登录信息保存在**Auth中
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document(collection = "users")
public class UserDao {


    @Id
    private ObjectId _id;
    /**
     * 逻辑主键
     */
    private Long userId;

    /*
     * 用户名称
     */
    private String userEmail;

    /**
     * 用户身份
     */
    @Field(value = "roles")
    private List<UserRoleDao> userRoleDaoList;

    /**
     * 用户发表过的文章id list
     */
    private List<Long> articleIds;

    /**
     * 对应的用户Info
     */
    private Long userInformationId;

    /**
     * 使用Email注册的用户的注册信息
     */
    private Long emailAuthId;

    /**
     * 用户注册日期
     */
    private LocalDateTime registrationDate;

    /**
     * 对应的邀请人id
     * 若该账号为自己注册，则值为-1
     */
    private Long referUserId;
}
