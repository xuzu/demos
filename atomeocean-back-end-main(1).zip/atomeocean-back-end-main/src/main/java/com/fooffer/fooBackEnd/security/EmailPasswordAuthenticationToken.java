package com.fooffer.fooBackEnd.security;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.util.Assert;

import java.util.Collection;

/**
 * 在用户使用邮箱+密码登录的过程中，提供身份验证的token
 */
public class EmailPasswordAuthenticationToken extends
        AbstractAuthenticationToken {

    // 邮箱
    private final Object principal;

    // 邮箱登录时的密码信息
    private Object credentials;

    /**
     * 未验证邮箱初始化权限为空，并设置不可信
     * @param principal 邮箱和密码信息
     */
    public EmailPasswordAuthenticationToken(
            Object principal,
            Object credentials
    ) {
        super(null);
        this.principal = principal;
        this.credentials = credentials;
        setAuthenticated(false);
    }

    /**
     * Authorization filter中使用
     * @param principal
     * @param credentials
     * @param authorities
     */
    public EmailPasswordAuthenticationToken(
            Object principal,
            Object credentials,
            Collection<? extends GrantedAuthority> authorities

    ) {
        super(authorities);
        this.principal = principal;
        this.credentials = credentials;
        super.setAuthenticated(true);
    }

    @Override
    public Object getCredentials() {
        return this.credentials;
    }

    @Override
    public Object getPrincipal() {
        return this.principal;
    }

    @Override
    public void setAuthenticated(boolean isAuthenticated) throws IllegalArgumentException {
        Assert.isTrue(!isAuthenticated,
                "Cannot set this token to trusted - use constructor which takes a GrantedAuthority list instead");
        super.setAuthenticated(false);
    }

    @Override
    public void eraseCredentials() {
        super.eraseCredentials();
        this.credentials = null;
    }
}
