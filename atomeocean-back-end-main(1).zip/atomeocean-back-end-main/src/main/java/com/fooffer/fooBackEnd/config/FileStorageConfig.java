package com.fooffer.fooBackEnd.config;

import io.minio.MinioClient;
import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 文件存储配置
 */
@Data
@Configuration
public class FileStorageConfig {
    /**
     * URL，域名，IPv4或者IPv6地址
     */
    @Value("${file-storage.endpoint}")
    private String endpoint;

    /**
     *  accessKey类似于用户ID，用于唯一标识账户
     */
    @Value("${file-storage.accessKey}")
    private String accessKey;

    /**
     *  账户密码
     */
    @Value("${file-storage.secretKey}")
    private String secretKey;

    /**
     *  存储桶名称
     */
    @Value("${file-storage.bucket-name}")
    private String bucketName;

    /**
     *  图片最大大小
     */
    @Value("${file-storage.image-size}")
    private long imageSize;

    /**
     *  文件最大大小
     */
    @Value("${file-storage.file-size}")
    private long fileSize;

    @Bean
    public MinioClient minioClient() {
        MinioClient minioClient = MinioClient.builder()
                        .credentials(accessKey, secretKey)
                        .endpoint(endpoint)
                        .build();
        return minioClient;
    }
}
