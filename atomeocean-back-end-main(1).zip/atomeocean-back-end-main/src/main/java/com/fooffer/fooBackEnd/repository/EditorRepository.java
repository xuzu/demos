package com.fooffer.fooBackEnd.repository;

import com.fooffer.fooBackEnd.model.entity.ArticleDao;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * 将Editor传递给后端的内容保存到数据库中
 */
@Repository
public interface EditorRepository extends MongoRepository<ArticleDao, Long> {

    /**
     * 根据id查询article dao
     * @param articleId 请求的article id
     * @return 带有article id的Dao
     */
    Optional<ArticleDao> findArticleDaoByArticleId(Long articleId);

    /*
     * 根据逻辑主键查询有效的article
     */
    ArticleDao findArticleDaoByArticleIdAndIsDeletedIsFalse(Long articleId);
}
