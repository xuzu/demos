package com.fooffer.fooBackEnd.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ArticleCategoryDto {

    private Long articleCategoryId;

    private String name;
}
