package com.fooffer.fooBackEnd.model.dto;

import lombok.Data;
import lombok.Builder;

import java.util.List;

/**
 * 动态路由表DTO
 */
@Data
@Builder
public class DynamicRouteDto {
    // 逻辑主键
    private Integer dynamicRouteId;

    private String path;

    private String name;

    // 路由对应组件
    private String component;

    // 父节点id
    private Integer parentRouteId;

    // 子路由id列表
    private List<Integer> childrenRoutes;
}
