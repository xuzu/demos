package com.fooffer.fooBackEnd.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * 测试权限控制器
 */
@RestController
@RequestMapping("/tasks")
public class TaskController {

    @GetMapping
    public String listTasks() {
        return "任务列表";
    }

    @PreAuthorize("hasAuthority('ROLE_MANAGER')")
    @PostMapping
    public String newTasks() {
        return "创建了一个新任务";
    }

    @PutMapping("/{taskId}")
    public String updateTasks(@PathVariable("taskId")Integer id) {
        return "更新了一下id为:" + id+ "的任务";
    }

    @DeleteMapping("/{taskId}")
    public String deleteTasks(@PathVariable("taskId")Integer id) {
        return "删掉了id为:" + id + "的任务";
    }
}
