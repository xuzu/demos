package com.fooffer.fooBackEnd.service.impl.creditSet;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fooffer.fooBackEnd.constant.ErrorReason;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.exception.cause.ExceptionCause;
import com.fooffer.fooBackEnd.mapper.creditSet.UserCreditSetMapper;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.dto.creditSet.UserCreditSetDto;
import com.fooffer.fooBackEnd.model.entity.creditSet.ShellTransactionStatementDao;
import com.fooffer.fooBackEnd.model.entity.creditSet.UserCreditSetDao;
import com.fooffer.fooBackEnd.model.vo.creditSet.UserCreditSetVo;
import com.fooffer.fooBackEnd.repository.creditSet.ShellTransactionStatementRepository;
import com.fooffer.fooBackEnd.repository.creditSet.UserCreditSetRepository;
import com.fooffer.fooBackEnd.service.intf.creditSet.ShellTransactionStatementService;
import com.fooffer.fooBackEnd.service.intf.creditSet.UserCreditSetService;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.util.Optional;

import static com.fooffer.fooBackEnd.constant.ReturnCode.ACCOUNT_NOT_EXIST;
import static com.fooffer.fooBackEnd.constant.ReturnCode.INSUFFICIENT_CREDIT;
import static com.fooffer.fooBackEnd.constant.credits.ShellConstants.DEFAULT_SHELL_CREDIT;

@Service
@AllArgsConstructor
@Slf4j
public class UserCreditSetServiceImpl implements UserCreditSetService {

    private final UserCreditSetRepository userCreditSetRepository;
    private final ShellTransactionStatementRepository shellTransactionStatementRepository;
    private final UserCreditSetMapper userCreditSetMapper;
    private final ShellTransactionStatementService shellTransactionStatementService;

    /**
     * 根据userId返回用户creditSetDao
     * 
     * @param userId
     * @return UserCreditSetDao
     */
    @Override
    public UserCreditSetDao getUserCreditSetDaoByUserId(Long userId) throws BaseException {
        Optional<UserCreditSetDao> optionalUserCreditSetDao = userCreditSetRepository.findUserCreditSetDaoByUserId(userId);
        //若该账户为创建积分dao，则为其创建
        if(!optionalUserCreditSetDao.isPresent()){
            //获取用户id
            Long currentUserId = (Long) SecurityContextHolder.getContext().getAuthentication().getDetails();
            //创建并保存积分dao
            UserCreditSetDao userCreditSetDao = UserCreditSetDao.builder()
                    .userId(currentUserId)
                    .shell(DEFAULT_SHELL_CREDIT)
                    .build();

            userCreditSetRepository.save(userCreditSetDao);

            //返回对应dao
            return userCreditSetDao;
        }

        return optionalUserCreditSetDao.get();
    }

    /**
     * 根据userId返回用户creditSetDto
     * 
     * @param userId
     * @return UserCreditSetDto
     */
    @Override
    public UserCreditSetDto getUserCreditSetDtoByUserId(Long userId) throws BaseException {
        UserCreditSetDao userCreditSetDao = getUserCreditSetDaoByUserId(userId);
        UserCreditSetDto userCreditSetDto = userCreditSetMapper.dao2dto(userCreditSetDao);
        return userCreditSetDto;
    }

    /**
     * 根据userId返回用户creditSetVo
     * 
     * @param userId
     * @return UserCreditSetVo
     */
    @Override
    public UserCreditSetVo getUserCreditSetVoByUserId(Long userId) throws BaseException {
        UserCreditSetDto userCreditSetDto = getUserCreditSetDtoByUserId(userId);
        UserCreditSetVo userCreditSetVo = userCreditSetMapper.dto2vo(userCreditSetDto);
        return userCreditSetVo;
    }

    /**
     * 为该userId添加积分
     * 
     * @param userId      用户id
     * @param amount      修改积分数量，正数为增加，负数为减少
     * @param description 本次修改积分的说明，用于修改记录
     * @return ResultData 如果成功则返回新的积分余额
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public ResultData modifyCredit(Long userId, Long amount, String description) throws BaseException {
        UserCreditSetDao userCreditSetDao = getUserCreditSetDaoByUserId(userId);
        Long newShellBalance = userCreditSetDao.getShell() + amount;

        // 用户积分余额不足
        if (newShellBalance < 0) {
            return ResultData.fail(INSUFFICIENT_CREDIT.getCode(), INSUFFICIENT_CREDIT.getMessage());
        }

        //修改用户积分
        userCreditSetDao.setShell(newShellBalance);
        userCreditSetRepository.save(userCreditSetDao);

        // 添加积分明细记录
        ShellTransactionStatementDao shellTransactionStatementDao = shellTransactionStatementService.generateShellTransactionStatement(userId,
                amount, LocalDateTime.now(), description);
        shellTransactionStatementRepository.save(shellTransactionStatementDao);
        
        return ResultData.success(newShellBalance);
    }

}