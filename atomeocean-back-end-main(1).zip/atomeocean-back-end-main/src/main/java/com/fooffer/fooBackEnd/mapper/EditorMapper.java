package com.fooffer.fooBackEnd.mapper;

import com.fooffer.fooBackEnd.model.dto.editor.EditorDto;
import com.fooffer.fooBackEnd.model.entity.ArticleContentDao;
import com.fooffer.fooBackEnd.model.entity.ArticleDao;
import com.fooffer.fooBackEnd.model.vo.EditorVo;
import org.mapstruct.*;

/**
 * 转换editor data object
 * 设定mapping strategy，如果source为null，忽略该变量的map
 */
@Mapper(
        componentModel = "spring",
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
)
public interface EditorMapper {

    /**
     * vo -> dto
     * @param editorVo 前段editor请求中的payload
     * @return EditorDto
     */
    @Mappings(
            @Mapping(source = "editorVo.addTagArray", target = "articleTagList")
    )
    EditorDto vo2dto(EditorVo editorVo);

    /**
     * editorDto -> articleDao
     * @param editorDto editor请求的dto
     * @return article dao 保存到article collection (db)
     */
    ArticleDao dto2dao(EditorDto editorDto);

    /**
     * 用新的dto更新已有的article dao
     * @param articleDao 需要被更新的dao，添加target注解
     * @param editorDto 存放新值的dto
     */
    void updateArticleDaoFromEditorDto(
            @MappingTarget ArticleDao articleDao,
            EditorDto editorDto
    );

    /**
     * 新的article dto更新已有的article content dao
     * @param articleContentDao 目标文章的content dao
     * @param editorDto 存放新值的dto
     */
    void updateArticleContentDaoFromEditorDto(
            @MappingTarget ArticleContentDao articleContentDao,
            EditorDto editorDto
    );

    /**
     * article dto -> article content dao
     * @param editorDto 含有id，文本等信息
     * @return article content dao，绑定content collection
     */
    ArticleContentDao dto2ContentDao(EditorDto editorDto);
}
