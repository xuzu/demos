package com.fooffer.fooBackEnd.service.intf;

import com.fooffer.fooBackEnd.constant.ResourceOperationType;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.model.vo.EditorVo;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public interface EditorService {

    /**
     * 将前端提交的文章保存到数据库里面
     * 需要附上上传时间，作者信息等
     *
     * @param operationType 根据操作类型决定是新增，更新或是删除文章
     */
    void saveAnArticle(
            EditorVo editorVo,
            ResourceOperationType operationType
    );

    /**
     * 接收上传的文章封面图片并生成链接
     * @param coverImage
     * @param imageHash
     * @return
     * @throws BaseException
     */
    String updateCoverImage(
            MultipartFile coverImage,
            String imageHash
    ) throws BaseException;
}
