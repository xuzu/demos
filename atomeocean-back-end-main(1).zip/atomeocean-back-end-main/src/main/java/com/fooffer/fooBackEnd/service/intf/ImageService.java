package com.fooffer.fooBackEnd.service.intf;

import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.model.entity.ImageDao;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public interface ImageService {

    /**
     * 根据图片的id获取图片的信息
     * @param imageId
     * @return
     */
    ImageDao getImageDaoByImageId(Long imageId);

    /**
     * 根据上传的文件对数据库进行更新
     *
     * @param image 用户上传的图片
     * @param hash 图片hash值
     * @return ImageDao
     */
    ImageDao uploadImage(MultipartFile image, String hash) throws BaseException;

    /**
     * 根据输入的id更新对应图片文件的引用次数
     *
     * @param imageId 图片Id
     * @param citationCounter 该图片引用次数的变化量
     */
    void updateCitation(Long imageId, int citationCounter);
}
