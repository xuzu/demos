package com.fooffer.fooBackEnd.controller.creditSet;


import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.vo.creditSet.UserCreditSetVo;
import com.fooffer.fooBackEnd.service.intf.creditSet.UserCreditSetService;
import com.fooffer.fooBackEnd.utils.NumConvertUtil;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.*;

/**
 * 用户积分系统接口
 */
@RestController
@AllArgsConstructor
@RequestMapping("/credit")
@Slf4j
public class UserCreditSetController {
    private final UserCreditSetService userCreditSetService;

    private final NumConvertUtil numConvertUtil;


    /**
     * 查询用户积分接口
     * @param encodedUserId userId
     * @return 用户当前积分明细
     */
    @GetMapping("/lookup")
    public ResultData lookup(
        @RequestParam(name = "encodedUserId") String encodedUserId
    ) {
        long userId = numConvertUtil.decode62To10(encodedUserId);
        UserCreditSetVo userCreditSetVo = userCreditSetService.getUserCreditSetVoByUserId(userId);
        return ResultData.success(userCreditSetVo);
    }

    /**
     * 修改用户积分接口
     * @param encodedUserId userId
     * @param amount 修改积分数量，正数表示增加，负数表示减少
     * @param description 本次积分修改的说明，用于积分修改记录
     * @return 如果操作成功则返回新的积分余额
     */
    @PostMapping("/modify")
    public ResultData modify(
        @RequestParam(name = "encodedUserId") String encodedUserId,
        @RequestParam(name = "amount") Long amount,
        @RequestParam(name = "description") String description
    ) {
        long userId = numConvertUtil.decode62To10(encodedUserId);
        return userCreditSetService.modifyCredit(userId, amount, description);
    }

}
