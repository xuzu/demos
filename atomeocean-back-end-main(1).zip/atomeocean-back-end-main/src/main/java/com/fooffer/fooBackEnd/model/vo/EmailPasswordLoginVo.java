package com.fooffer.fooBackEnd.model.vo;

import lombok.Data;

/**
 * 接收email password登录请求参数
 */
@Data
public class EmailPasswordLoginVo {
    private String userEmail;
    private String password;

}
