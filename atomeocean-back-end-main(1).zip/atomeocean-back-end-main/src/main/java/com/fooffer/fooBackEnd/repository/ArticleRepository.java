package com.fooffer.fooBackEnd.repository;

import com.fooffer.fooBackEnd.model.entity.ArticleDao;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

/**
 * 操作mongodb中article collection
 * 扩展接口的时候需要把id类型改成Long
 */
@Repository
public interface ArticleRepository extends MongoRepository<ArticleDao, Long> {

    /*
     * 根据逻辑主键查询有效的article
     */
    ArticleDao findArticleDaoByArticleIdAndIsDeletedIsFalse(Long articleId);

    /**
     * 根据作者id查询该作者发布过的所有文章
     * @param authorId 作者的userid
     * @return 返回该作者文章查询的分页结果
     */
    Page<ArticleDao> findArticleDaoByAuthorIdAndIsDeletedIsFalse(Long authorId, Pageable pageable);
}
