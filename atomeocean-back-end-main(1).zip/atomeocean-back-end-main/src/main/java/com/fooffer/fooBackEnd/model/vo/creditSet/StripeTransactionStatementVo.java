package com.fooffer.fooBackEnd.model.vo.creditSet;

import com.fooffer.fooBackEnd.constant.stripe.Currency;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class StripeTransactionStatementVo {

    private String stripeTransactionStatementId;

    private Long amount;

    private Currency currency;

    private LocalDateTime timestamp;

    private String receiptUrl;
}
