package com.fooffer.fooBackEnd.service.intf;

import com.fooffer.fooBackEnd.model.vo.DynamicRouteVo;
import com.fooffer.fooBackEnd.model.vo.UserRoleVo;
import org.springframework.stereotype.Service;

/**
 * 动态路由表service
 */
@Service
public interface DynamicRouteService {

    /**
     * 根据角色读取符合权限的路由表
     */
    DynamicRouteVo getDynamicRoutesByDynamicRouteId(Integer dynamicRouteId);
}
