package com.fooffer.fooBackEnd.model.vo;


import com.fooffer.fooBackEnd.constant.ResourceOperationType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;


/**
 * 前端发送用户工作经历的封装类
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CareerVo {

    private Long careerId;

    private ResourceOperationType operationType;

    //公司名
    private String companyName;

    //职位名
    private String position;

    //开始日期
    private LocalDate startDate;

    //结束日期
    private LocalDate endDate;

    //是否已经离职，如果是false那么前端显示结束日期为“至今”
    private Boolean isCompleted;
}
