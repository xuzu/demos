package com.fooffer.fooBackEnd.constant.credits;

public class ShellConstants {
    public static Long DEFAULT_SHELL_CREDIT = 0L;
    public static String RECHARGE = "贝壳积分变动为充值所得";
}
