package com.fooffer.fooBackEnd.model.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 接收Editor上传文章中的Article Tag参数
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ArticleTagVo {

    private String title;

    private String type;
}
