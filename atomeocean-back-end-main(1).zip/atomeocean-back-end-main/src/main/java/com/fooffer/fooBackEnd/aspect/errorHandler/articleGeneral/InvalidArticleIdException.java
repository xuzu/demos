package com.fooffer.fooBackEnd.aspect.errorHandler.articleGeneral;

import com.fooffer.fooBackEnd.constant.ReturnCode;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.exception.cause.ExceptionCause;
import com.fooffer.fooBackEnd.constant.ErrorReason;

/**
 * Article Id 不合法异常
 */
public class InvalidArticleIdException extends BaseException {


    public InvalidArticleIdException(ReturnCode returnCode, String message) {
        super(returnCode, new ExceptionCause("Article", ErrorReason.ARTICLE_INVALID), message);
    }

    public InvalidArticleIdException(ReturnCode returnCode, String message, Throwable cause) {
        super(returnCode, new ExceptionCause("Article", ErrorReason.ARTICLE_INVALID), message, cause);
    }

    public InvalidArticleIdException(String message) {
        super(ReturnCode.RC400, new ExceptionCause("Article", ErrorReason.ARTICLE_INVALID), message);
    }

    public ErrorReason getErrorCause() {
        return (ErrorReason) getExceptionCause().getErrorReason();
    }
}

