package com.fooffer.fooBackEnd.service.impl;

import com.fooffer.fooBackEnd.constant.ErrorReason;
import com.fooffer.fooBackEnd.constant.userInformation.UserInformationVisibility;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.exception.cause.ExceptionCause;
import com.fooffer.fooBackEnd.mapper.EmailAuthMapper;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.dto.EmailAuthDto;
import com.fooffer.fooBackEnd.model.entity.EmailAuthDao;
import com.fooffer.fooBackEnd.model.entity.creditSet.UserCreditSetDao;
import com.fooffer.fooBackEnd.model.entity.UserDao;
import com.fooffer.fooBackEnd.model.entity.UserRoleDao;
import com.fooffer.fooBackEnd.model.entity.UserInformationDao;
import com.fooffer.fooBackEnd.model.vo.EmailAuthVo;
import com.fooffer.fooBackEnd.repository.EmailAuthRepository;
import com.fooffer.fooBackEnd.repository.creditSet.UserCreditSetRepository;
import com.fooffer.fooBackEnd.repository.UserRepository;
import com.fooffer.fooBackEnd.repository.UserInformationRepository;
import com.fooffer.fooBackEnd.service.intf.UserRegisterService;
import com.fooffer.fooBackEnd.utils.EmailSenderUtil;
import com.fooffer.fooBackEnd.utils.RedisUtil;
import com.fooffer.fooBackEnd.utils.SnowflakeIdWorker;
import com.fooffer.fooBackEnd.utils.VerificationCodeUtil;
import com.fooffer.fooBackEnd.utils.NumConvertUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import static com.fooffer.fooBackEnd.constant.ReturnCode.*;
import static com.fooffer.fooBackEnd.constant.UserRoles.ROLE_MEMBER_ID;
import static com.fooffer.fooBackEnd.constant.credits.ShellConstants.DEFAULT_SHELL_CREDIT;
import static com.fooffer.fooBackEnd.constant.user.RegisterConstant.EXPIRED_TIME;

@Service
@Slf4j
public class UserRegisterServiceImpl implements UserRegisterService {

    private final UserRepository userRepository;

    private final EmailAuthRepository emailAuthRepository;

    private final UserInformationRepository userInformationRepository;

    private final UserCreditSetRepository userCreditSetRepository;

    private final BCryptPasswordEncoder bCryptPasswordEncoder;

    private final EmailAuthMapper emailAuthMapper;

    private final SnowflakeIdWorker snowflakeIdWorker;

    private final NumConvertUtil numConvertUtil;

    public UserRegisterServiceImpl(
            UserRepository userRepository,
            EmailAuthRepository emailAuthRepository,
            BCryptPasswordEncoder bCryptPasswordEncoder,
            EmailAuthMapper emailAuthMapper,
            UserInformationRepository userInformationRepository,
            NumConvertUtil numConvertUtil,
            UserCreditSetRepository userCreditSetRepository
    ) {
        this.userRepository = userRepository;
        this.emailAuthRepository = emailAuthRepository;
        this.bCryptPasswordEncoder = bCryptPasswordEncoder;
        this.emailAuthMapper = emailAuthMapper;
        this.userInformationRepository = userInformationRepository;
        this.numConvertUtil = numConvertUtil;
        this.snowflakeIdWorker = new SnowflakeIdWorker(7L, 6L);
        this.userCreditSetRepository = userCreditSetRepository;
    }

    /*
     * 将新注册未验证的账号缓存到Redis中等待验证
     * @param emailAuthVo 前端提交的新用户信息
     * @return ResultData 包含状态码以及对应信息
     * */
    @Override
    public ResultData saveUnverifiedNewUser(EmailAuthVo emailAuthVo) throws BaseException {
        //验证该用户是否已经注册过
        Optional<EmailAuthDao> optionalEmailAuthDao = emailAuthRepository.findEmailAuthDaoByUserEmail(emailAuthVo.getUserEmail());
        if(optionalEmailAuthDao.isPresent()) {
            ExceptionCause exceptionCause = new ExceptionCause("sign up", ErrorReason.ACCOUNT_EXIST);
            throw new BaseException(ACCOUNT_EXIST, exceptionCause);
        }

        //加密密码
        String encodedPassword = bCryptPasswordEncoder.encode(emailAuthVo.getPassword());
        emailAuthVo.setPassword(encodedPassword);

        //判断账户是否已在缓存
        String existingCode = (String) RedisUtil.get(emailAuthVo.getUserEmail());
        if(existingCode != null){
            //判断用户是否修改了密码，如果密码被修改，则更新redis中的数据
            EmailAuthVo existingInfo = (EmailAuthVo) RedisUtil.get(emailAuthVo.getUserEmail() + " " + existingCode);
            if(!existingInfo.getPassword().equals(emailAuthVo.getPassword())) {
                //更新redis中的信息
                RedisUtil.set(emailAuthVo.getUserEmail(), existingCode, EXPIRED_TIME, TimeUnit.SECONDS);
                RedisUtil.set(emailAuthVo.getUserEmail() + " " + existingCode, emailAuthVo, EXPIRED_TIME, TimeUnit.SECONDS);
            }
            //发送邮件，返回提示
            EmailSenderUtil.sendVerificationEmail(emailAuthVo.getUserEmail(), existingCode, "verification");
            return ResultData.success("验证邮件已发送到您的邮箱，请验证您的账号，验证邮件有效期为15分钟");
        }

        //生成验证码并发送
        VerificationCodeUtil.sendVerificationCodeEmail(emailAuthVo, EXPIRED_TIME, TimeUnit.SECONDS, "verification");
        
        //验证用户refer链接是否有效
        Long referUserId = Long.parseLong(emailAuthVo.getReferIdString());
        if(referUserId == -1){
            return ResultData.success("验证码已发送到您的邮箱，请验证您的账号，验证码有效期为15分钟");
        }
        UserDao referUser = userRepository.findUserDaoByUserId(referUserId);
        if(referUser == null){
            ExceptionCause exceptionCause = new ExceptionCause("sign up", ErrorReason.INVALID_REFER);
            throw new BaseException(INVALID_REFER_ID, exceptionCause);
        }
        else{
            return ResultData.success("验证码已发送到您的邮箱，请验证您的账号，验证码有效期为15分钟");
        }
    }

    /*
     * 验证邮箱，验证成功后存入数据库
     * @param email 用户注册邮箱
     * @param code 验证用户账户的验证码
     * @return ResultData 包含状态码以及对应信息
     * */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public ResultData saveVerifiedNewUser(String email, String code) throws BaseException {
        
        //检查验证码
        EmailAuthVo emailAuthVo = VerificationCodeUtil.verifyCode(email, code, "sign up");

        //验证无误，到下一步 
        EmailAuthDto emailAuthDto = emailAuthMapper.vo2dto(emailAuthVo);
        Long emailAuthId= snowflakeIdWorker.nextId();
        emailAuthDto.setEmailAuthId(emailAuthId);
        Long userId = snowflakeIdWorker.nextId();
        Long userInformationId = snowflakeIdWorker.nextId();
        emailAuthDto.setUserId(userId);

        EmailAuthDao emailAuthDao = emailAuthMapper.dto2dao(emailAuthDto);

        //转换referId
        Long referUserId = Long.parseLong(emailAuthVo.getReferIdString());
        //创建对应的UserDao
        UserDao userDao = convertUserDaoFromEmailAuthDao(emailAuthDao, referUserId, userInformationId);
        //创建对应的UserInformationDao
        UserInformationDao userInformationDao = convertUserInformationDaoFromUserDao(userDao);
        //创建对应的UserCreditSetDao
        UserCreditSetDao userCreditSetDao = convertUserCreditSetDaoFromUserDao(userDao);
        //保存进数据库
        emailAuthRepository.save(emailAuthDao);
        userRepository.save(userDao);
        userInformationRepository.save(userInformationDao);
        userCreditSetRepository.save(userCreditSetDao);

        return ResultData.success("恭喜您注册成功!");
    }

    /**
     * 保存新用户UserDao信息
     * @param emailAuthDao 用户邮箱注册信息
     */
    private UserDao convertUserDaoFromEmailAuthDao(EmailAuthDao emailAuthDao, Long referUserId, Long userInformationId) {
        // 新注册用户获得member role
        List<UserRoleDao> userRoleDaos = List.of(
                UserRoleDao.builder()
                        .roleId(ROLE_MEMBER_ID)
                        .roleName("ROLE_MEMBER")
                        .build());

        return UserDao.builder()
                .userId(emailAuthDao.getUserId())
                .emailAuthId(emailAuthDao.getEmailAuthId())
                .userRoleDaoList(userRoleDaos)
                .userInformationId(userInformationId)
                .registrationDate(LocalDateTime.now())
                .referUserId(referUserId)
                .build();
    }

    //根据User生成UserInformation
    private UserInformationDao convertUserInformationDaoFromUserDao(UserDao userDao) {
        String username = "user" + numConvertUtil.encode10To62(userDao.getUserId(),10);

        return UserInformationDao
                .builder()
                .userId(userDao.getUserId())
                .userInformationId(userDao.getUserInformationId())
                .nickname(username)
                .careerIdSet(new HashSet<>())
                .educationIdSet(new HashSet<>())
                .userInformationVisibility(UserInformationVisibility.EVERY_ONE_CAN_SEE)
                .build();
    }


    //根据User生成UserCreditSet
    private UserCreditSetDao convertUserCreditSetDaoFromUserDao(UserDao userDao) {

        return UserCreditSetDao
                .builder()
                .userId(userDao.getUserId())
                .shell(DEFAULT_SHELL_CREDIT)
                .build();
    }
}
