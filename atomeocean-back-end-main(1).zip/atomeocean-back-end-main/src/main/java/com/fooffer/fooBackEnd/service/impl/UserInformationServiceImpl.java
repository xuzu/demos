package com.fooffer.fooBackEnd.service.impl;

import com.fooffer.fooBackEnd.constant.ErrorReason;
import com.fooffer.fooBackEnd.constant.userInformation.UserInformationVisibility;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.exception.cause.ExceptionCause;
import com.fooffer.fooBackEnd.mapper.CareerMapper;
import com.fooffer.fooBackEnd.mapper.EducationMapper;
import com.fooffer.fooBackEnd.mapper.UserInformationMapper;
import com.fooffer.fooBackEnd.model.dto.CareerDto;
import com.fooffer.fooBackEnd.model.dto.EducationDto;
import com.fooffer.fooBackEnd.model.dto.UserInformationDto;
import com.fooffer.fooBackEnd.model.entity.CareerDao;
import com.fooffer.fooBackEnd.model.entity.EducationDao;
import com.fooffer.fooBackEnd.model.entity.ImageDao;
import com.fooffer.fooBackEnd.model.entity.UserInformationDao;
import com.fooffer.fooBackEnd.model.vo.ModifyProfileParamsVo;
import com.fooffer.fooBackEnd.model.vo.UserInformationVo;
import com.fooffer.fooBackEnd.repository.CareerRepository;
import com.fooffer.fooBackEnd.repository.EducationRepository;
import com.fooffer.fooBackEnd.repository.ImageRepository;
import com.fooffer.fooBackEnd.repository.UserInformationRepository;
import com.fooffer.fooBackEnd.service.intf.ImageService;
import com.fooffer.fooBackEnd.service.intf.UserInformationService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import static com.fooffer.fooBackEnd.constant.ConstantValues.DAYS_BETWEEN_NAME_MODIFY;
import static com.fooffer.fooBackEnd.constant.ReturnCode.ACCOUNT_NOT_EXIST;
import static com.fooffer.fooBackEnd.constant.ReturnCode.MODIFY_NAME_TOO_OFTEN;
import static com.fooffer.fooBackEnd.constant.security.AuthenticationConstant.ANONYMOUS_USER_PRINCIPLE;


/**
 * 用户信息接口实现
 */
@Service
@Slf4j
@AllArgsConstructor
public class UserInformationServiceImpl implements UserInformationService {

    private final UserInformationRepository userInformationRepository;

    private final ImageRepository imageRepository;

    private final EducationRepository educationRepository;

    private final CareerRepository careerRepository;

    private final ImageService imageService;

    private final UserInformationMapper userInformationMapper;

    private final EducationMapper educationMapper;

    private final CareerMapper careerMapper;

    /**
     * 根据用户id来查询用户信息
     * @param userId 需要查询的用户userId
     * @return UserInformationDto 用户非登录信息
     */
    @Override
    public UserInformationDto getUserInformationDtoByUserId(Long userId) {
        UserInformationDao userInformationDao = getUserInformationDaoByUserId(userId);
        UserInformationDto userInformationDto = convertUserInformationDaoToDto(userInformationDao);

        return userInformationDto;
    }

    /**
     * 根据用户Id返回UserInfoVo
     *
     * @param userId 用户id
     * @return 用户名对应的userInfo Vo
     */
    @Override
    public UserInformationVo getUserInformationVoByUserId(Long userId) {
        UserInformationDao userInformationDao = getUserInformationDaoByUserId(userId);

        //查看请求者登录状态
        Authentication authentication =  SecurityContextHolder.getContext().getAuthentication();

        UserInformationDto userInformationDto = null;

        if(authentication.getPrincipal().equals(ANONYMOUS_USER_PRINCIPLE) || !authentication.isAuthenticated()) {
            //未登录只能看对所有人公开的profile
            if(userInformationDao.getUserInformationVisibility() != UserInformationVisibility.EVERY_ONE_CAN_SEE){
                userInformationDto = convertUserInformationDaoToDtoWithoutPermission(userInformationDao);
            }
        }
        else{
            //登录后若查看非本账号且权限为仅自己可见的账号，拒绝访问
            Long currentUserId = (Long) authentication.getDetails();
            if((!currentUserId.equals(userId)) && userInformationDao.getUserInformationVisibility() == UserInformationVisibility.ONLY_SELF_CAN_SEE){
                userInformationDto = convertUserInformationDaoToDtoWithoutPermission(userInformationDao);
            }
        }

        if(userInformationDto == null){
            userInformationDto = convertUserInformationDaoToDto(userInformationDao);
        }
        UserInformationVo userInformationVo = userInformationMapper.dto2vo(userInformationDto);
        return userInformationVo;
    }

    /**

     * 根据用户id来查询用户信息
     * @param userId 需要查询的用户userId
     * @return UserInformationDao
     */
    @Override
    public UserInformationDao getUserInformationDaoByUserId(Long userId) {
        UserInformationDao userInformationDao = userInformationRepository.findUserInformationDaoByUserId(userId).orElseThrow(
                () -> new BaseException(
                        ACCOUNT_NOT_EXIST,
                        ExceptionCause.builder()
                                .domain("user profile")
                                .errorReason(ErrorReason.ACCOUNT_NOT_EXIST)
                                .build()
                )
        );

        return userInformationDao;
    }
     /**
     * 当无权限查看该用户信息时，仅返回基础资料
     *
     * @param userInformationDao
     *
     * @return 用户信息的dto
     */
    private UserInformationDto convertUserInformationDaoToDtoWithoutPermission(UserInformationDao userInformationDao){
        UserInformationDto userInformationDto = UserInformationDto.builder()
                .nickname(userInformationDao.getNickname())
                .motto(userInformationDao.getMotto())
                .visibilityId(userInformationDao.getUserInformationVisibility().getId())
                .build();
        if(userInformationDao.getAvatarId() != null){
            Optional<ImageDao> optionalImageDao = imageRepository.findImageDaoByImageId(userInformationDao.getAvatarId());
            optionalImageDao.ifPresent(imageDao -> userInformationDto.setAvatarLink(imageDao.getUrl()));
        }

        return userInformationDto;

    }

    /**
     * 根据用户id更新其头像
     *
     * @param avatarImage 用户上传的头像图片
     *
     * @return 用户更新后的头像链接
     */
    @Override
    public String updateAvatar(MultipartFile avatarImage, String imageHash) throws BaseException {
        //获取用户id
        Long userId = (Long) SecurityContextHolder.getContext().getAuthentication().getDetails();

        //获取该用户信息
        Optional<UserInformationDao> optionalUserInformationDao = userInformationRepository.findUserInformationDaoByUserId(userId);
        //如果用户id不存在，则抛出异常
        if(!optionalUserInformationDao.isPresent()) {
            ExceptionCause exceptionCause = new ExceptionCause("user profile", ErrorReason.ACCOUNT_NOT_EXIST);
            throw new BaseException(ACCOUNT_NOT_EXIST, exceptionCause);
        }

        //调用ImageService完成上传文件操作
        ImageDao imageDao = imageService.uploadImage(avatarImage, imageHash);
        //降低旧图片的引用量
        UserInformationDao userInformationDao = optionalUserInformationDao.get();
        if(userInformationDao.getAvatarId() != null) {
            imageService.updateCitation(userInformationDao.getAvatarId(), -1);
        }
        //将该用户的头像设为新图片
        userInformationDao.setAvatarId(imageDao.getImageId());
        userInformationRepository.save(userInformationDao);

        return imageDao.getUrl();
    }

    private UserInformationDto convertUserInformationDaoToDto(UserInformationDao userInformationDao){
        UserInformationDto userInformationDto = userInformationMapper.dao2dto(userInformationDao);
        if(userInformationDao.getAvatarId() != null){
            Optional<ImageDao> optionalImageDao = imageRepository.findImageDaoByImageId(userInformationDao.getAvatarId());
            optionalImageDao.ifPresent(imageDao -> userInformationDto.setAvatarLink(imageDao.getUrl()));
        }

        userInformationDto.setVisibilityId(userInformationDao.getUserInformationVisibility().getId());

        //通过Education id set 查询所有的教育经历
        Set<EducationDto> educationDtoSet = new HashSet<EducationDto>();
        if(userInformationDao.getEducationIdSet() != null){
            for (Long educationId : userInformationDao.getEducationIdSet()){
                Optional<EducationDao> optionalEducationDao = educationRepository.findEducationDaoByEducationId(educationId);
                optionalEducationDao.ifPresent(educationDao -> educationDtoSet.add(educationMapper.dao2dto(educationDao)));
            }
        }
        userInformationDto.setEducationDtoSet(educationDtoSet);

        //通过Career id set 查询所有的工作经历
        Set<CareerDto> careerDtoSet = new HashSet<CareerDto>();
        if(userInformationDao.getCareerIdSet() != null){
            for (Long careerId : userInformationDao.getCareerIdSet()){
                Optional<CareerDao> optionalCareerDao = careerRepository.findCareerDaoByCareerId(careerId);
                optionalCareerDao.ifPresent(careerDao -> careerDtoSet.add(careerMapper.dao2dto(careerDao)));
            }
        }
        userInformationDto.setCareerDtoSet(careerDtoSet);
        return userInformationDto;
    }

    /**
     * @param modifyProfileParamsVo 需要修改的值
     * @throws BaseException
     */
    @Override
    public void updateUserInformation(
            ModifyProfileParamsVo modifyProfileParamsVo
    ) throws NoSuchFieldException, IllegalAccessException {

        // 获取当前用户的user id
        Long currentUserId = (Long) SecurityContextHolder.getContext().getAuthentication().getDetails();

        String[] fieldsModified = modifyProfileParamsVo.getFieldsModified();

        Optional<UserInformationDao> optionalUserInformationDao = userInformationRepository.findUserInformationDaoByUserId(currentUserId);
        if (!optionalUserInformationDao.isPresent()) {
            ExceptionCause exceptionCause = new ExceptionCause("user profile", ErrorReason.ACCOUNT_NOT_EXIST);
            throw new BaseException(ACCOUNT_NOT_EXIST, exceptionCause);
        }

        UserInformationDao userInformationDao = optionalUserInformationDao.get();

        // 逐个更新用户提交的修改
        for (String fieldName: fieldsModified) {
            Field field = ModifyProfileParamsVo.class.getDeclaredField(fieldName);
            if(fieldName.equals("nickname")) {
                long timeNow = LocalDateTime.now().toEpochSecond(ZoneOffset.UTC);
                if ( userInformationDao.getNicknameLastModifyTime() == null || timeNow - userInformationDao.getNicknameLastModifyTime().toEpochSecond(ZoneOffset.UTC) > DAYS_BETWEEN_NAME_MODIFY){
                    Field nicknameLastModifyTimeField = UserInformationDao.class.getDeclaredField("nicknameLastModifyTime");
                    nicknameLastModifyTimeField.setAccessible(true);
                    nicknameLastModifyTimeField.set(userInformationDao, LocalDateTime.now());
                }
                else{
                    ExceptionCause exceptionCause = new ExceptionCause("user profile", ErrorReason.MODIFY_NAME_TOO_OFTEN);
                    throw new BaseException(MODIFY_NAME_TOO_OFTEN, exceptionCause);
                }
            }
            field.setAccessible(true);

            Object value = field.get(modifyProfileParamsVo);
            Field userInformationDaoField = UserInformationDao.class.getDeclaredField(fieldName);
            userInformationDaoField.setAccessible(true);
            userInformationDaoField.set(userInformationDao, value);
        }

        userInformationRepository.save(userInformationDao);
    }

    /**
     * 更新用户信息的可见性
     * @param visibilityId 用户选择的可见性权限id
     */
    @Override
    public void updateVisibility(Integer visibilityId) {
        //获取用户id
        Long currentUserId = (Long) SecurityContextHolder.getContext().getAuthentication().getDetails();
        //获取该用户信息
        Optional<UserInformationDao> optionalUserInformationDao = userInformationRepository.findUserInformationDaoByUserId(currentUserId);
        //如果用户id不存在，则抛出异常
        if(!optionalUserInformationDao.isPresent()) {
            ExceptionCause exceptionCause = new ExceptionCause("user profile", ErrorReason.ACCOUNT_NOT_EXIST);
            throw new BaseException(ACCOUNT_NOT_EXIST, exceptionCause);
        }
        UserInformationDao userInformationDao = optionalUserInformationDao.get();

        //解析对应可见性的枚举对象
        UserInformationVisibility userInformationVisibility = UserInformationVisibility.decode(visibilityId);
        userInformationDao.setUserInformationVisibility(userInformationVisibility);

        userInformationRepository.save(userInformationDao);
    }
}