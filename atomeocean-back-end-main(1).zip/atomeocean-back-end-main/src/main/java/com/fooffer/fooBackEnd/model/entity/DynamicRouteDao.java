package com.fooffer.fooBackEnd.model.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

/**
 * 动态路由表Dao
 */
@Data
@Document(collection = "dynamicRoutes")
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DynamicRouteDao {

    // 逻辑主键
    private Integer dynamicRouteId;

    private String path;

    private String name;

    // 父节点id
    private Integer parentRouteId;

    // 子路由列表
    private List<Integer> childrenRoutes;
}
