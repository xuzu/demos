package com.fooffer.fooBackEnd.model.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import static com.fooffer.fooBackEnd.constant.articles.ArticleRequestConstant.DEFAULT_LIMIT;

/**
 * 关于文章列表的Vo
 * 例如profile页面请求该作者的所有文章
 * 或添加参数，limit=5&sortBy=createDate
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ArticleListRequestParams {

    /**
     * 作者的id
     */
    private String authorId;

    /**
     * 分页查询所在的页码，默认为1
     * 但Mongo中0是第一页
     */
    @Builder.Default
    private Integer pageNumber = 1;

    /**
     * 返回文章的数量
     */
    @Builder.Default
    private Integer limit = DEFAULT_LIMIT;

}
