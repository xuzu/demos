package com.fooffer.fooBackEnd.model.dto.editor;

import com.fooffer.fooBackEnd.constant.articles.ArticleVisibility;
import com.fooffer.fooBackEnd.model.dto.article.ArticleTagDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 文章上传过程中
 * Editor Vo -> Editor Dto -> Article Dao
 * 这个类负责处理整合Vo中的数据并准备传送给Dao
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EditorDto {

    private Long articleId;

    private String title;

    private String collapsedContent;

    private Long authorId;

    private Long contentId;

    // 文章内容
    private String content;

    private LocalDateTime createTime;

    private LocalDateTime latestUpdateTime;

    private Integer wordCount;

    private Boolean isDeleted;

    private String categoryName;

    private ArticleVisibility visibility;

    private List<ArticleTagDto> articleTagList;

    /**
     * 文章封面图的链接
     */
    private String articleCoverImageLink;
}
