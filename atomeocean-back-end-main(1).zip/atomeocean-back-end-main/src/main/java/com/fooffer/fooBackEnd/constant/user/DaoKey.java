package com.fooffer.fooBackEnd.constant.user;

/**
 * UserDao中key的名字
 */
public enum DaoKey {
    USER_NAME("username"),
    USER_EMAIL("userEmail");

    private String key;
    DaoKey(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }
}
