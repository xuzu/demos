package com.fooffer.fooBackEnd.model.dto.article;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 文章作者dto封装类
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ArticleAuthor {

    /**
     * 62进制用户id
     */
    private String authorId;
    /**
     * 作者的名字
     */
    private String nickname;

    /**
     * 作者头像链接
     */
    private String avatarLink;

    /**
     * 作者简介
     */
    private String motto;
}
