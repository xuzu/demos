package com.fooffer.fooBackEnd.service.intf;

import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.vo.EmailAuthVo;
import org.springframework.stereotype.Service;

/**
 * 用户注册相关Service
 */
@Service
public interface UserRegisterService {

    /**
     * 将未验证邮箱的用户保存进缓存
     */
    ResultData saveUnverifiedNewUser(EmailAuthVo emailAuthVo) throws BaseException;

    /**
     * 验证用户邮箱，验证成功后存入数据库
     */
    ResultData saveVerifiedNewUser(String email, String code) throws BaseException;
}
