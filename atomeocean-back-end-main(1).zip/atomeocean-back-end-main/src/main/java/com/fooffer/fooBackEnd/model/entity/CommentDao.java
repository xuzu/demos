package com.fooffer.fooBackEnd.model.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;


/**
 * 对应数据库中的comment collection
 * 保存文章的评论信息，包括对文章以及对评论的评论
 */
@Data
@Document(collection = "comment")
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CommentDao {
    @Id
    private ObjectId _id;

    //逻辑主键
    @Indexed
    private Long commentId;

    //本条评论对应的父评论id,对于第一层评论则保存文章id作为parentId
    private Long parentId;

    //本条评论所在的文章id
    private Long articleId;

    //评论者id
    private Long fromId;

    //被评论者id
    private Long toId;

    //点赞数量
    private Integer likes;

    //评论内容
    private String content;

    //评论创建时间
    private LocalDateTime createTime;

    //评论修改时间
    private LocalDateTime modifyTime;

    //是否被删除
    private Boolean isDeleted;

    //是否悄悄话
    private Boolean isWhisper;

    //子评论数量
    private Integer childrenNumber;
}
