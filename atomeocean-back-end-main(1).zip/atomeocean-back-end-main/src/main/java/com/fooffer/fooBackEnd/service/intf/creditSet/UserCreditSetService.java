package com.fooffer.fooBackEnd.service.intf.creditSet;

import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.dto.creditSet.UserCreditSetDto;
import com.fooffer.fooBackEnd.model.entity.creditSet.UserCreditSetDao;
import com.fooffer.fooBackEnd.model.vo.creditSet.UserCreditSetVo;

import org.springframework.stereotype.Service;

/**
 * 用户积分接口
 * 由于目前只有一种积分，所有接口默认修改贝壳shell数量
 * 如果之后添加更多积分种类，可以在接口中加入积分种类变量
 */
@Service
public interface UserCreditSetService {


    /**
     * 根据userId返回用户creditSetDao
     * @param userId
     * @return
     */
    UserCreditSetDao getUserCreditSetDaoByUserId(Long userId);

    /**
     * 根据userId返回用户creditSetDto
     * @param userId
     * @return
     */
    UserCreditSetDto getUserCreditSetDtoByUserId(Long userId);

    /**
     * 根据userId返回用户creditSetVo
     * @param userId
     * @return
     */
    UserCreditSetVo getUserCreditSetVoByUserId(Long userId);
    
    /**
     * 为该userId修改积分数量
     * @param amount 正数代表增加，负数代表减少
     */
    ResultData modifyCredit(Long userId, Long amount, String description) throws BaseException;

    //TODO：积分明细相关接口
}
