package com.fooffer.fooBackEnd.repository;

import com.fooffer.fooBackEnd.model.entity.ImageDao;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ImageRepository  extends MongoRepository<ImageDao, Long> {
    //利用id查找文件
    Optional<ImageDao> findImageDaoByImageId(Long imageId);

    //利用文件hash值查找文件
    Optional<ImageDao> findImageDaoByHash(String hash);
}
