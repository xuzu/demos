package com.fooffer.fooBackEnd.controller;

import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.vo.CommentVo;
import com.fooffer.fooBackEnd.service.intf.CommentService;
import com.fooffer.fooBackEnd.utils.NumConvertUtil;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


/**
 * 评论系统接口
 * 包括读取、添加、修改、删除评论等操作
 */
@RestController
@AllArgsConstructor
@RequestMapping("/Comment")
@Slf4j
public class CommentController {

    private final CommentService commentService;
    
    /**
     * 创建一条新的comment
     * @param commentVo 根据contract 会包括以下变量
     * 	"parentId": "本条评论的父评论id",
        "articleId": "本条评论所在的文章id",
        "fromId": "评论者用户id",
        "toId": "被评论用户id",
        "content": "评论内容",
        "isWhisper": "是否以悄悄话发布",
     * @return 创建评论的操作结果
     */
    @PostMapping("/create")
    public ResultData createComment(@RequestBody CommentVo commentVo) throws BaseException{

        commentVo.setCreateTime(LocalDateTime.now());
        commentVo.setModifyTime(LocalDateTime.now());
        commentVo.setIsDeleted(false);
        commentVo.setLikes(0);
        commentVo.setChildrenNumber(0);
        return commentService.createComment(commentVo);
    }

    @GetMapping("/get")
    public ResultData getComment(
        @RequestParam(name = "userId") String encodedUserId,
        @RequestParam(name = "parentId") Long parentId) throws BaseException{

        Long userId = NumConvertUtil.decode62To10(encodedUserId);
        List<CommentVo> commentList = commentService.getCommentList(userId, parentId);

        return ResultData.success(commentList);
    }

    /**
     * 创建一条新的comment
     * @param commentVo 根据contract 会包括以下变量
        "commentId": "本条评论id"，
        "content": "修改后的评论内容",
        "isWhisper": "是否是悄悄话",
        "isDeleted": "是否删除"
     * @return 创建评论的操作结果
     */
    @PostMapping("/edit")
    public ResultData editComment(@RequestBody CommentVo commentVo) throws BaseException{
        return commentService.modifyComment(commentVo);
    }
}
