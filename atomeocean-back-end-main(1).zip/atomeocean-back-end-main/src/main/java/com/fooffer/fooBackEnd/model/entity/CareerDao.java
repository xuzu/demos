package com.fooffer.fooBackEnd.model.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;


/**
 * 对应数据库中的career collection
 * 保存用户的工作经历信息，每个career对应一段经历
 */
@Data
@Document(collection = "career")
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CareerDao {
    @Id
    private ObjectId _id;

    //逻辑主键
    @Indexed
    private Long careerId;

    //本段工作经历所对应的userId
    private Long userId;

    //公司名
    private String companyName;

    //职位名
    private String position;

    //开始日期
    private LocalDate startDate;

    //结束日期
    private LocalDate endDate;

    //是否已经离职，如果是false那么前端显示结束日期为“至今”
    private Boolean isCompleted;
}
