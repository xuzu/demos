package com.fooffer.fooBackEnd.constant.file;

/**
 * 标识文件状态
 */
public enum FileStatus {

    ;

    private Integer code;
    private String status;

    FileStatus(Integer code, String status){
        this.code = code;
        this.status = status;
    }

    public Integer getCode() {
        return code;
    }

    public String getStatus(){
        return status;
    }
}
