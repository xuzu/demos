package com.fooffer.fooBackEnd.model.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 请求UserVo的参数
 *
 * usecase: profile页面加载时用用户名来请求到该用户的其他信息
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserRequestParams {
    private String userEmail;
}
