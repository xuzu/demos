package com.fooffer.fooBackEnd.service.impl.creditSet;

import com.fooffer.fooBackEnd.model.entity.creditSet.ShellTransactionStatementDao;
import com.fooffer.fooBackEnd.model.entity.creditSet.UserCreditSetDao;
import com.fooffer.fooBackEnd.repository.creditSet.UserCreditSetRepository;
import com.fooffer.fooBackEnd.service.intf.creditSet.ShellTransactionStatementService;
import com.fooffer.fooBackEnd.utils.SnowflakeIdWorker;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
@Slf4j
public class ShellTransactionStatementServiceImpl implements ShellTransactionStatementService {

    private final SnowflakeIdWorker snowflakeIdWorker;

    private final UserCreditSetRepository userCreditSetRepository;

    public ShellTransactionStatementServiceImpl(
            UserCreditSetRepository userCreditSetRepository
    ){
        this.userCreditSetRepository = userCreditSetRepository;
        this.snowflakeIdWorker = new SnowflakeIdWorker(7L, 6L);
    }

    /**
     * 生成一条贝壳交易记录
     * @param userId 用户id
     * @param amount 交易的贝壳数，正数表示充值，负数表示退款
     * @param timestamp 交易时间
     * @param description 交易描述
     */
    @Override
    public ShellTransactionStatementDao generateShellTransactionStatement(Long userId, Long amount, LocalDateTime timestamp, String description) {
        //生成交易单号
        Long shellTransactionStatementId = snowflakeIdWorker.nextId();

        ShellTransactionStatementDao shellTransactionStatementDao = ShellTransactionStatementDao.builder()
                    .shellTransactionStatementId(shellTransactionStatementId)
                    .userId(userId)
                    .amount(amount)
                    .timestamp(timestamp)
                    .description(description)
                    .build();

        //查询用户余额
        Optional<UserCreditSetDao> optionalUserCreditSetDao = userCreditSetRepository.findUserCreditSetDaoByUserId(userId);
        optionalUserCreditSetDao.ifPresent(userCreditSetDao -> shellTransactionStatementDao.setShellBalance(userCreditSetDao.getShell()));

        return shellTransactionStatementDao;
    }
}
