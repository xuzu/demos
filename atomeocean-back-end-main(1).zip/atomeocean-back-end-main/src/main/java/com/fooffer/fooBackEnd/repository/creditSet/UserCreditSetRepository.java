package com.fooffer.fooBackEnd.repository.creditSet;

import com.fooffer.fooBackEnd.model.entity.creditSet.UserCreditSetDao;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * 对数据库中userCreditSet collection进行操作
 */
@Repository
public interface UserCreditSetRepository extends MongoRepository<UserCreditSetDao, Long> {

    // 通过用户id获取UserCreditSetDao
    Optional<UserCreditSetDao> findUserCreditSetDaoByUserId(Long userId);
}
