package com.fooffer.fooBackEnd.controller.creditSet;

import com.fooffer.fooBackEnd.constant.stripe.Currency;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.vo.StripePaymentParamsVo;
import com.fooffer.fooBackEnd.service.intf.creditSet.StripeService;
import com.stripe.exception.StripeException;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * stripe支付接口
 */
@RestController
@AllArgsConstructor
@RequestMapping("/stripe")
@Slf4j
public class StripeController {

    private final StripeService stripeService;

    /**
     * stripe支付接口
     * @param stripePaymentParamsVo 用户支付信息
     * @return 通知前端支付结果
     */
    @PostMapping("/pay")
    public ResultData pay(@RequestBody @Validated StripePaymentParamsVo stripePaymentParamsVo) throws StripeException {
        //设置交易货币种类
        stripePaymentParamsVo.setCurrency(Currency.USD);

        return stripeService.pay(stripePaymentParamsVo);
    }
}
