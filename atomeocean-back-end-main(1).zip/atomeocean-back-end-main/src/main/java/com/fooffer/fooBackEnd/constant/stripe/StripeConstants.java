package com.fooffer.fooBackEnd.constant.stripe;

public class StripeConstants {
    /**
     *  手续费根据stripe官方提供比例计算
     *  https://stripe.com/pricing
     */

    //充值扣除手续费后网站实际到账金额比例
    public final static Double FEE_RATE = 0.971;
    //每笔交易固定手续费，单位为cent
    public final static Integer CONSTANT_FEE = 30;
}
