package com.fooffer.fooBackEnd.aspect.converter;

import com.fooffer.fooBackEnd.constant.ErrorReason;
import com.fooffer.fooBackEnd.constant.ReturnCode;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.exception.CauseOnlyException;
import com.fooffer.fooBackEnd.exception.cause.ExceptionCause;
import org.springframework.core.convert.converter.Converter;
import com.fooffer.fooBackEnd.constant.baseEnum.IdCodeBaseEnum;
import com.google.common.collect.Maps;


import java.util.Arrays;
import java.util.Map;
import java.util.Optional;

public class IdCodeToEnumConverter <T extends IdCodeBaseEnum> implements Converter<String, T> {
    private final Map<String, T> idEnumMap = Maps.newHashMap();
    private final Map<String, T> codeEnumMap = Maps.newHashMap();

    public IdCodeToEnumConverter(Class<T> enumType) {
        Arrays.stream(enumType.getEnumConstants())
                .forEach(targetEnum -> {
                    idEnumMap.put(targetEnum.getId().toString(), targetEnum);
                    codeEnumMap.put(targetEnum.getCode(), targetEnum);
                });
    }

    @Override
    public T convert(String source) {
        return Optional.of(source)
                .map(codeEnumMap::get)
                .orElseGet(
                        () -> {
                        return Optional.of(source)
                                .map(idEnumMap::get)
                                .orElseThrow(() -> new CauseOnlyException(
                                        ExceptionCause.builder()
                                                .domain("converter")
                                                .errorReason(ErrorReason.PARAM_INVALID).
                                                build()
                                ));
                        }
                );
    }
}
