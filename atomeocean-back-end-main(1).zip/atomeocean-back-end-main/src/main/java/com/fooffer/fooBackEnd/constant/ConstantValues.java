package com.fooffer.fooBackEnd.constant;

public class ConstantValues {
    /**
        一些常量
     *
     */

    //表示间隔60天的时长
    public static final long DAYS_BETWEEN_NAME_MODIFY = 518_4000L;

}
