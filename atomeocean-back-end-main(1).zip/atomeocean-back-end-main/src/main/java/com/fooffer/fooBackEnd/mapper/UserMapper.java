package com.fooffer.fooBackEnd.mapper;

import com.fooffer.fooBackEnd.model.dto.UserDto;
import com.fooffer.fooBackEnd.model.entity.UserDao;
import com.fooffer.fooBackEnd.model.vo.UserVo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

/**
 * User vo, dto, dao 映射
 */
@Mapper(componentModel = "spring", uses = {UserRoleMapper.class})
public interface UserMapper {
    UserMapper INSTANCE = Mappers.getMapper(UserMapper.class);

    UserDto vo2dto(UserVo userVo);

    UserVo dto2vo(UserDto userDto);

    @Mapping(source = "userRoleDtoList", target = "userRoleDaoList")
    UserDao dto2dao(UserDto userDto);

    @Mapping(source = "userDao.userRoleDaoList", target = "userRoleDtoList")
    UserDto dao2dto(UserDao userDao);
}
