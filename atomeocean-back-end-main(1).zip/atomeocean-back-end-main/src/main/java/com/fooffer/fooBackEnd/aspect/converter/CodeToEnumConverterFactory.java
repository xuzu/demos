package com.fooffer.fooBackEnd.aspect.converter;

import com.fooffer.fooBackEnd.constant.baseEnum.CodeBaseEnum;
import com.google.common.collect.Maps;
import org.springframework.core.convert.converter.Converter;
import org.springframework.core.convert.converter.ConverterFactory;

import java.util.Map;

public class CodeToEnumConverterFactory implements ConverterFactory<String, CodeBaseEnum> {
    @SuppressWarnings("rawtypes")
    private static final Map<Class, Converter> CONVERTERS = Maps.newHashMap();
    @Override
    public <T extends CodeBaseEnum> Converter<String, T> getConverter(Class<T> targetType) {
        return CONVERTERS.computeIfAbsent(targetType, key -> new CodeToEnumConverter<>(targetType));
    }
}
