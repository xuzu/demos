package com.fooffer.fooBackEnd.service.impl;

import com.fooffer.fooBackEnd.constant.ErrorReason;
import com.fooffer.fooBackEnd.constant.ResourceOperationType;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.exception.cause.ExceptionCause;
import com.fooffer.fooBackEnd.mapper.EducationMapper;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.dto.EducationDto;
import com.fooffer.fooBackEnd.model.entity.EducationDao;
import com.fooffer.fooBackEnd.model.entity.UserInformationDao;
import com.fooffer.fooBackEnd.model.vo.EducationVo;
import com.fooffer.fooBackEnd.repository.EducationRepository;
import com.fooffer.fooBackEnd.repository.UserInformationRepository;
import com.fooffer.fooBackEnd.service.intf.EducationService;
import com.fooffer.fooBackEnd.service.intf.UserInformationService;
import com.fooffer.fooBackEnd.utils.SnowflakeIdWorker;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import static com.fooffer.fooBackEnd.constant.ReturnCode.*;

import java.util.Set;

@Service
@Slf4j
@AllArgsConstructor
public class EducationServiceImpl  implements EducationService {

    private final EducationRepository educationRepository;
    private final UserInformationRepository userInformationRepository;
    private final EducationMapper educationMapper;
    private final SnowflakeIdWorker snowflakeIdWorker = new SnowflakeIdWorker(7L, 6L);
    private final UserInformationService userInformationService;

    /**
     * 检查用户输入的教育经历信息，如果符合要求则创建新的教育经历并存入数据库
     */
    @Override
    public ResultData createEducation(EducationVo educationVo) throws BaseException{
        Long userId = (Long) SecurityContextHolder.getContext().getAuthentication().getDetails();
        Long educationId = educationVo.getEducationId();
        UserInformationDao userInformationDao = userInformationService.getUserInformationDaoByUserId(userId);

        //用户已经输入了教育经历id
        if (educationId != null){
            ExceptionCause exceptionCause = new ExceptionCause("education", ErrorReason.BAD_REQUEST);
            throw new BaseException(EDUCATION_EXIST, exceptionCause);
        }

        //为新教育经历生成独特的educationId
        EducationDto educationDto = educationMapper.vo2dto(educationVo);
        educationDto.setUserId(userId);
        EducationDao educationDao = educationMapper.dto2dao(educationDto);
        educationId= snowflakeIdWorker.nextId();
        educationDao.setEducationId(educationId);

        //保存至数据库
        educationRepository.save(educationDao);

        //用户信息里的educationId set添加新的educationId
        Set<Long> educationIdSet = userInformationDao.getEducationIdSet();
        educationIdSet.add(educationId);
        userInformationDao.setEducationIdSet(educationIdSet);
        userInformationRepository.save(userInformationDao);

        //操作成功返回生成的educationId
        return ResultData.success(educationId);
    };



    /**
     * 检查用户输入的教育经历信息，如果符合要求则修改对应的教育经历(修改内容或删除)
     * operationType patch：修改内容
     * operationType delete：删除经历
     */
    @Override
    public ResultData modifyEducation(EducationVo educationVo, ResourceOperationType operationType) throws BaseException{
        Long userId = (Long) SecurityContextHolder.getContext().getAuthentication().getDetails();
        Long educationId = educationVo.getEducationId();
        UserInformationDao userInformationDao = userInformationService.getUserInformationDaoByUserId(userId);
        
        EducationDao old_educationDao = educationRepository.findEducationDaoByEducationId(educationId).orElseThrow(
                () -> new BaseException(
                        EDUCATION_NOT_EXIST,
                        ExceptionCause.builder()
                                .domain("education")
                                .errorReason(ErrorReason.BAD_REQUEST)
                                .build()
                )
        );

        //如果userId和用户提交的教育经历里记录的userId不同，抛出异常（用户试图修改属于其他人的教育经历）
        if (!old_educationDao.getUserId().equals(userId)){
            ExceptionCause exceptionCause = new ExceptionCause("education", ErrorReason.BAD_REQUEST);
            throw new BaseException(ACCESS_DENIED, exceptionCause);
        }

        switch (operationType) {
            // 修改教育经历
            case Patch:
                EducationDto educationDto = educationMapper.vo2dto(educationVo);
                educationDto.setUserId(userId);
                EducationDao new_educationDao = educationMapper.dto2dao(educationDto);
                new_educationDao.set_id(old_educationDao.get_id());

                //保存新教育信息至数据库
                educationRepository.save(new_educationDao);

                return ResultData.success("教育经历修改成功！");
            // 删除教育经历
            case Delete:

                //删除数据库中的教育信息
                educationRepository.delete(old_educationDao);
                
                //修改用户信息里的educationId set
                
                Set<Long> educationIdSet = userInformationDao.getEducationIdSet();
                educationIdSet.remove(educationId);
                userInformationDao.setEducationIdSet(educationIdSet);
                userInformationRepository.save(userInformationDao);

                return ResultData.success("教育经历删除成功！");

            // 否则operationType错误，抛出错误(创建education需要用createEducation)
            default:
                ExceptionCause exceptionCause = new ExceptionCause("education", ErrorReason.BAD_REQUEST);
                throw new BaseException(EDUCATION_EXIST, exceptionCause);
        } 
    };
    
}
