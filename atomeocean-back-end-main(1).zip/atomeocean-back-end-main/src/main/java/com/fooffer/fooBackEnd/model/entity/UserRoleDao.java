package com.fooffer.fooBackEnd.model.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

/**
 * 对应userRoles
 * 用户角色信息
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document(collection = "userRoles")
public class UserRoleDao {

    /**
     * 逻辑主键，因为role数量有限只用Integer
     */
    private Integer roleId;

    /**
     * 角色名称
     */
    private String roleName;

    /**
     * 这个role可以访问哪些动态路由，参数为id
     */
    private List<Integer> dynamicRouteIds;
}
