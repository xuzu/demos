package com.fooffer.fooBackEnd.model.entity.creditSet;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

/**
 * 对应数据库中的shellTransactionStatement collection
 * 记录平台所有用户的贝壳交易明细
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document(collection = "shellTransactionStatement")
public class ShellTransactionStatementDao {

    @Id
    private ObjectId _id;

    /**
     * 逻辑主键
     * 代表交易单号
     */
    private Long shellTransactionStatementId;

    /**
     * 交易用户id
     */
    private Long userId;

    /**
     * 交易贝壳数额
     * 正值代表充值，负值代表退款
     */
    private Long amount;

    /**
     * 交易时间
     */
    private LocalDateTime timestamp;

    /**
     * 交易描述
     */
    private String description;

    /**
     * 交易完成后用户的shell余额
     */
    private Long shellBalance;
}
