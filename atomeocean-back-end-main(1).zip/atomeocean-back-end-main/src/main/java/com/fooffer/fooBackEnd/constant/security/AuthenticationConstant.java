package com.fooffer.fooBackEnd.constant.security;

/**
 * spring-security authentication可能出现的常量
 */
public class AuthenticationConstant {
    public static final String ANONYMOUS_USER_PRINCIPLE = "anonymousUser";
}
