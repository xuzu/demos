package com.fooffer.fooBackEnd.utils;

import com.fooffer.fooBackEnd.config.FileStorageConfig;
import io.minio.*;
import io.minio.http.Method;
import io.minio.messages.Bucket;
import io.minio.messages.Item;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

/**
 * 文件存储工具类，处理和文件相关的操作
 */
@Slf4j
@Component
public class FileStorageUtil {

    private static MinioClient minioClient;
    private static FileStorageConfig fileStorageConfig;

    @Autowired
    public FileStorageUtil(MinioClient minioClient, FileStorageConfig minioConfig){
        this.minioClient = minioClient;
        this.fileStorageConfig = minioConfig;
    }


    /**************************** 桶操作 ****************************/

    /**
     * 检查存储桶是否存在
     *
     * @param bucketName 存储桶名称
     * @return
     */
    public static boolean bucketExists(String bucketName) throws Exception {
        return minioClient.bucketExists(BucketExistsArgs.builder().bucket(bucketName).build());
    }

    /**
     * 创建存储桶
     *
     * @param bucketName 存储桶名称
     * @return boolean值表示桶创建是否成功
     */
    public static boolean makeBucket(String bucketName) throws Exception{
        boolean exists = bucketExists(bucketName);
        if (!exists) {
            minioClient.makeBucket(MakeBucketArgs.builder().bucket(bucketName).build());
            return true;
        } else {
            return false;
        }
    }

    /**
     * 列出所有存储桶
     *
     * @return 返回所有存储桶
     */
    public static List<Bucket> listBuckets() throws Exception{
        return minioClient.listBuckets();
    }

    /**
     * 根据bucketName获取其相关信息
     *
     * @param bucketName
     * @return 返回输入桶的相关信息，null表示桶名称不存在
     */
    public static Optional<Bucket> getBucket(String bucketName) throws Exception{
        boolean exists = bucketExists(bucketName);
        if(exists) {
            return listBuckets().stream().filter(b -> b.name().equals(bucketName)).findFirst();
        }

        return null;
    }

    /**
     * 列出所有存储桶名称
     *
     * @return 返回所有桶名称
     */
    public static List<String> listBucketNames() throws Exception{
        List<Bucket> bucketList = listBuckets();
        List<String> bucketListName = new ArrayList<>();
        for (Bucket bucket : bucketList) {
            bucketListName.add(bucket.name());
        }
        return bucketListName;
    }

    /**
     * 列出存储桶中的所有对象
     *
     * @param bucketName 存储桶名称
     * @return 返回输入桶名称中所有对象，null表示输入桶不存在
     */
    public static Iterable<Result<Item>> listObjects(String bucketName) throws Exception{
        boolean exists = bucketExists(bucketName);
        if (exists) {
            return minioClient.listObjects(ListObjectsArgs.builder().bucket(bucketName).build());
        }
        return null;
    }

    /**
     * 列出存储桶中的所有对象名称
     *
     * @param bucketName 存储桶名称
     * @return 返回输入桶中所有对象名称，null表示输入桶名称不存在
     */
    public static List<String> listObjectNames(String bucketName) throws Exception{
        List<String> listObjectNames = new ArrayList<>();
        boolean exists = bucketExists(bucketName);
        if (exists) {
            Iterable<Result<Item>> myObjects = listObjects(bucketName);
            for (Result<Item> result : myObjects) {
                listObjectNames.add(result.get().objectName());
            }
            return listObjectNames;
        }
        return null;
    }

    /**
     * 删除存储桶
     *
     * @param bucketName 存储桶名称
     * @return boolean值表示删除操作是否成功
     */
    public static boolean removeBucket(String bucketName) throws Exception{
        boolean exists = bucketExists(bucketName);
        if (exists) {
            Iterable<Result<Item>> myObjects = listObjects(bucketName);
            for (Result<Item> result : myObjects) {
                Item item = result.get();
                // 有对象文件，则删除失败
                if (item.size() > 0) {
                    return false;
                }
            }
            // 删除存储桶，注意，只有存储桶为空时才能删除成功。
            minioClient.removeBucket(RemoveBucketArgs.builder().bucket(bucketName).build());
            exists = bucketExists(bucketName);
            if (!exists) {
                return true;
            }
        }
        return false;
    }


    /**************************** 文件操作 ****************************/

    /**
     * 文件上传
     *
     * @param bucketName
     * @param multipartFile
     *
     * @return boolean值表示文件上传是否成功，false表示输入的桶名称不存在
     */
    public static boolean putObject(String bucketName, MultipartFile multipartFile, String filename, String fileType) throws Exception{
        boolean exists = bucketExists(bucketName);
        if (exists) {
            InputStream inputStream = new ByteArrayInputStream(multipartFile.getBytes());
            minioClient.putObject(
                    PutObjectArgs.builder().bucket(bucketName).object(filename).stream(
                                    inputStream, -1, fileStorageConfig.getFileSize())
                            .contentType(fileType)
                            .build());
            return true;
        }

        return false;
    }

    /**
     * 文件通过InputStream上传对象
     *
     * @param bucketName 存储桶名称
     * @param objectName 存储桶里的对象名称
     * @param inputStream     要上传的流
     * @param contentType     要上传的文件类型
     * @return boolean值表示文件上传是否成功
     */
    public static boolean putObject(String bucketName, String objectName, InputStream inputStream, String contentType) throws Exception{
        boolean exists = bucketExists(bucketName);
        if (exists) {
            minioClient.putObject(
                    PutObjectArgs.builder().bucket(bucketName).object(objectName)
                            .stream(inputStream, -1, fileStorageConfig.getFileSize())
                            .contentType(contentType)
                            .build());
            StatObjectResponse statObject = statObject(bucketName, objectName);
            if (statObject != null && statObject.size() > 0) {
                return true;
            }
        }
        return false;
    }

    /**
     * 删除文件
     *
     * @param bucketName 存储桶名称
     * @param objectName 存储桶里的对象名称
     *
     * @return boolean值表示删除操作是否成功
     */
    public static boolean removeObject(String bucketName, String objectName) throws Exception{
        boolean exists = bucketExists(bucketName);
        if (exists) {
            minioClient.removeObject(RemoveObjectArgs.builder().bucket(bucketName).object(objectName).build());
            return true;
        }
        return false;
    }

    /**
     * 获取对象的元数据
     *
     * @param bucketName 存储桶名称
     * @param objectName 存储桶里的对象名称
     * @return 返回对象元数据，null比哦啊是输入桶名称不存在
     */
    public static StatObjectResponse statObject(String bucketName, String objectName) throws Exception{
        boolean exists = bucketExists(bucketName);
        if (exists) {
            StatObjectResponse stat = minioClient.statObject(StatObjectArgs.builder().bucket(bucketName).object(objectName).build());
            return stat;
        }
        return null;
    }

    /**
     * 以流的形式获取一个文件对象
     *
     * @param bucketName 存储桶名称
     * @param objectName 存储桶里的对象名称
     * @return 返回输入流，null表示输入的桶名称不存在或文件不存在
     */
    public static InputStream getObject(String bucketName, String objectName) throws Exception{
        boolean exists = bucketExists(bucketName);
        if (exists) {
            StatObjectResponse statObject = statObject(bucketName, objectName);
            if (statObject != null && statObject.size() > 0) {
                InputStream stream = minioClient.getObject(GetObjectArgs.builder()
                                        .bucket(bucketName)
                                        .object(objectName)
                                        .build());
                return stream;
            }
        }
        return null;
    }

    /**
     * 以流的形式获取一个文件对象（断点下载）
     *
     * @param bucketName 存储桶名称
     * @param objectName 存储桶里的对象名称
     * @param offset     起始字节的位置
     * @param length     要读取的长度 (可选，如果无值则代表读到文件结尾)
     * @return 返回输入流，null表示输入的桶名称不存在或文件不存在
     */
    public static InputStream getObject(String bucketName, String objectName, long offset, Long length) throws Exception{
        boolean exists = bucketExists(bucketName);
        if (exists) {
            StatObjectResponse statObject = statObject(bucketName, objectName);
            if (statObject != null && statObject.size() > 0) {
                InputStream stream = minioClient.getObject(GetObjectArgs.builder()
                                        .bucket(bucketName)
                                        .object(objectName)
                                        .offset(offset)
                                        .length(length)
                                        .build());
                return stream;
            }
        }
        return null;
    }


    /**
     * 文件访问路径
     *
     * @param bucketName 存储桶名称
     * @param objectName 存储桶里的对象名称
     * @return 返回输入文件名称路径，null表示输入的桶名称不存在
     */
    public static String getObjectUrl(String bucketName, String objectName) throws Exception{
        boolean exists = bucketExists(bucketName);
        if (exists) {
            return minioClient.getPresignedObjectUrl(
                    GetPresignedObjectUrlArgs.builder()
                            .method(Method.GET)
                            .bucket(bucketName)
                            .object(objectName)
                            .expiry(2, TimeUnit.MINUTES)
                            .build());
        }

        return null;
    }
}

