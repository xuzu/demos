package com.fooffer.fooBackEnd.aspect.converter;

import com.fooffer.fooBackEnd.constant.baseEnum.IdBaseEnum;
import com.google.common.collect.Maps;
import org.springframework.core.convert.converter.Converter;
import org.springframework.core.convert.converter.ConverterFactory;

import java.util.Map;

public class IdToEnumConverterFactory implements ConverterFactory<String, IdBaseEnum> {
    @SuppressWarnings("rawtypes")
    private static final Map<Class, Converter> CONVERTERS = Maps.newHashMap();

    @Override
    public <T extends IdBaseEnum> Converter<String, T> getConverter(Class<T> targetType) {
        //noinspection unchecked
        return CONVERTERS.computeIfAbsent(targetType, key -> new IdToEnumConverter<>(targetType));
    }
}
