package com.fooffer.fooBackEnd.constant.baseEnum;

public interface CodeBaseEnum {
    String getCode();
}
