package com.fooffer.fooBackEnd.service.impl;

import com.fooffer.fooBackEnd.constant.ErrorReason;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.exception.cause.ExceptionCause;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.entity.EmailAuthDao;
import com.fooffer.fooBackEnd.model.vo.EmailAuthVo;
import com.fooffer.fooBackEnd.repository.EmailAuthRepository;
import com.fooffer.fooBackEnd.service.intf.ResetPasswordService;
import com.fooffer.fooBackEnd.utils.*;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.concurrent.TimeUnit;

import static com.fooffer.fooBackEnd.constant.ReturnCode.*;
import static com.fooffer.fooBackEnd.constant.user.RegisterConstant.EXPIRED_TIME;

@Service
@AllArgsConstructor
@Slf4j
public class ResetPasswordServiceImpl implements ResetPasswordService {

    private final EmailAuthRepository emailAuthRepository;
    private final BCryptPasswordEncoder bCryptPasswordEncoder;
    /*
     * 验证用户是否已注册过，已注册过则发送邮件，基本是UserRegisterService稍做修改后的复用
     * @param emailAuthVo 前端提交的用户邮箱信息
     * @return ResultData 包含状态码以及对应信息
     * */
    @Override
    public ResultData verifyUserEmail(EmailAuthVo emailAuthVo) throws BaseException {
        //验证该用户是否已经注册过,这里是如果没注册过就抛出错误
        Optional<EmailAuthDao> optionalEmailAuthDao = emailAuthRepository.findEmailAuthDaoByUserEmail(emailAuthVo.getUserEmail());
        if(!optionalEmailAuthDao.isPresent()) {
            ExceptionCause exceptionCause = new ExceptionCause("reset password", ErrorReason.ACCOUNT_NOT_EXIST);
            throw new BaseException(ACCOUNT_NOT_EXIST, exceptionCause);
        }

        //判断账户是否已在缓存
        String existingCode = (String) RedisUtil.get(emailAuthVo.getUserEmail());
        if(existingCode != null){
            //发送邮件，返回提示
            EmailSenderUtil.sendVerificationEmail(emailAuthVo.getUserEmail(), existingCode, "resetPassword");
            return ResultData.success("验证邮件已发送到您的邮箱，请验证您的邮箱，验证邮件有效期为15分钟");
        }
        
        //生成验证码并发送邮件
        VerificationCodeUtil.sendVerificationCodeEmail(emailAuthVo, EXPIRED_TIME, TimeUnit.SECONDS, "resetPassword");
        
        return ResultData.success("验证码已发送到您的邮箱，请验证您的邮箱，验证码有效期为15分钟");
    }

    /*
     * 检查用户输入的验证码，如果正确则修改密码
     * @param email 用户注册邮箱
     * @param code 验证用户账户的验证码
     * @return ResultData 包含状态码以及对应信息
     * */
    @Override
    public ResultData verifyCode(String email, String code) throws BaseException {

        //检查验证码
        EmailAuthVo emailAuthVo = VerificationCodeUtil.verifyCode(email, code, "reset password");

        //加密密码
        String encodedPassword = bCryptPasswordEncoder.encode(emailAuthVo.getPassword());

        //修改密码，存回数据库
        Optional<EmailAuthDao> optionalEmailAuthDao = emailAuthRepository.findEmailAuthDaoByUserEmail(email);
        EmailAuthDao emailAuthDao = optionalEmailAuthDao.get();
        emailAuthDao.setPassword(encodedPassword);
        emailAuthRepository.save(emailAuthDao);

        return ResultData.success("密码修改成功");
    }


}
