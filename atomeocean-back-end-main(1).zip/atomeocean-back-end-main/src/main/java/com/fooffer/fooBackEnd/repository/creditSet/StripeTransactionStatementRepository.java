package com.fooffer.fooBackEnd.repository.creditSet;

import com.fooffer.fooBackEnd.model.entity.creditSet.StripeTransactionStatementDao;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface StripeTransactionStatementRepository extends MongoRepository<StripeTransactionStatementDao, Long> {
    //根据交易单号查询交易记录
    Optional<StripeTransactionStatementDao> findStripeTransactionStatementDaoByStripeTransactionStatementId(String id);
}
