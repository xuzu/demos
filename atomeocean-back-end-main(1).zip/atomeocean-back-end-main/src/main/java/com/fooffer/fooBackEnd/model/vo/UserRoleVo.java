package com.fooffer.fooBackEnd.model.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 与前端交互时使用的role model
 * VO中包含用户身份的名字
 * 和它权限对应的动态路由的名字
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserRoleVo {

    private String roleName;

    private List<String> dynamicRouteNames;
}
