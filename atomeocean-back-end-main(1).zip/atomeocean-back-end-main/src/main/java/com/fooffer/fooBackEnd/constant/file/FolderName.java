package com.fooffer.fooBackEnd.constant.file;

/**
 * 文件系统中文件夹的名称
 */
public enum FolderName {
    Image("images"),
    Video("videos"),
    Pdf("pdfs");

    private String name;
    FolderName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
