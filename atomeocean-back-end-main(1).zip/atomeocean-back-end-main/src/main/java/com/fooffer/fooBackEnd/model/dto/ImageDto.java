package com.fooffer.fooBackEnd.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 图片在数据传输过程中的封装类
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ImageDto {
    private Long fileId;
}
