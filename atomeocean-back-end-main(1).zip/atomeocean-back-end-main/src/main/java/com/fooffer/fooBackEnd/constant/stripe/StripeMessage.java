package com.fooffer.fooBackEnd.constant.stripe;

public class StripeMessage {
    public static final String SUCCESS = "支付成功";
}
