package com.fooffer.fooBackEnd.constant.baseEnum;

public interface IdBaseEnum {
    Integer getId();
}

