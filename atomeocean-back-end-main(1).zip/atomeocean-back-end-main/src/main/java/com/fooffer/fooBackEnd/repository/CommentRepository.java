package com.fooffer.fooBackEnd.repository;

import com.fooffer.fooBackEnd.model.entity.CommentDao;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * 对数据库中CommentDao collection进行操作
 */
@Repository
public interface CommentRepository extends MongoRepository<CommentDao, Long> {

    // 通过评论id获取CommentDao
    Optional<CommentDao> findCommentDaoByCommentId(Long commentId);

    // 通过父评论id获取属于父评论的所有CommentDao list
    List<CommentDao> findCommentDaoListByParentId(Long parentId);
}
