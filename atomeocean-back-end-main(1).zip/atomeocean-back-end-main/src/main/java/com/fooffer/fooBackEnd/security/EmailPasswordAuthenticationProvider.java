package com.fooffer.fooBackEnd.security;

import com.fooffer.fooBackEnd.model.entity.EmailAuthDao;
import com.fooffer.fooBackEnd.service.intf.EmailAuthenticationService;
import com.fooffer.fooBackEnd.service.intf.UserAuthenticationService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * 响应EmailPasswordAuthenticationToken的验证请求
 */
@Slf4j
@Component
@AllArgsConstructor
public class EmailPasswordAuthenticationProvider implements
        AuthenticationProvider {

    private final UserAuthenticationService userAuthService;

    private final EmailAuthenticationService emailAuthenticationService;

    private final BCryptPasswordEncoder bCryptPasswordEncoder;

    @Override
    public Authentication authenticate(Authentication authentication)
            throws AuthenticationException {
        if (!supports(authentication.getClass())) {
            return null;
        }

        log.info("EmailPasswordAuthentication authentication request: {}", authentication);
        String userEmail = (authentication.getPrincipal() == null) ? "EMAIL_NOT_PROVIDED" : authentication.getName();
        String providedPassword = authentication.getCredentials().toString();

        EmailAuthDao emailAuthDao = emailAuthenticationService.loadEmailAuthDaoByUserEmail(userEmail);

        // 检查密码是否正确
        if(!bCryptPasswordEncoder.matches(providedPassword, emailAuthDao.getPassword())) {
            log.error("password not matched");
            log.info(emailAuthDao.getPassword());
            throw new BadCredentialsException("密码错误");
        }

        JwtUserDetails userDetails = userAuthService.loadUserDetailsByUserId(emailAuthDao.getUserId());

        EmailPasswordAuthenticationToken result = new EmailPasswordAuthenticationToken(
                userEmail,
                providedPassword
        );
        result.setDetails(userDetails);

        return result;
    }

    /**
     * 指定AuthenticationProvider验证EmailPasswordAuthenticationToken
     * @param authentication
     * @return 是否支持
     */
    @Override
    public boolean supports(Class<?> authentication) {
        return EmailPasswordAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
