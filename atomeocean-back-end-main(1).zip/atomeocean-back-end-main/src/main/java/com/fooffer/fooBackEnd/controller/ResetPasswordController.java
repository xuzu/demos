package com.fooffer.fooBackEnd.controller;


import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.vo.EmailAuthVo;
import com.fooffer.fooBackEnd.service.intf.ResetPasswordService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/resetPassword")
@AllArgsConstructor
@Slf4j
public class ResetPasswordController {
    private final ResetPasswordService resetPasswordService;

    //检查用户输入的邮箱是否满足重置密码的要求
    @PostMapping("/verifyEmail")
    public ResultData verifyUserEmail(
            @RequestBody @Validated EmailAuthVo userEmailInput
    ) {

        //验证用户输入的邮箱是否已注册过。
        return resetPasswordService.verifyUserEmail(userEmailInput);

    }

    //检查输入的验证码是否正确，如果正确则修改用户密码
    @PostMapping("/verifyCode")
    public ResultData verifyCode(
            @RequestParam(name = "email") String email,
            @RequestParam(name = "code") String code
    ) throws BaseException {

        return resetPasswordService.verifyCode(email,code);
    }

}
