package com.fooffer.fooBackEnd.model.entity.creditSet;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Builder;
import org.bson.types.ObjectId;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.data.mongodb.core.mapping.Document;


/**
 * 对应数据库中的user creditSet object
 * 每种成员变量代表该用户的各种积分数量
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EnableMongoAuditing
@Document(collection = "userCreditSet")
public class UserCreditSetDao {

    @Id
    private ObjectId _id;

    /**
     * 逻辑主键
     */
    private Long userId;

    /**
     * 该用户贝壳数量
     */
    private Long shell;
    
    /**
     * 用来实现乐观锁
     */
    @Version 
    private Long version;
}

