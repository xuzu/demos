package com.fooffer.fooBackEnd.model.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * 前端在user register时候发送的数据封装类
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EmailAuthVo implements Serializable {
    @NotBlank(message = "missing user email")
    private String userEmail;

    @NotBlank(message = "missing password")
    private String password;

    //为referIdString设置默认值(无邀请注册)
    @Builder.Default
    private String referIdString = "-1";
}
