package com.fooffer.fooBackEnd.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fooffer.fooBackEnd.model.RecaptchaResponse;
import com.fooffer.fooBackEnd.service.intf.RecaptchaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;


@Service
public class RecaptchaServiceImpl implements RecaptchaService {

    @Value("${recaptcha.server-key}")
    private String secretKey;
    @Value("${recaptcha.verify-url}")
    private String verifyUrl;

    private WebClient webClient;

    @Autowired
    public RecaptchaServiceImpl(WebClient webClient) {
        this.webClient = webClient;
    }

    @Override
    public RecaptchaResponse validateToken(String recaptchaToken) throws JsonProcessingException {
        //向Google发送http请求
        MultiValueMap<String,String> formData = new LinkedMultiValueMap<>();
        formData.add("secret", secretKey);
        formData.add("response", recaptchaToken);

        Mono<String> response = webClient.post()
                .uri(verifyUrl)
                .body(BodyInserters.fromFormData(formData))
                .retrieve()
                .bodyToMono(String.class);

        //将响应的Json字符串转换为RecaptchaResponse对象
        ObjectMapper objectMapper = new ObjectMapper();
        RecaptchaResponse recaptchaResponse = objectMapper.readValue(response.block(), RecaptchaResponse.class);

        return recaptchaResponse;
    }
}
