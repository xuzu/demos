package com.fooffer.fooBackEnd.constant.security;

/**
 * 保存和Jwt相关的常量
 */
public class JwtTokenConstant {
    public static final String TOKEN_HEADER = "Authorization";
    public static final String TOKEN_PREFIX = "Bearer";

    // todo: prod上需要保存到其他地方
    public static final String SECRET = "jwtSecretDemo";

    public static final String ISS = "fooffer";
}
