package com.fooffer.fooBackEnd.controller;

import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.vo.EducationVo;
import com.fooffer.fooBackEnd.service.intf.EducationService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;



/**
 * 教育经历接口
 * 包括添加、修改、删除教育经历等操作
 */
@RestController
@AllArgsConstructor
@RequestMapping("/education")
@Slf4j
public class EducationController {

     private final EducationService educationService;

    /**
     * 创建、修改、删除教育经历
     * @param educationVo 
     * @return 创建、修改、删除教育经历的操作结果
     */
    @PostMapping("")
    public ResultData operateEducation(@RequestBody EducationVo educationVo) {

        ResultData result;
        // 根据操作类型决定调用哪个service
        switch (educationVo.getOperationType()) {

            // 创建新的教育经历
            case Post:
                result = educationService.createEducation(educationVo);
                break;

            // 修改已有的教育经历/删除教育经历
            case Patch: case Delete:
                result = educationService.modifyEducation(educationVo, educationVo.getOperationType());
                break;

            // 缺失按照post处理
            default:
                result = educationService.createEducation(educationVo);
                log.info("no operation type provided");
        }

        return result;
    }
}
