package com.fooffer.fooBackEnd.model.entity;

import com.fooffer.fooBackEnd.constant.file.FileStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

/**
 * 对应数据库中的Image collection
 * 保存用户上传的图片信息
 */
@Data
@Document(collection = "images")
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ImageDao {
    @Id
    private ObjectId _id;

    /**
     * 逻辑主键
     * 文件唯一id标识
     */
    @Indexed
    private Long imageId;

    /**
     * 用户上传时的图片名
     */
    private String originalImageName;

    /**
     * 图片存放的桶名称
     */
    private String bucketName;

    /**
     * 图片存放在s3服务器中的名称
     */
    private String s3ImageName;

    /**
     * 图片在服务器中的存放路径
     */
    private String url;

    /**
     * 图片类型
     */
    private String imageType;

    /**
     * 图片大小
     */
    private Long imageSize;

    /**
     * 图片上传日期
     */
    private LocalDateTime timestamp;

    /**
     * 图片hash值
     */
    private String hash;

    /**
     * 图片当前被引用的次数
     */
    private int citation;

    /**
     * 图片缩略图对应的id
     */
    private Long thumbnailId;
}
