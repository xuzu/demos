package com.fooffer.fooBackEnd.controller;

import com.fooffer.fooBackEnd.constant.ResourceOperationType;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.vo.EditorVo;
import com.fooffer.fooBackEnd.service.intf.EditorService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

/**
 * 编辑器接口
 * 处理单篇文章的操作，例如上传、删除等
 * 接口前缀为`/editor`
 */
@RestController
@AllArgsConstructor
@RequestMapping("/editor")
@Slf4j
public class EditorController {

    private final EditorService editorService;

    /**
     * 发表一篇新的文章
     * @param editorVo 将前端提交的json映射到VO里面
     * @return 文章提交/更新/删除成功的信息
     */
    @PostMapping("")
    public ResultData operateArticle(@RequestBody EditorVo editorVo) {

        // 根据操作类型决定调用哪个service
        switch (editorVo.getOperationType()) {
            // 发布一篇新文章
            case Post:
                editorService.saveAnArticle(
                        editorVo,
                        ResourceOperationType.Post
                );
                break;
            // 编辑一篇已有文章
            case Patch:
                editorService.saveAnArticle(
                        editorVo,
                        ResourceOperationType.Patch
                );
                break;
            // 删除一篇文章
            case Delete:
                editorService.saveAnArticle(
                        editorVo,
                        ResourceOperationType.Delete
                );
                break;

            // 缺失按照post处理
            default:
                editorService.saveAnArticle(
                        editorVo,
                        ResourceOperationType.Post
                );
                log.info("no operation type provided");
        }

        return ResultData.success("article update successfully");
    }

    @PostMapping("/coverImage/update")
    public ResultData<String> updateArticleCoverImage(
            @RequestParam(name = "coverImage") MultipartFile coverImage,
            @RequestParam(name = "hash") String imageHash
    ){
        String coverImageLink = editorService.updateCoverImage(coverImage, imageHash);

        return ResultData.success(coverImageLink);
    }
}
