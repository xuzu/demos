package com.fooffer.fooBackEnd.service.impl;

import com.fooffer.fooBackEnd.model.entity.EmailAuthDao;
import com.fooffer.fooBackEnd.repository.EmailAuthRepository;
import com.fooffer.fooBackEnd.service.intf.EmailAuthenticationService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@AllArgsConstructor
public class EmailAuthenticationServiceImpl implements EmailAuthenticationService {

    private final EmailAuthRepository emailAuthRepository;

    @Override
    public EmailAuthDao loadEmailAuthDaoByUserEmail(String userEmail) {
        return emailAuthRepository
                .findEmailAuthDaoByUserEmail(userEmail)
                .orElseThrow(()-> new BadCredentialsException("用户不存在"));
    }
}
