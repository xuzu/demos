package com.fooffer.fooBackEnd.service.intf;

import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.model.dto.UserInformationDto;
import com.fooffer.fooBackEnd.model.entity.UserInformationDao;
import com.fooffer.fooBackEnd.model.vo.ModifyProfileParamsVo;
import com.fooffer.fooBackEnd.model.vo.UserInformationVo;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

/**
 * 用户信息接口
 */
@Service
public interface UserInformationService {

    /**
     * 根据userId返回用户信息Dto
     * @param userId
     * @return
     */
    UserInformationDto getUserInformationDtoByUserId(Long userId);
    
    /**
     * 根据userId返回用户信息Vo
     * 
     * @param userId 用户Id
     * @return UserInformationVo
     */
    UserInformationVo getUserInformationVoByUserId(Long userId);

    /**
     * 根据userId返回用户信息Dao
     * @param userId
     * @return
     */
    UserInformationDao getUserInformationDaoByUserId(Long userId);

    /**
     * 更新用户头像
     * @param avatarImage 用户上传的头像图片
     */
    String updateAvatar(
            MultipartFile avatarImage,
            String imageHash
    ) throws BaseException;

    /**
     * 更新用户的信息
     * @param modifyProfileParamsVo 需要更新的值
     * @throws BaseException
     * @throws NoSuchFieldException
     */
    void updateUserInformation(
            ModifyProfileParamsVo modifyProfileParamsVo
    ) throws BaseException, NoSuchFieldException, IllegalAccessException;

    /**
     * 更新用户信息的可见性
     * @param visibilityId 用户选择的可见性权限id
     */
    void updateVisibility(Integer visibilityId);
}
