package com.fooffer.fooBackEnd.service.impl;

import com.fooffer.fooBackEnd.constant.ErrorReason;
import com.fooffer.fooBackEnd.constant.ResourceOperationType;
import com.fooffer.fooBackEnd.constant.ReturnCode;
import com.fooffer.fooBackEnd.constant.articles.ArticleVisibility;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.exception.cause.ExceptionCause;
import com.fooffer.fooBackEnd.mapper.EditorMapper;
import com.fooffer.fooBackEnd.model.dto.editor.EditorDto;
import com.fooffer.fooBackEnd.model.entity.ArticleContentDao;
import com.fooffer.fooBackEnd.model.entity.ArticleDao;
import com.fooffer.fooBackEnd.model.entity.ImageDao;
import com.fooffer.fooBackEnd.model.vo.EditorVo;
import com.fooffer.fooBackEnd.repository.ArticleContentRepository;
import com.fooffer.fooBackEnd.repository.EditorRepository;
import com.fooffer.fooBackEnd.service.intf.EditorService;
import com.fooffer.fooBackEnd.service.intf.ImageService;
import com.fooffer.fooBackEnd.utils.SnowflakeIdWorker;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;

import static com.fooffer.fooBackEnd.constant.articles.ArticleVisibility.EVERYONE_CAN_SEE;

/**
 * 实现Editor Service接口的方法
 */
@Service
@AllArgsConstructor
@Slf4j
public class EditorServiceImpl implements EditorService {

    private final EditorMapper editorMapper;

    private final EditorRepository editorRepository;

    private final ArticleContentRepository articleContentRepository;

    private final ImageService imageService;

    private final SnowflakeIdWorker snowflakeIdWorker = new SnowflakeIdWorker(7,6);

    /**
     * 根据请求数据，添加/更新/标记删除数据库中的文章
     *
     * @param editorVo 前端传来的请求
     */
    @Override
    public void saveAnArticle(
            EditorVo editorVo,
            ResourceOperationType operationType
    ) {
        EditorDto editorDto = editorMapper.vo2dto(editorVo);
        //转换文章可见性
        editorDto.setVisibility(ArticleVisibility.decode(editorVo.getVisibilityId()));

        // 新增文章
        if (operationType == ResourceOperationType.Post) {
            // 添加id和创作时间
            Long articleId = snowflakeIdWorker.nextId();
            editorDto.setArticleId(articleId);
            editorDto.setCreateTime(LocalDateTime.now());
            editorDto.setLatestUpdateTime(LocalDateTime.now());
            Long contentId = snowflakeIdWorker.nextId();
            editorDto.setContentId(contentId);

            addArticleAuthorToArticleDto(editorDto);

            storeArticleDao(editorDto);
            storeArticleContentDao(editorDto);
        }
        // 更新或标记删除则需要找到已有的Article Dao
        else if (
                operationType == ResourceOperationType.Patch ||
                operationType == ResourceOperationType.Delete
        ) {
            ArticleDao existingArticleDao = editorRepository.findArticleDaoByArticleId(editorDto.getArticleId()).orElseThrow(
                    () -> new BaseException(
                            ReturnCode.RC400,
                            ExceptionCause.builder()
                                    .domain("editor")
                                    .errorReason(ErrorReason.BAD_REQUEST)
                                    .build()
                            )

            );

            if (operationType == ResourceOperationType.Patch) {
                // 更新最后修改时间
                editorDto.setLatestUpdateTime(LocalDateTime.now());
                editorMapper.updateArticleDaoFromEditorDto(
                        existingArticleDao,
                        editorDto
                );

                ArticleContentDao existingArticleContentDao = articleContentRepository.findArticleContentDaoByContentId(existingArticleDao.getContentId());
                editorMapper.updateArticleContentDaoFromEditorDto(
                        existingArticleContentDao,
                        editorDto
                );
                articleContentRepository.save(existingArticleContentDao);
            }
            else { // 删除文章的请求

                // 把文章标记删除，并记录进数据库
                editorDto.setIsDeleted(true);
                editorMapper.updateArticleDaoFromEditorDto(existingArticleDao, editorDto);
            }
            editorRepository.save(existingArticleDao);
        }
    }

    /**
     * 保存文章过程中添加作者信息
     */
    private void addArticleAuthorToArticleDto(
            EditorDto editorDto
    ) {
        // 添加当前用户的userId为作者
        Long currentUserId = (Long) SecurityContextHolder.getContext().getAuthentication().getDetails();
        editorDto.setAuthorId(currentUserId);
    }

    /**
     * 将article dto转换成dao并保存到数据库里面
     * @param editorDto 包含文章的元数据
     */
    private void storeArticleDao (EditorDto editorDto) {
        // 将Dto转成articleDao，并存入DB
        ArticleDao articleDao = editorMapper.dto2dao(editorDto);

        editorRepository.save(articleDao);
    }

    /**
     * 将 editorDto 里面的数据保存到Article content表里面
     * @param editorDto editor dto包含的请求内容
     */
    private void storeArticleContentDao (EditorDto editorDto) {
        ArticleContentDao articleContentDao = editorMapper.dto2ContentDao(editorDto);
        articleContentRepository.save(articleContentDao);
    }

    /**
     * 接收上传的文章封面图片并生成链接
     *
     * @param coverImage
     * @param imageHash
     * @return
     * @throws BaseException
     */
    @Override
    public String updateCoverImage(
            MultipartFile coverImage,
            String imageHash
    ) throws BaseException {

        ImageDao imageDao = imageService.uploadImage(coverImage, imageHash);

        return imageDao.getUrl();
    }
}
