package com.fooffer.fooBackEnd.service.intf;

import com.fooffer.fooBackEnd.model.dto.ArticleDto;
import com.fooffer.fooBackEnd.model.vo.ArticleListRequestParams;
import com.fooffer.fooBackEnd.model.vo.ArticleResponseVo;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 文章列表接口
 */
@Service
public interface ArticleListService {

    /**
     * 搜索数据库中符合条件的多篇文章，并转换成Dto
     * @return db中的所有文章的dto
     */
    List<ArticleDto> getArticleDtoList(ArticleListRequestParams articleListRequestParams);

    /**
     * 搜索数据库所有的文章并转成ArticleResponseVo
     * @param articleListRequestParams 文章列表请求的参数
     * @return 数据库里面的所有的ArticleVo
     */
    List<ArticleResponseVo> getArticleResponseVoList(ArticleListRequestParams articleListRequestParams);
}
