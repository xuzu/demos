package com.fooffer.fooBackEnd.controller;

import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.service.intf.UserInformationService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 用于接收用户修改profile可见性的请求
 */
@RestController
@RequestMapping("/profile/visibility")
@AllArgsConstructor
@Slf4j
public class ProfileVisibilityController {

    private final UserInformationService userInformationService;

    @PostMapping("/update")
    public ResultData updateVisibility(@RequestParam(name = "id") Integer visibilityId){
        userInformationService.updateVisibility(visibilityId);
        return ResultData.success("用户信息可见性修改成功");
    }
}
