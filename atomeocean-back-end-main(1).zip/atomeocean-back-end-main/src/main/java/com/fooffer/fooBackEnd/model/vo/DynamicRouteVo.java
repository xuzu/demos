package com.fooffer.fooBackEnd.model.vo;

import lombok.Data;
import lombok.Builder;

import java.util.List;

/**
 * 动态路由
 * Vo：与前端交互
 */

@Data
@Builder
public class DynamicRouteVo {

    private Integer dynamicRouteId;

    private String path;

    private String name;

    private String component;

    private Integer parentRouteId; // 父节点id

    // 嵌套子路由
    private List<DynamicRouteVo> children;
}
