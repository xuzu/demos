package com.fooffer.fooBackEnd.model.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 前端在user register时候发送的数据封装类
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserVo {

    private String userId;

    private String username;
}
