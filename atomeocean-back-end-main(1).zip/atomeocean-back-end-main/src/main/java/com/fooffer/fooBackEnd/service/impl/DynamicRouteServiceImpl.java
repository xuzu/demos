package com.fooffer.fooBackEnd.service.impl;

import com.fooffer.fooBackEnd.mapper.DynamicRouteMapper;
import com.fooffer.fooBackEnd.model.dto.DynamicRouteDto;
import com.fooffer.fooBackEnd.model.entity.DynamicRouteDao;
import com.fooffer.fooBackEnd.model.vo.DynamicRouteVo;
import com.fooffer.fooBackEnd.repository.DynamicRouteRepository;
import com.fooffer.fooBackEnd.service.intf.DynamicRouteService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class DynamicRouteServiceImpl implements DynamicRouteService {
    private final DynamicRouteMapper dynamicRouteMapper;
    private final DynamicRouteRepository dynamicRouteRepository;

    @Autowired
    public DynamicRouteServiceImpl(DynamicRouteMapper dynamicRouteMapper, DynamicRouteRepository dynamicRouteRepository) {
        this.dynamicRouteMapper = dynamicRouteMapper;
        this.dynamicRouteRepository = dynamicRouteRepository;
    }

    @Override
    public DynamicRouteVo getDynamicRoutesByDynamicRouteId(Integer dynamicRouteId) {
        DynamicRouteDao dao = dynamicRouteRepository.findDynamicRouteDaoByDynamicRouteId(dynamicRouteId);

        DynamicRouteDto dto = dynamicRouteMapper.dao2dto(dao);

        DynamicRouteVo vo = dynamicRouteMapper.dto2vo(dto);

        return vo;
    }
}
