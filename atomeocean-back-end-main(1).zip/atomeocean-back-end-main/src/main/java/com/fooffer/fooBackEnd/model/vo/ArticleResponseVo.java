package com.fooffer.fooBackEnd.model.vo;


import com.fooffer.fooBackEnd.model.dto.article.ArticleAuthor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDate;
import java.util.List;

/**
 * 用于返回给前端article的数据类
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class ArticleResponseVo extends ArticleBaseVo {

    /**
     * web需要把过长的Long id变成string类型
     */
    private String articleId;

    /**
     * Key of title.
     */
    private String title;

    /**
     * 作者的信息
     */
    private ArticleAuthor articleAuthor;

    /**
     * 文章的摘要
     */
    private String collapsedContent;

    /**
     * Key of content.
     */
    private String contentId;

    /**
     * 文章的文本字符串
     */
    private String content;

    /**
     * Key of create date.
     * 转换成日期
     *
     */
    @Builder.Default
    private LocalDate createTime = LocalDate.now();

    private LocalDate latestUpdateTime;

    /**
     * 文章的总浏览数
     */
    private Integer viewCount;

    /**
     * 文章是否已经被删除
     * 默认文章存在，即false
     */
    @Builder.Default
    private Boolean isDeleted = false;

    private String categoryName;

    /**
     * 文章标签
     */
    private List<ArticleTagVo> articleTagList;

    /**
     * 文章封面图的链接
     */
    private String articleCoverImageLink;

    @Override
    public String toString() {
        return "Article vo { title" + title
                + ", createTime" + getCreateTime().toString();
    }
}

