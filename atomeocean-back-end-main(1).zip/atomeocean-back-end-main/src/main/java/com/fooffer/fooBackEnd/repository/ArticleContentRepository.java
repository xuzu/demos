package com.fooffer.fooBackEnd.repository;

import com.fooffer.fooBackEnd.model.entity.ArticleContentDao;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ArticleContentRepository extends MongoRepository<ArticleContentDao, Long> {

    // 根据contentId进行查询
    ArticleContentDao findArticleContentDaoByContentId(Long contentId);
}
