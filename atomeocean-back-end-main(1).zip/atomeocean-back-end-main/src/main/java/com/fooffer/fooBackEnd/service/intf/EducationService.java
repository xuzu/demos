package com.fooffer.fooBackEnd.service.intf;

import com.fooffer.fooBackEnd.constant.ResourceOperationType;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.vo.EducationVo;
import org.springframework.stereotype.Service;

/**
 * 用户教育经历相关Service
 */
@Service
public interface EducationService {
    /**
     * 检查用户输入的教育经历信息，如果符合要求则创建教育经历并存入数据库
     */
    ResultData createEducation(EducationVo educationVo) throws BaseException;

    /**
     * 检查用户输入的教育经历信息，如果符合要求则修改对应的教育经历(修改内容或删除)
     * operation post：修改内容
     * operation delete：删除经历
     */
    ResultData modifyEducation(EducationVo educationVo, ResourceOperationType operation) throws BaseException;

}
