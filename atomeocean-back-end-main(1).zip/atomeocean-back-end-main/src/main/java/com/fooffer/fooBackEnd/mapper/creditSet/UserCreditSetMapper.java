package com.fooffer.fooBackEnd.mapper.creditSet;

import org.mapstruct.Mapper;


import com.fooffer.fooBackEnd.model.dto.creditSet.UserCreditSetDto;
import com.fooffer.fooBackEnd.model.entity.creditSet.UserCreditSetDao;
import com.fooffer.fooBackEnd.model.vo.creditSet.UserCreditSetVo;



/**
 * user creditSet 对应的mapper
 */
@Mapper(componentModel = "spring")
public interface UserCreditSetMapper {
    UserCreditSetDto vo2dto(UserCreditSetVo userCreditSetVo);

    UserCreditSetVo dto2vo(UserCreditSetDto userCreditSetDto);

    UserCreditSetDao dto2dao(UserCreditSetDto userCreditSetDto);

    UserCreditSetDto dao2dto(UserCreditSetDao userCreditSetDao);
}
