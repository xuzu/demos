package com.fooffer.fooBackEnd.mapper.creditSet;

import com.fooffer.fooBackEnd.model.dto.creditSet.ShellTransactionStatementDto;
import com.fooffer.fooBackEnd.model.entity.creditSet.ShellTransactionStatementDao;
import com.fooffer.fooBackEnd.model.vo.creditSet.ShellTransactionStatementVo;
import org.mapstruct.Mapper;


/**
 * shell交易明细 对应的mapper
 */
@Mapper(componentModel = "spring")
public interface ShellTransactionStatementMapper {

    ShellTransactionStatementDto dao2dto(ShellTransactionStatementDao shellTransactionStatementDao);

    ShellTransactionStatementVo dto2vo(ShellTransactionStatementDto shellTransactionStatementDto);
}
