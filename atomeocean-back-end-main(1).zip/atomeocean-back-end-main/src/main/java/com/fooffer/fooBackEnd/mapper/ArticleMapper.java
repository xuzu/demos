package com.fooffer.fooBackEnd.mapper;

import com.fooffer.fooBackEnd.model.dto.ArticleDto;
import com.fooffer.fooBackEnd.model.entity.ArticleContentDao;
import com.fooffer.fooBackEnd.model.entity.ArticleTagDao;
import com.fooffer.fooBackEnd.model.dto.article.ArticleTagDto;
import com.fooffer.fooBackEnd.model.entity.ArticleDao;
import com.fooffer.fooBackEnd.model.vo.ArticleResponseVo;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.util.List;


/**
 * ArticleDao -> ArticleDto
 * ArticleDto -> ArticleResponseVo
 * 如果映射pojo自身field为null，将不会被map到被映射pojo
 */
@Mapper(
        componentModel = "spring",
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
)
public interface ArticleMapper {

    ArticleMapper INSTANCE = Mappers.getMapper(ArticleMapper.class);

    /**
     * articleDao -> articleDto
     * @param articleDao
     * @return
     */
    ArticleDto dao2dto(ArticleDao articleDao);

    /**
     * 将article dto的信息传入倒tag dao里面
     * @param articleDto 含有id，title等信息
     * @return tag dao，可传入tag collection
     */
    ArticleTagDao dto2TagDao(ArticleTagDto articleDto);

    /**
     * article， article content Dao， 和article Tag Dao 合并转换成dto
     * @param dao
     * @param contentDao
     * @return article Dto
     */
    @Mappings({
            @Mapping(source = "contentDao.content", target = "content"),
            @Mapping(source = "dao.contentId", target = "contentId"),
            @Mapping(source = "dao.articleId", target = "articleId"),
            @Mapping(source = "dao.title", target = "title"),
            @Mapping(source = "dao.collapsedContent", target = "collapsedContent"),
            @Mapping(source = "dao.articleTagList", target = "articleTagList"),

    })
    ArticleDto mergeDao2dto(ArticleDao dao, ArticleContentDao contentDao, List<ArticleTagDao> tagDaoList);

    @Mappings(
            @Mapping(source = "articleDto.articleTagList", target = "articleTagList")
    )
    ArticleResponseVo dto2vo(ArticleDto articleDto);

    /**
     * 将article dto -> article response vo
     * @param articleDtos
     * @return ResponseVo 列表
     */
    List<ArticleResponseVo> dto2ResponseVoList(List<ArticleDto> articleDtos);


}


