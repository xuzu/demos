package com.fooffer.fooBackEnd.model.vo.creditSet;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ShellTransactionStatementVo {

    private Long shellTransactionStatementId;

    private Long userId;

    private Long amount;

    private LocalDateTime timestamp;

    private String description;
}
