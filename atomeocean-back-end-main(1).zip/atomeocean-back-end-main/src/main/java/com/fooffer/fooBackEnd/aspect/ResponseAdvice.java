package com.fooffer.fooBackEnd.aspect;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fooffer.fooBackEnd.model.ResultData;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

/**
 * 自动扫描所有的rest controller，对返回的数据进行预处理
 * @RestControllerAdvice是 @RestController注解的增强，可以实现三个方面的功能：
 *
 * 全局异常处理
 * 全局数据绑定
 * 全局数据预处理，扫描整个包，对所有RestController的返回的数据做预处理
 */
@RestControllerAdvice
@Slf4j
public class ResponseAdvice implements ResponseBodyAdvice<Object> {

    /**
     * jackson工具object mapper会把object里面的key value写成json格式。
     */
    @Autowired
    private ObjectMapper objectMapper;

    /**
     * 实现为true，表示支持使用这个advice
     * @param returnType
     * @param converterType
     * @return
     */
    @Override
    public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
        return true;
    }

    /**
     * 这个方法是扫描全局，对rest controller返回的数据进行预处理。
     * 添加sneaky throws是因为writeValueAsString方法需要抛出异常
     * @param body
     * @param returnType
     * @param selectedContentType
     * @param selectedConverterType
     * @param request
     * @param response
     * @return
     */
    @SneakyThrows
    @Override
    public Object beforeBodyWrite(
            Object body, MethodParameter returnType,
            MediaType selectedContentType,
            Class<? extends HttpMessageConverter<?>> selectedConverterType,
            ServerHttpRequest request,
            ServerHttpResponse response
    ) {
        // 这个if是因为springboot会直接返回string，我们这里手动转成json string
        if (body instanceof String) {
            return objectMapper.writeValueAsString(ResultData.success(body));
        }
        // 保证不对抛出的异常做多余的再封装
        if (body instanceof ResultData) {
            return body;
        }

        return ResultData.success(body);
    }
}
