package com.fooffer.fooBackEnd.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 用户角色信息
 * spring security会自动给role name添加ROLE_前缀
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserRoleDto {

    /**
     * 角色id
     */
    private Integer roleId;

    /**
     * 角色名称
     */
    private String roleName;

    /**
     * 可以有权限访问到的动态路由id列表
     */
    private List<Integer> dynamicRouteIds;

    /**
     * 可以有权限访问到的动态路由name列表
     */
    private List<String> dynamicRouteNames;
}
