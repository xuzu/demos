package com.fooffer.fooBackEnd.constant.userInformation;

/**
 * 用户信息格式检查使用的常量
 */
public class DataValidationConstant {

    /* nickname start */
    public static final int NICKNAME_MIN_LENGTH = 2;

    public static final String NICKNAME_MIN_LENGTH_MESSAGE = "名字太短";

    public static final int NICKNAME_MAX_LENGTH = 20;

    public static final String NICKNAME_MAX_LENGTH_MESSAGE = "名字过长";

    /* nickname end */

    /* motto start */
    public static final int MOTTO_MAX_LENGTH = 40;

    public static final String MOTTO_MAX_LENGTH_MESSAGE = "简介过长";

    /* motto end */


    /* self introduction start */
    public static final int SELF_INTRODUCTION_MAX_LENGTH = 300;

    public static final String SELF_INTRODUCTION_MAX_LENGTH_MESSAGE = "自我介绍过长";

    /* self introduction end */
}
