package com.fooffer.fooBackEnd.repository;

import com.fooffer.fooBackEnd.model.entity.UserDao;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * 对数据库中users collection进行操作
 */
@Repository
public interface UserRepository extends MongoRepository<UserDao, Long> {

    // 通过用户名获取用户
    UserDao findUserDaoByUserEmail(String userEmail);
    // 通过用户id获取用户
    UserDao findUserDaoByUserId(Long userId);
}
