package com.fooffer.fooBackEnd.utils;

import cn.hutool.core.io.FileTypeUtil;
import com.fooffer.fooBackEnd.constant.ErrorReason;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.exception.cause.ExceptionCause;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;

import static com.fooffer.fooBackEnd.constant.ReturnCode.FILE_ERROR;
import static com.fooffer.fooBackEnd.constant.file.FileType.*;

@Slf4j
public class FileTypeUtils {

    //利用hutool工具类中的方法重新封装传入的文件类型
    public static String getFileType(MultipartFile multipartFile) {
        try {
            InputStream inputStream = multipartFile.getInputStream();
            String type = FileTypeUtil.getType(inputStream);
            String upperCaseType = type.toUpperCase();

            if (isImageType(upperCaseType)) {
                return IMAGE_TYPE+type;
            }
            if (isAudioType(upperCaseType)) {
                return AUDIO_TYPE+type;
            }
            if (isVideoType(upperCaseType)) {
                return VIDEO_TYPE+type;
            }
            if (isApplicationType(upperCaseType)) {
                return APPLICATION_TYPE+type;
            }
            if (isTxtType(upperCaseType)) {
                return TXT_TYPE+type;
            }
        } catch (IOException e) {
            ExceptionCause exceptionCause = new ExceptionCause("general error", ErrorReason.FILE_ERROR);
            throw new BaseException(FILE_ERROR, exceptionCause, e.getMessage(), e.getCause());
        }
        return null;
    }
}
