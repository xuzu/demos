package com.fooffer.fooBackEnd.utils;

import com.fooffer.fooBackEnd.constant.ErrorReason;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.exception.cause.ExceptionCause;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import javax.mail.internet.MimeMessage;

import static com.fooffer.fooBackEnd.constant.ReturnCode.EMAIL_SEND_FAILED;

@Component
@Slf4j
public class EmailSenderUtil {

    public static JavaMailSender javaMailSender;
    private static TemplateEngine templateEngine;
    private static String sender;
    private static final String VERIFICATION_TEMPLATE = "verification.html";
    private static final String RESET_TEMPLATE = "resetVerification.html";

    @Autowired
    public EmailSenderUtil(
            JavaMailSender javaMailSender,
            TemplateEngine templateEngine,
            @Value("${spring.mail.userEmail}") String sender
    ){
        this.javaMailSender = javaMailSender;
        this.templateEngine = templateEngine;
        this.sender = sender;
    }

    /**
     * (账号注册)发送验证邮箱的邮件
     * @param receiver 输入的用户邮件
     * @param code 验证码
     * @param template 邮件模板 (verification / resetPassword)
     * @return boolean值表示邮件是否发送成功
     */
    public static void sendVerificationEmail(String receiver, String code, String template) throws BaseException {
        try {
            MimeMessage mimeMessage = javaMailSender.createMimeMessage();
            //解决thymeleaf中文乱码问题
            MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true, "UTF-8");

            //设置邮件信息
            mimeMessageHelper.setFrom(sender);
            mimeMessageHelper.setTo(receiver);
            mimeMessageHelper.setSubject("验证邮件");

            //设置邮件thymeleaf模板参数
            Context context = new Context();
            context.setVariable("code", code);

            //选择邮件模板
            String process;
            if (template == "verification"){
                process = templateEngine.process(VERIFICATION_TEMPLATE, context);
            }
            else{
                process = templateEngine.process(RESET_TEMPLATE, context);
            }
            mimeMessageHelper.setText(process,true);
            javaMailSender.send(mimeMessage);

        } catch (Exception e) {
            ExceptionCause exceptionCause = new ExceptionCause("sign up", ErrorReason.EMAIL_SEND_FAILED);
            throw new BaseException(EMAIL_SEND_FAILED, exceptionCause, e.getMessage(), e.getCause());
        }
    }

}
