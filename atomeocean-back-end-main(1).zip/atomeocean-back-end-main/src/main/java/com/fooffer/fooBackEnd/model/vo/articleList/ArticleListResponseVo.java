package com.fooffer.fooBackEnd.model.vo.articleList;

import com.fooffer.fooBackEnd.model.vo.ArticleResponseVo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 定义返回给前端的vo
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ArticleListResponseVo {

    /**
     * 文章列表
     */
    private List<ArticleResponseVo> articleList;

    /**
     * 分页用的token
     */
    private String paginationToken;
}
