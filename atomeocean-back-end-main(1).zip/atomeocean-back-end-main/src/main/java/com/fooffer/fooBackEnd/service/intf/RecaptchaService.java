package com.fooffer.fooBackEnd.service.intf;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fooffer.fooBackEnd.model.RecaptchaResponse;
import org.springframework.stereotype.Service;

@Service
public interface RecaptchaService {
    /**
     * 向Google发送验证recaptcha token的请求
     * 并获取验证结果
     */
    RecaptchaResponse validateToken(String recaptchaToken) throws JsonProcessingException;
}
