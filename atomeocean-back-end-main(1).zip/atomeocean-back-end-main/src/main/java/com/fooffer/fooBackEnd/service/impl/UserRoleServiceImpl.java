package com.fooffer.fooBackEnd.service.impl;

import com.fooffer.fooBackEnd.mapper.UserRoleMapper;
import com.fooffer.fooBackEnd.model.dto.UserRoleDto;
import com.fooffer.fooBackEnd.model.entity.UserRoleDao;
import com.fooffer.fooBackEnd.model.vo.UserRoleVo;
import com.fooffer.fooBackEnd.repository.UserRoleRepository;
import com.fooffer.fooBackEnd.service.intf.UserRoleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class UserRoleServiceImpl implements UserRoleService {


    public final UserRoleRepository userRoleRepository;

    private final UserRoleMapper userRoleMapper;

    @Autowired
    public UserRoleServiceImpl(UserRoleRepository userRoleRepository, UserRoleMapper userRoleMapper) {
        this.userRoleRepository = userRoleRepository;
        this.userRoleMapper = userRoleMapper;
    }

    @Override
    public void createRole(UserRoleVo userRoleVo) {

        UserRoleDto userRoleDto = userRoleMapper.vo2dto(userRoleVo);

        UserRoleDao userRoleDao = userRoleMapper.dto2dao(userRoleDto);

        userRoleRepository.save(userRoleDao);
    }

    @Override
    public UserRoleDao findRoleByRoleName(String authority) {
        return userRoleRepository.findUserRoleDaoByRoleName(authority);
    }

    @Override
    public List<UserRoleVo> findAllRoles() {
        List<UserRoleDao> userRoleDaoList = userRoleRepository.findAll();

        List<UserRoleDto> userRoleDtoList = userRoleMapper.daoList2dtoList(userRoleDaoList);

        List<UserRoleVo> userRoleVoList = userRoleMapper.dtoList2voList(userRoleDtoList);

        return userRoleVoList;
    }
}
