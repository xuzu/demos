package com.fooffer.fooBackEnd.utils;

import org.springframework.stereotype.Service;

//数字进制转化工具，目前用于长数字uid和62进制短id之间的转换
@Service
public class NumConvertUtil {

    //62进制转换
    private static String CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    private static int SCALE = 62;
    private static String REGEX = "^[0-9A-Za-z]+$";

    /**
     * 10进制数字转为62进制字符串，允许设置最小长度，
     * 如果转换结果不足最小长度则从左边开始以0补齐
     * 举例：转换结果是7sA3，要求最小长度8 -> 00007sA3
     * 
     * @param num 10进制数字
     * @param length 字符串的最小长度
     * @return 62进制字符串
     */
    public static String encode10To62(long num, int length) {

        //转换至62位字符串 
        String s = encode10To62(num);
        if (s.length() >= length) {
            return s;
        }

        //补足长度
        StringBuilder sb = new StringBuilder();
        while (sb.length() < length - s.length()) {
            sb.append('0');
        }
        sb.append(s);
        return sb.toString();
    }

    /**
     * 10进制数字转为62进制字符串，不设置最小长度
     *
     * @param num 10进制数字
     * @return 62进制字符串
     */
    public static String encode10To62(long num) {
        if (num < 0) {
            throw new IllegalArgumentException("this is an Invalid parameter:" + num);
        }

        StringBuilder sb = new StringBuilder();
        int remainder = 0;
        while (Math.abs(num) > SCALE - 1) {
            //从最后一位开始进制转换，取转换后的值，最后反转字符串
            remainder = Long.valueOf(num % SCALE).intValue();
            sb.append(CHARS.charAt(remainder));
            num = num / SCALE;
        }
        //获取最高位
        sb.append(CHARS.charAt(Long.valueOf(num).intValue()));
        return sb.reverse().toString();
    }

    /**
     * 62进制字符串转为10进制数字
     *
     * @param s 62进制字符串
     * @return 10进制数字
     */
    public static long decode62To10(String s) {
        if (s == null) {
            throw new NumberFormatException("null");
        }

        if (!s.matches(REGEX)) {
            throw new IllegalArgumentException("this is an Invalid parameter:" + s);
        }
        
        //替换0开头的字符串
        String tmp = s.replace("^0*", "");

        long result = 0;
        int index = 0;
        int length = tmp.length();
        
        //按62进制逐个计算每个字符的值
        for (int i = 0; i < length; i++) {   
            //获取字符 -> 获取字符在CHARS里对应的数值 -> 根据数位乘算
            index = CHARS.indexOf(tmp.charAt(i));
            result += (long)(index * Math.pow(SCALE, length - i - 1));
        }

        return result;
    }

    // 测试使用
    public static void main(String[] args) {
        System.out.println(encode10To62(Long.valueOf("868416343489011713")));
    }
}
