package com.fooffer.fooBackEnd.service.intf;


import com.fooffer.fooBackEnd.aspect.errorHandler.articleGeneral.InvalidArticleIdException;
import com.fooffer.fooBackEnd.model.dto.article.ArticleAuthor;
import com.fooffer.fooBackEnd.model.vo.ArticleResponseVo;
import org.springframework.stereotype.Service;

/**
 * 定义关于article的操作
 * 它操作article repository对db进行修改
 */
@Service
public interface ArticleService {

    /**
     * 根据id获取文章
     * @param articleId 前端请求url里面文章id，类型为string
     * @return 查询的结果，并转换成ArticleResponseVo
     */
    ArticleResponseVo getArticle(String articleId) throws InvalidArticleIdException;

    /**
     * 根据id获取文章
     * @param articleId 前端请求url里面文章id，类型为string
     * @return 查询的结果，并转换成ArticleResponseVo
     */
    ArticleResponseVo getArticle(String articleId, String ip) throws InvalidArticleIdException;

    /**
     * 同步Redis中文章浏览量到MongoDB
     *
     */
    void synchronizeViewCounts();

    /**
     * 根据文章的view count key获取浏览量
     * @param viewCountKey "viewCount: %s", articleId
     * @return 返回redis中文章独特访客数量
     */
    long getUniqViewCount(String viewCountKey);

    /**
     * 根据作者的id获取到作者其他信息
     * @param authorId 作者userId
     * @return 文章中作者的dto ArticleAuthor
     */
    ArticleAuthor getArticleAuthorByAuthorId(Long authorId);
}
