package com.fooffer.fooBackEnd.aspect.errorHandler;

import com.fooffer.fooBackEnd.constant.ReturnCode;
import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.model.ResultData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;


/**
 * 全局异常处理器
 */
@Slf4j
@RestControllerAdvice
public class RestExceptionHandler {

    /**
     * 默认全局异常处理，可以给异常添加信息，而且它是早于ResponseAdvice对返回的数据进行处理的
     * @param e 抛出的异常
     * @return ResultData
     *
     *  @ExceptionHandler,统一处理某一类异常，从而减少代码重复率和复杂度，比如要获取自定义异常可以
     *  @ExceptionHandler(BusinessException.class)
     *  @ResponseStatus指定客户端收到的http状态码
     */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResultData<String> exception(Exception e) {
        log.error("全局异常信息 ex = {}", e.getMessage(), e);
        // 指定前端收到500的状态码
        return ResultData.fail(ReturnCode.RC500.getCode(), e.getMessage());
    }

    /**
     * 处理业务逻辑中抛出的BaseException异常
     * log打印异常产生的原因，并将封装好的ReturnCode返回给前端
     * @param e 抛出的BaseException
     * @return ResultData
     */
    @ExceptionHandler(BaseException.class)
    public ResultData<String> baseException(BaseException e){
        //打印自定义的exception cause
        log.error("Error Domain: " + e.getExceptionCause().getDomain());
        log.error("Error Reason: " + e.getExceptionCause().getErrorReason().getMessage());

        //若为Java封装异常，将cause信息打印
        String causeMessage = e.getCause() == null ? "业务逻辑异常" : e.getCause().getMessage();
        log.error(causeMessage);

        //返回异常信息
        return new ResultData(e.getReturnCode());
    }


    /**
     * 处理validated注解抛出的异常
     * @param methodArgumentNotValidException 抛出的异常
     * @return ResultData
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResultData methodArgumentNotValidException(MethodArgumentNotValidException methodArgumentNotValidException){

        log.error("MethodArgumentNotValidException: {}", methodArgumentNotValidException.getMessage());

        //返回异常信息
        return new ResultData(ReturnCode.MISSING_PARAMETER);
    }
}