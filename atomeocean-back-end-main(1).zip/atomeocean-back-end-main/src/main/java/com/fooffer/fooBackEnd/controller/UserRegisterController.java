package com.fooffer.fooBackEnd.controller;

import com.fooffer.fooBackEnd.exception.BaseException;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.model.vo.EmailAuthVo;
import com.fooffer.fooBackEnd.service.intf.UserRegisterService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * 用户注册接口
 */
@RestController
@AllArgsConstructor
@RequestMapping("/signup")
@Slf4j
public class UserRegisterController {

    private final UserRegisterService userRegisterService;

    /**
     * 用户注册接口
     * @param registerUser 提交的user注册信息
     * @return 通知前端注册是否成功
     */
    @PostMapping("/email/register")

    public ResultData registerUser(
            @RequestBody @Validated EmailAuthVo registerUser
    ) {

        //向service发送请求，添加新的待验证用户
        return userRegisterService.saveUnverifiedNewUser(registerUser);
    }


    /**
     * 账户验证接口
     * @param email 用户注册邮箱
     * @param code 验证用户账户的验证码
     * @return 通知前端账户验证是否成功
     */
    @PostMapping("/email/verify")
    public ResultData verifyUserEmail(
            @RequestParam(name = "email") String email,
            @RequestParam(name = "code") String code
    ) throws BaseException {

        return userRegisterService.saveVerifiedNewUser(email, code);
    }
}
