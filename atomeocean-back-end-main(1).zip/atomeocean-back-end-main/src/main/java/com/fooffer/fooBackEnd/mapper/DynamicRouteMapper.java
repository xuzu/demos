package com.fooffer.fooBackEnd.mapper;

import com.fooffer.fooBackEnd.model.dto.DynamicRouteDto;
import com.fooffer.fooBackEnd.model.entity.DynamicRouteDao;
import com.fooffer.fooBackEnd.model.vo.DynamicRouteVo;
import org.mapstruct.Mapper;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.factory.Mappers;

/**
 * 动态路由表的mapper
 * vo <-> dto <-> dao
 */
@Mapper(
        componentModel = "spring",
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
)
public interface DynamicRouteMapper {

    DynamicRouteDto dao2dto(DynamicRouteDao dynamicRouteDao);

    DynamicRouteDao dto2dao(DynamicRouteDto dynamicRouteDto);

    DynamicRouteVo dto2vo(DynamicRouteDto dynamicRouteDto);

    DynamicRouteDto vo2dto(DynamicRouteVo dynamicRouteVo);
}
