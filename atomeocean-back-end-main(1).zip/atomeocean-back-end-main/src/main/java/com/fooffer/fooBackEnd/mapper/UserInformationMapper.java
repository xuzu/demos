package com.fooffer.fooBackEnd.mapper;

import com.fooffer.fooBackEnd.model.dto.UserInformationDto;
import com.fooffer.fooBackEnd.model.entity.UserInformationDao;
import com.fooffer.fooBackEnd.model.vo.UserInformationVo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;
/**
 * user information 对应的mapper
 */
@Mapper(componentModel = "spring")
public interface UserInformationMapper {

    @Mappings({
            @Mapping(source = "userInformationDto.educationDtoSet", target = "educationVoSet"),
            @Mapping(source = "userInformationDto.careerDtoSet", target = "careerVoSet")
    })
    UserInformationVo dto2vo(UserInformationDto userInformationDto);

    UserInformationDto vo2dto(UserInformationVo userInformationVo);

    List<UserInformationVo> dto2voList(List<UserInformationDto> userinfoDtoList);

    List<UserInformationDto> vo2dtoList(List<UserInformationVo> userInformationVoList);

    UserInformationDao dto2dao(UserInformationDto userInformationDto);

    UserInformationDto dao2dto(UserInformationDao userInformationDao);

    List<UserInformationDao> dto2daoList(List<UserInformationDto> userInformationDtoList);

    List<UserInformationDto> dao2dtoList(List<UserInformationDto> userinfoDtoList);
}
