package com.fooffer.fooBackEnd.utils;

import static com.fooffer.fooBackEnd.constant.CodeSequenceBase.CodeSequenceBase.CHECK_CODE_SEQUENCE_BASE;
import static com.fooffer.fooBackEnd.constant.CodeSequenceBase.CodeSequenceBase.PHONE_CODE_SEQUENCE_BASE;

public class CaptchaGenerator {

    private static final int DEFAULT_LENGTH = 6;

    /**
     * 根据提供的序列基数组随机生成指定长度的验证码
     * @param codeLength 验证码位数
     * @param codeSequence  验证码序列基数组
     * @return
     */
    private static String getValidateCode(int codeLength, char []codeSequence){
        String randomCode = "";
        for (int i = 0; i < codeLength; i++) {
            randomCode += codeSequence[(int) Math.floor(Math.random()*(codeSequence.length))];
        }
        return randomCode;
    }

    /**
     * 生成指定长度的验证码
     * @param codeLength 验证码位数
     * @return
     */
    public static String generateValidateCode(int codeLength){
        return getValidateCode(codeLength, CHECK_CODE_SEQUENCE_BASE);
    }

    /**
     * 生成默认长度的验证码
     * @return
     */
    public static String generateValidateCode(){
        return getValidateCode(DEFAULT_LENGTH, CHECK_CODE_SEQUENCE_BASE);
    }

    /**
     * 生成默认长度的手机验证码
     * @return
     */
    public static String generatePhoneCode(){
        return getValidateCode(DEFAULT_LENGTH, PHONE_CODE_SEQUENCE_BASE);
    }
}
