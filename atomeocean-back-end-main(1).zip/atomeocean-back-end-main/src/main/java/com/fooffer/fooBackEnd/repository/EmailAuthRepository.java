package com.fooffer.fooBackEnd.repository;

import com.fooffer.fooBackEnd.model.entity.EmailAuthDao;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;


import java.util.Optional;

/**
 * 对数据库中EmailAuthUser collection进行操作
 */
@Repository
public interface EmailAuthRepository extends MongoRepository<EmailAuthDao, Long> {
    // 通过用户邮箱获取用户注册信息

    Optional<EmailAuthDao> findEmailAuthDaoByUserEmail(String userEmail);

    // 通过Email Auth id获取用户注册信息
    Optional<EmailAuthDao> findEmailAuthDaoByEmailAuthId(Long userAuthId);
}
