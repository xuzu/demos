package com.fooffer.fooBackEnd.constant.articles;

/**
 * 文章请求需要的常量
 */
public class ArticleRequestConstant {

    public static final Integer DEFAULT_LIMIT = 20;

    // 同个ip在25小时(90000s)只计算一次相同文章的view
    public static final Integer ARTICLE_VIEW_EXPIRED_TIME = 90000;

    public static final String USER_IP_ADDRESS = "X-Forwarded-For";


}
