package com.fooffer.fooBackEnd.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fooffer.fooBackEnd.model.ResultData;
import com.fooffer.fooBackEnd.utils.JwtTokenUtils;
import io.jsonwebtoken.ExpiredJwtException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Collection;

import static com.fooffer.fooBackEnd.constant.ErrorReason.TOKEN_EXPIRED;
import static com.fooffer.fooBackEnd.constant.ReturnCode.INVALID_TOKEN;
import static com.fooffer.fooBackEnd.constant.security.JwtTokenConstant.TOKEN_HEADER;
import static com.fooffer.fooBackEnd.constant.security.JwtTokenConstant.TOKEN_PREFIX;

/**
 * 在authentication filter生成token后，提取出token的信息
 * 验证用户的role
 */
@Slf4j
public class EmailPasswordAuthorizationFilter extends BasicAuthenticationFilter {
    public EmailPasswordAuthorizationFilter(AuthenticationManager authenticationManager) {
        super(authenticationManager);
    }

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain chain
    ) throws IOException, ServletException {
        String tokenHeader = request.getHeader(TOKEN_HEADER);

        // request header中没有authorization信息直接放行
        if (tokenHeader == null || !tokenHeader.startsWith(TOKEN_PREFIX)) {
            chain.doFilter(request, response);
            return;
        }

        // 如果请求头中有token，则进行解析，并且设置认证信息
        // 如果token失效，返回1007给前端
        try {
            SecurityContextHolder.getContext().setAuthentication(getAuthentication(tokenHeader));
            chain.doFilter(request, response);
        } catch (ExpiredJwtException error) {
            //为token过期用户自动logout
            new SecurityContextLogoutHandler().logout(request, response, null);
            String body = new ObjectMapper().writeValueAsString(ResultData.fail(INVALID_TOKEN.getCode(), TOKEN_EXPIRED.getMessage()));
            log.error("Error Domain: login");
            log.error("Error Reason: " + TOKEN_EXPIRED.getMessage());
            response.getWriter().write(body);
        }
    }

    /**
     * 从token中获取用户信息并新建一个token
     * @param tokenHeader 在请求头中的token
     * @return 新建的一个token
     */
    private EmailPasswordAuthenticationToken getAuthentication(String tokenHeader) {
        String token = tokenHeader.replace(TOKEN_PREFIX, "");

        // 从token payload中读取信息
        String userEmail = JwtTokenUtils.getUserEmail(token);

        Collection<? extends GrantedAuthority> roles = JwtTokenUtils
                .getUserRoles(token);
        if (userEmail != null) {
            EmailPasswordAuthenticationToken emailPasswordAuthenticationToken =  new EmailPasswordAuthenticationToken(
                    userEmail,
                    null,
                    roles
            );
            // 将User id添加到token detail中
            emailPasswordAuthenticationToken.setDetails(JwtTokenUtils.getUserId(token));
            return emailPasswordAuthenticationToken;
        }
        return null;
    }
}