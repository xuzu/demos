package com.fooffer.fooBackEnd.mapper;

import com.fooffer.fooBackEnd.model.dto.UserRoleDto;
import com.fooffer.fooBackEnd.model.entity.UserRoleDao;
import com.fooffer.fooBackEnd.model.vo.UserRoleVo;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * user role对应的mapper
 */
@Mapper(componentModel = "spring")
public interface UserRoleMapper {

    UserRoleMapper INSTANCE = Mappers.getMapper(UserRoleMapper.class);

    UserRoleVo dto2vo(UserRoleDto userRoleDto);

    UserRoleDto vo2dto(UserRoleVo userRoleVo);

    UserRoleDao dto2dao(UserRoleDto userRoleDto);

    UserRoleDto dao2dto(UserRoleDao userRoleDao);

    List<UserRoleVo> dtoList2voList(List<UserRoleDto> userRoleDtoList);

    List<UserRoleDto> daoList2dtoList(List<UserRoleDao> userRoleDaoList);
}
