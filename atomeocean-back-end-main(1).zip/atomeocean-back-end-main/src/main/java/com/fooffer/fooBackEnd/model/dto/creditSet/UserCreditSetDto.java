package com.fooffer.fooBackEnd.model.dto.creditSet;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Builder;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserCreditSetDto {

    private Long userId;

    private Long shell;
}
