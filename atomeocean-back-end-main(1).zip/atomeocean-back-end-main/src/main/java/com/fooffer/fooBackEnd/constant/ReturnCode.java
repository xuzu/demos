package com.fooffer.fooBackEnd.constant;

/**
 * 返回给前端的状态码
 */
public enum ReturnCode {
    /**操作成功**/
    RC100(100,"操作成功"),

    /**服务限流**/
    RC200(200,"服务开启限流保护,请稍后再试!"),
    /**服务降级**/
    RC201(201,"服务开启降级保护,请稍后再试!"),
    /**热点参数限流**/
    RC202(202,"热点参数限流,请稍后再试!"),
    /**系统规则不满足**/
    RC203(203,"系统规则不满足要求,请稍后再试!"),
    /**授权规则不通过**/
    RC204(204,"授权规则不通过,请稍后再试!"),

    /**服务错误**/
    RC400(400, "服务出错"),

    /**服务异常**/
    RC500(500,"系统异常，请稍后重试"),

    /**通用错误**/
    RECAPTCHA_VERIFICAITON_FAILED(601, "recaptcha验证失败"),

    /**操作失败**/
    RC999(999,"操作失败"),

    /**用户异常(注册，登录，账户异常，用户信息异常等)**/
    CLIENT_AUTHENTICATION_FAILED(1001,"客户端认证失败"),
    USERNAME_OR_PASSWORD_ERROR(1002,"用户名或密码错误"),
    PERMISSION_DENIED(1003, "无访问权限"),
    MISSING_PARAMETER(1004, "用户输入缺失参数"),
    ACCOUNT_EXIST(1005, "该账户已存在"),
    EMAIL_SEND_FAILED(1006, "邮件发送失败"),
    INVALID_TOKEN(1007,"访问令牌不合法"),
    ACCESS_DENIED(1008,"没有权限访问该资源，请联系管理员授予权限"),
    INVALID_REFER_ID(1009, "您的邀请链接不可用"),
    CODE_EXPIRED(1010, "您的验证码已过期"),
    INVALID_CODE(1011, "验证码错误"),
    REGISTRATION_EXPIRED(1012, "您的注册信息已过期，请重新完成注册"),
    INVALID_PASSWORD(1013, "登录密码错误"),
    INVALID_EMAIL(1014, "用户邮箱不存在"),
    ACCOUNT_NOT_EXIST(1015, "该账户不存在"),
    FILE_ERROR(1016, "文件异常"),
    FILE_UPLOAD_FAILED(1017, "文件上传失败"),
    EDUCATION_EXIST(1018, "该教育经历已存在"),
    EDUCATION_NOT_EXIST(1019, "该教育经历不存在"),
    CAREER_EXIST(1020, "该工作经历已存在"),
    CAREER_NOT_EXIST(1021, "该工作经历不存在"),
    MODIFY_NAME_TOO_OFTEN(1022, "两次修改名字之间需间隔至少60天"),
    INSUFFICIENT_CREDIT(1023, "用户积分不足"),
    COMMENT_NOT_EXIST(1024, "评论不存在");

    /**自定义状态码**/
    private final int code;
    /**自定义描述**/
    private final String message;

    ReturnCode(int code, String message){
        this.code = code;
        this.message = message;
    }


    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}