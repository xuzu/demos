package com.fooffer.fooBackEnd.model.dto;

import java.util.Set;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Builder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserInformationDto {

    private String nickname;

    private String motto;

    private String avatarLink;
    
    private String selfIntroduction;

    private int visibilityId;

    private Set<EducationDto> educationDtoSet;

    private Set<CareerDto> careerDtoSet;

    @Override
    public String toString() {
        return "UserInformation dto { nickname" + nickname + "motto" + motto + "selfIntroduction" + selfIntroduction
                + ", avatarLink" + avatarLink + "}";
    }
}
