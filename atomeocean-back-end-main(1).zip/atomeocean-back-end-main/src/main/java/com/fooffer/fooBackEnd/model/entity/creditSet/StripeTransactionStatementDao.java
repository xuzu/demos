package com.fooffer.fooBackEnd.model.entity.creditSet;

import com.fooffer.fooBackEnd.constant.stripe.Currency;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

/**
 * 对应数据库中的stripeTransactionStatement collection
 * 记录平台所有用户使用stripe的交易明细
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document(collection = "stripeTransactionStatement")
public class StripeTransactionStatementDao {

    @Id
    private ObjectId _id;

    /**
     * 逻辑主键
     * 代表交易单号
     */
    private String stripeTransactionStatementId;

    /**
     * 交易金额
     * 单位为cent，即$9.99为999
     */
    private Long amount;

    /**
     * 交易货币
     */
    private Currency currency;

    /**
     * 交易时间
     */
    private LocalDateTime timestamp;

    /**
     * 交易收据
     */
    private String receiptUrl;

    /**
     * 银行卡后四位
     */
    private String cardLastFourDigits;

    /**
     * 银行卡过期时间
     */
    private String cardExpiredDate;

    /**
     * 充值帐户
     */
    private Long userId;
}
