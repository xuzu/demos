package com.fooffer.fooBackEnd.service.impl;

import com.fooffer.fooBackEnd.constant.articles.ArticleVisibility;
import com.fooffer.fooBackEnd.mapper.ArticleMapper;
import com.fooffer.fooBackEnd.model.dto.ArticleDto;
import com.fooffer.fooBackEnd.model.dto.article.ArticleAuthor;
import com.fooffer.fooBackEnd.model.entity.ArticleDao;
import com.fooffer.fooBackEnd.model.vo.ArticleListRequestParams;
import com.fooffer.fooBackEnd.model.vo.ArticleResponseVo;
import com.fooffer.fooBackEnd.repository.ArticleListRepository;
import com.fooffer.fooBackEnd.repository.ArticleRepository;
import com.fooffer.fooBackEnd.service.intf.ArticleListService;
import com.fooffer.fooBackEnd.service.intf.ArticleService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

import static com.fooffer.fooBackEnd.constant.articles.ArticleVisibility.EVERYONE_CAN_SEE;
import static com.fooffer.fooBackEnd.utils.NumConvertUtil.decode62To10;

/**
 * 文章列表接口
 */
@Service
@AllArgsConstructor
@Slf4j
public class ArticleListServiceImpl implements ArticleListService {

    private final ArticleMapper articleMapper;

    private final ArticleService articleService;

    private final ArticleRepository articleRepository;

    private final ArticleListRepository articleListRepository;

    /**
     * 根据请求中的参数
     * @param articleListRequestParams 文章请求的参数
     * @return article dto列表
     */
    @Override
    public List<ArticleDto> getArticleDtoList(ArticleListRequestParams articleListRequestParams) {

        // 默认文章选取是按创建时间从新到旧的顺序
        Sort sort = Sort.by(
                Sort.Direction.DESC,
                "createTime"
        );
        Pageable pageable = PageRequest.of(
                articleListRequestParams.getPageNumber()-1,
                articleListRequestParams.getLimit(),
                sort
        );

        List<ArticleDao> articleDaoList;
        String authorIdInParams = articleListRequestParams.getAuthorId();

        // 如果参数中有authorId，查询该作者发表的文章
        if (authorIdInParams != null) {
            articleDaoList = articleListRepository.findArticleDaoByAuthorId(
                    decode62To10(authorIdInParams),
                    pageable
            ).getContent();
        } else {
            articleDaoList = articleRepository.findAll(pageable).getContent();
        }

        return convertToArticleDtoList(articleDaoList);
    }

    /**
     * List<ArticleDao> -> List<ArticleDto>
     * 在map的过程中，逐个读取文章作者信息，并添加到dto中
     * @param articleDaoList article dao列表
     * @return 返回一个article dto列表
     */
    private List<ArticleDto> convertToArticleDtoList(List<ArticleDao> articleDaoList){

        return articleDaoList.stream()
                .map(articleDao -> {
                    ArticleAuthor articleAuthor = articleService.getArticleAuthorByAuthorId(articleDao.getAuthorId());
                    ArticleDto articleDto = articleMapper.dao2dto(articleDao);
                    articleDto.setArticleAuthor(articleAuthor);
                    return articleDto;
                })
                .collect(Collectors.toList());
    }

    /**
     * ArticleDtoList -> ArticleResponseVoList
     * @param articleListRequestParams 文章列表请求的参数
     * @return ArticleResponseVo List
     */
    @Override
    public List<ArticleResponseVo> getArticleResponseVoList(
            ArticleListRequestParams articleListRequestParams
    ) {

        List<ArticleDto> articleDtoList = getArticleDtoList(articleListRequestParams)
                .stream()
                // 显示未被删除的文章
                .filter(articleDto -> !articleDto.getIsDeleted())
                // 显示公开的文章
                .filter(articleDto -> articleDto.getVisibility().equals(EVERYONE_CAN_SEE))
                .collect(Collectors.toList());

        return articleMapper.dto2ResponseVoList(articleDtoList);
    }
}
