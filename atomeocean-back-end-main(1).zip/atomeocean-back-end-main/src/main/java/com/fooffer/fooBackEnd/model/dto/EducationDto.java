package com.fooffer.fooBackEnd.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * 教育经历在数据传输过程中的封装类
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EducationDto {

    private Long educationId;

    //本段教育经历所对应用户的userId
    private Long userId;
    
    //学校名
    private String institutionName;

    /**学位名
     * 0：high school
     * 1：bachelor
     * 2：master
     * 3：doctor
     * 4：postdoc
     */
    private Integer degreeLevel;
    
    //专业名
    private String major;

    //开始日期
    private LocalDate startDate;    

    //结束日期
    private LocalDate endDate;
    
    //是否已经完成，如果是false那么前端显示结束日期为“至今”
    private Boolean isCompleted;
}
