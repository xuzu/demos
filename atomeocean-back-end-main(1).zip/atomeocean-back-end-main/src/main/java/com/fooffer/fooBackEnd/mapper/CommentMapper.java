package com.fooffer.fooBackEnd.mapper;


import com.fooffer.fooBackEnd.model.dto.CommentDto;
import com.fooffer.fooBackEnd.model.entity.CommentDao;
import com.fooffer.fooBackEnd.model.vo.CommentVo;

import org.mapstruct.Mapper;


/**
 * Comment vo, dto, dao 映射
 */
@Mapper(componentModel = "spring")
public interface CommentMapper {
    CommentDto vo2dto(CommentVo CommentVo);

    CommentVo dto2vo(CommentDto CommentDto);

    CommentDao dto2dao(CommentDto CommentDto);

    CommentDto dao2dto(CommentDao CommentDao);
}
