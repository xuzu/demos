package com.fooffer.fooBackEnd.mapper;


import com.fooffer.fooBackEnd.model.dto.CareerDto;
import com.fooffer.fooBackEnd.model.entity.CareerDao;
import com.fooffer.fooBackEnd.model.vo.CareerVo;
import org.mapstruct.Mapper;

/**
 * Career vo, dto, dao 映射
 */
@Mapper(componentModel = "spring")
public interface CareerMapper {

    CareerDto vo2dto(CareerVo careerVo);

    CareerVo dto2vo(CareerDto careerDto);

    CareerDao dto2dao(CareerDto careerDto);

    CareerDto dao2dto(CareerDao careerDao);
}
