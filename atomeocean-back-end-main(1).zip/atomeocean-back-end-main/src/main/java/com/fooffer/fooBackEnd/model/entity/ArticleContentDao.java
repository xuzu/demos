package com.fooffer.fooBackEnd.model.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * 文章内容对应的实体
 * 保存文章的全篇内容
 */
@Data
@Document(collection = "articleContents")
@AllArgsConstructor
@NoArgsConstructor
public class ArticleContentDao {

    @Id
    private ObjectId _id;

    private Long contentId;

    // 文章内容本身，长字符串
    private String content;

    // 文章的id
    private Long articleId;
}
