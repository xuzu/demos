package com.fooffer.fooBackEnd.model.vo;

import lombok.Data;

/**
 * 定义分页查询的参数
 * 通过base64 encode -> paginationToken(String)
 */
@Data
public class PaginationTokenVo {
    /**
     * 查询的页码
     */
    private Integer pageNumber;

    /**
     * 每一页元素个数
     */
    private Integer pageSize;
}
