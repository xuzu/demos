package com.fooffer.fooBackEnd.controller;

import com.fooffer.fooBackEnd.aspect.errorHandler.articleGeneral.InvalidArticleIdException;
import com.fooffer.fooBackEnd.model.vo.ArticleRequestParams;
import com.fooffer.fooBackEnd.model.vo.ArticleResponseVo;
import com.fooffer.fooBackEnd.service.intf.ArticleService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * 负责展示文章的接口
 * 路径前缀为"/article"
 */
@RestController
@AllArgsConstructor
@RequestMapping("/article")
@Slf4j
public class ArticleController {

    private final ArticleService articleService;

    /**
     * 根据文章id请求该文章
     * @return json文件包含文章所有信息
     */
    @GetMapping("")
    public Map<String, ArticleResponseVo> getArticle(
            ArticleRequestParams articleRequestParams
//            @RequestHeader(USER_IP_ADDRESS) String requestIp
    ) throws InvalidArticleIdException {
        String requestedArticleId = articleRequestParams.getArticleId();

        if (!StringUtils.hasLength(requestedArticleId)) {
            log.info("invalid request id");
            return null;
        }

        Map<String, ArticleResponseVo> resultMap = new HashMap<>();
        // todo: 使用spring security获取请求中的ip地址
        String requestIp = "1.2.3.4";
        ArticleResponseVo articleResponseVo = articleService.getArticle(
                requestedArticleId,
                requestIp
        );
        resultMap.put("article", articleResponseVo);

        return resultMap;
    }
}
