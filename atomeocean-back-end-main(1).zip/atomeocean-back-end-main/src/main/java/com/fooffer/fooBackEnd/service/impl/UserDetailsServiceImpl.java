package com.fooffer.fooBackEnd.service.impl;

import com.fooffer.fooBackEnd.security.JwtUserDetails;
import com.fooffer.fooBackEnd.model.entity.UserDao;
import com.fooffer.fooBackEnd.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 * 扩展spring security自带的接口
 */
@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    private UserRepository userRepository;

    @Autowired
    public UserDetailsServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String userEmail) throws UsernameNotFoundException {
        UserDao userDao = userRepository.findUserDaoByUserEmail(userEmail);

        return new JwtUserDetails(userDao);

    }
}
