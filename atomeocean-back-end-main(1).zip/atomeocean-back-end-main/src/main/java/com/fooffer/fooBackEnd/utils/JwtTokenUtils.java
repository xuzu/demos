package com.fooffer.fooBackEnd.utils;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.fooffer.fooBackEnd.constant.security.JwtTokenConstant.ISS;
import static com.fooffer.fooBackEnd.constant.security.JwtTokenConstant.SECRET;

/**
 * 封装jwt工具类方便调用
 */
@Slf4j
public class JwtTokenUtils {

    // 过期时间3600秒
    private static final long EXPIRATION = 3600L;

    // remember me过期时间7天
    private static final long EXPIRATION_REMEMBER = 604800L;

    // 添加角色的key
    private static final String ROLE_CLAIMS = "role";

    private static final String USER_ID_CLAIMS = "userId";

    // 创建token
    public static String createToken(
            String userEmail,
            Long userId,
            List<String> roles,
            boolean isRememberMe
    ) {
        long expiration = isRememberMe ? EXPIRATION_REMEMBER : EXPIRATION;
        Map<String, Object> map = new HashMap<>();
        map.put(ROLE_CLAIMS, roles);
        map.put(USER_ID_CLAIMS, userId);
        return Jwts.builder()
                .signWith(SignatureAlgorithm.HS512, SECRET)
                // 放在后面会覆盖其他字段
                .setClaims(map)
                .setIssuer(ISS)
                .setSubject(userEmail)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expiration * 1000))
                .compact();
    }

    // 从token payload中获取用户Id
    public static Long getUserId(String token) {
        return (Long) getTokenBody(token).get(USER_ID_CLAIMS);
    }

    // 从token payload中获取用户邮箱
    public static String getUserEmail(String token) {
        return getTokenBody(token).getSubject();
    }

    // 从token中获取用户角色
    public static List<SimpleGrantedAuthority> getUserRoles(String token) {

        return ((List<String>)getTokenBody(token)
                .get(ROLE_CLAIMS))
                .stream()
                .map(
                        SimpleGrantedAuthority::new
                )
                .collect(Collectors.toList());
    }

    // 是否已经过期
    public static boolean isExpiration(String token) {
        return getTokenBody(token).getExpiration().before(new Date());
    }

    private static Claims getTokenBody(String token) {
        return Jwts.parser()
                .setSigningKey(SECRET)
                .parseClaimsJws(token)
                .getBody();
    }
}
