package com.fooffer.fooBackEnd.model.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Description: 存储文件Vo
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ImageVo {

    /**
     * 文件名称
     */
    private String originalFileName;

    /**
     * 文件类型
     * todo: 可能是图片，视频或文件
     */
    private String fileType;

    /**
     * 文件大小
     */
    private long fileSize;

    /**
     * cloud storage中文件的路径
     */
    private String url;
}
