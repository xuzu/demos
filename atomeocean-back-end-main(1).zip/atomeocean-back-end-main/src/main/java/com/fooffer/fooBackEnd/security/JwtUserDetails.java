package com.fooffer.fooBackEnd.security;

import com.fooffer.fooBackEnd.model.entity.UserDao;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.stream.Collectors;

/**
 * 实现UserDetails接口
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class JwtUserDetails implements UserDetails {

    private Long userId;

    private Collection<? extends GrantedAuthority> authorities;

    /**
     * 将UserDao封装进JwtUserDetails
     * @param userDao
     */
    public JwtUserDetails(UserDao userDao) {
        userId = userDao.getUserId();

        // 初始化用户的权限
        authorities = userDao.getUserRoleDaoList()
                        .stream()
                        .map(
                            userRoleDao ->
                                    new SimpleGrantedAuthority(userRoleDao.getRoleName())
                        )
                        .collect(Collectors.toList());
    }

    /**
     * 获取权限信息 authorities -> user roles
     * @return 返回当前用户的权限
     */
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    @Override
    public String getPassword() {
        return null;
    }

    @Override
    public String getUsername() {
        return null;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    /**
     * 打印信息用
     * @return 包含所有信息的string
     */
    @Override
    public String toString() {
        return "JwtUserDetails: {" +
                "id=" + userId +
                ", authorities=" + authorities.toString() +
                "}";
    }
}
