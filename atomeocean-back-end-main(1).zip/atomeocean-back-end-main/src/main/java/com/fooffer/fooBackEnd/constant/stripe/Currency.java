package com.fooffer.fooBackEnd.constant.stripe;

public enum Currency {
    USD;
}
