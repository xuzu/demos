package com.fooffer.fooBackEnd.repository;

import com.fooffer.fooBackEnd.model.entity.UserRoleDao;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

/**
 * 操作userRole collection
 */
@Repository
public interface UserRoleRepository extends MongoRepository<UserRoleDao, Integer> {

    // super.save(Entity userRoleDao)

    /**
     * find role by role name
     */
    UserRoleDao findUserRoleDaoByRoleName(String roleName);
}
