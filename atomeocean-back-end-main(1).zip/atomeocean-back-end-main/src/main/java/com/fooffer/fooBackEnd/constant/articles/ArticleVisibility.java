package com.fooffer.fooBackEnd.constant.articles;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fooffer.fooBackEnd.constant.baseEnum.IdCodeBaseEnum;

import java.util.stream.Stream;

/**
 * 文章显示的权限
 */
public enum ArticleVisibility implements IdCodeBaseEnum {

    // 完全公开
    EVERYONE_CAN_SEE(1, "EveryoneCanSee"),

    // 登录后可见
    NEED_SIGN_IN(2, "NeedSignIn"),

    // 关注者可见
    FOLLOWERS_ONLY(3, "FollowersOnly"),

    // 仅作者自己可见
    AUTHOR_SELF_ONLY(5, "AuthorSelfOnly");

    private final Integer id;
    private final String code;

    private ArticleVisibility(Integer id, String code) {
        this.id = id;
        this.code = code;
    }

    @JsonCreator
    public static ArticleVisibility decode(Integer value) {
        return Stream.of(ArticleVisibility.values()).filter(targetEnum -> targetEnum.id.equals(value)).findFirst().orElse(null);
    }

    @Override
    public Integer getId() {
        return id;
    }

    @JsonValue
    @Override
    public String getCode() {
        return code;
    }
}
