package com.fooffer.fooBackEnd.mapper;


import com.fooffer.fooBackEnd.model.dto.EmailAuthDto;
import com.fooffer.fooBackEnd.model.entity.EmailAuthDao;
import com.fooffer.fooBackEnd.model.vo.EmailAuthVo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * EmailAuth vo, dto, dao 映射
 */
@Mapper(componentModel = "spring")
public interface EmailAuthMapper {

    EmailAuthDto vo2dto(EmailAuthVo emailAuthVo);

    EmailAuthVo dto2vo(EmailAuthDto emailAuthDto);

    EmailAuthDao dto2dao(EmailAuthDto emailAuthDto);

    @Mapping(target = "password", constant = "password hidden")
    EmailAuthDto dao2dto(EmailAuthDao emailAuthDao);
}
