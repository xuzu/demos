package com.fooffer.fooBackEnd.model.dto;

import com.fooffer.fooBackEnd.model.entity.UserRoleDao;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * user在数据传输过程中的封装类
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmailAuthDto {

    private Long emailAuthId;

    /**
     * 用户邮箱
     */
    private String userEmail;

    /**
     * 用户密码
     */
    private String password;

    /**
     * 对应UserDao id
     */
    private Long userId;
}
