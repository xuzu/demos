package com.fooffer.fooBackEnd.mapper.creditSet;

import com.fooffer.fooBackEnd.model.dto.creditSet.StripeTransactionStatementDto;
import com.fooffer.fooBackEnd.model.entity.creditSet.StripeTransactionStatementDao;
import com.fooffer.fooBackEnd.model.vo.creditSet.StripeTransactionStatementVo;
import org.mapstruct.Mapper;

/**
 * stripe交易明细 对应的mapper
 */
@Mapper(componentModel = "spring")
public interface StripeTransactionStatementMapper {
    StripeTransactionStatementDto dao2dto(StripeTransactionStatementDao stripeTransactionStatementDao);

    StripeTransactionStatementVo dto2vo(StripeTransactionStatementDto stripeTransactionStatementDto);
}
