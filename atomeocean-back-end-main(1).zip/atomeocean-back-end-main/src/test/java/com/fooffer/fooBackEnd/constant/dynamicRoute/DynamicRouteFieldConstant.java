package com.fooffer.fooBackEnd.constant.dynamicRoute;


import java.util.*;

/**
 * 测试DynamicRoute用的常量
 */
public class DynamicRouteFieldConstant {
    public static final String DYNAMIC_ROUTE_PATH = "dynamic route path";
    public static final String DYNAMIC_ROUTE_NAME = "dynamic route name";
    public static final String DYNAMIC_COMPONENT = "dynamic route component";
    public static final int PARENT_ROUTE_ID = 1000;
    public static  List<Integer> CHILDREN_ROUTES = Arrays.asList(2000, 3000, 4000);

}
