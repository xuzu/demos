package com.fooffer.fooBackEnd.service.impl;

import com.fooffer.fooBackEnd.aspect.errorHandler.articleGeneral.InvalidArticleIdException;
import com.fooffer.fooBackEnd.mapper.ArticleMapper;
import com.fooffer.fooBackEnd.model.dto.ArticleDto;
import com.fooffer.fooBackEnd.model.entity.ArticleContentDao;
import com.fooffer.fooBackEnd.model.entity.ArticleDao;
import com.fooffer.fooBackEnd.model.entity.ArticleTagDao;
import com.fooffer.fooBackEnd.model.vo.ArticleListRequestParams;
import com.fooffer.fooBackEnd.model.vo.ArticleResponseVo;
import com.fooffer.fooBackEnd.repository.ArticleContentRepository;
import com.fooffer.fooBackEnd.repository.ArticleRepository;
import com.fooffer.fooBackEnd.repository.ArticleTagRepository;
import com.fooffer.fooBackEnd.utils.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.fooffer.fooBackEnd.constant.article.ArticleFieldConstant.*;
import static com.fooffer.fooBackEnd.constant.articles.ArticleRequestConstant.ARTICLE_VIEW_EXPIRED_TIME;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(SpringExtension.class)
@Slf4j
@SpringBootTest
@Testcontainers
@ActiveProfiles("test")
@DisplayName("Article Service Test")
class ArticleServiceImplTest {

    @InjectMocks
    private ArticleServiceImpl articleService;

    @InjectMocks
    private ArticleListServiceImpl articleListService;

    @Mock
    private ArticleRepository articleRepository;

    @Mock
    private ArticleContentRepository articleContentRepository;

    @Mock
    private ArticleTagRepository articleTagRepository;
    @Mock
    private ArticleMapper articleMapper;

    @Mock
    private RedisUtil redisUtil;

    @Container
    public static GenericContainer<?> redisContainer =
            new GenericContainer<>(
                    DockerImageName.parse("redis:7"))
                    .withExposedPorts(6379);

    @DynamicPropertySource
    static void registerProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.redis.host", redisContainer::getHost);
        registry.add("spring.redis.port", () -> redisContainer.getFirstMappedPort());
    }

    @Test
    @DisplayName("Test getArticle()")
    void testGetArticle() throws InvalidArticleIdException {
        // given
        String articleId = "12345";
        Long contentId = Long.parseLong("67890");
        Long dbId = Long.parseLong(articleId);
        String ipArticleIdKey = "1.1.0.0"+":article:"+ articleId;
        String viewCountKey = "viewCount:" + articleId;
        String tagID_s = "5fa5e5eef917d023c8751395";
        ObjectId tagId = new ObjectId(tagID_s);
        String tagTitle = "title";
        List<String> tagList = new ArrayList<>();
        tagList.add(tagID_s);
        redisContainer.start();
        redisUtil.set(ipArticleIdKey,"true", ARTICLE_VIEW_EXPIRED_TIME, TimeUnit.SECONDS);
        Assertions.assertEquals(redisUtil.get(ipArticleIdKey),"true");
        redisUtil.set(viewCountKey, 1, ARTICLE_VIEW_EXPIRED_TIME, TimeUnit.SECONDS);
        Assertions.assertEquals(redisUtil.get(viewCountKey), 1);

        ArticleDao mockArticleDao = new ArticleDao();
        mockArticleDao.setTitle(ARTICLE_TITLE);
        mockArticleDao.setContentId(contentId);
        Mockito.doReturn(mockArticleDao)
                .when(articleRepository)
                .findArticleDaoByArticleIdAndIsDeletedIsFalse(dbId);

        ArticleContentDao mockContentDao = new ArticleContentDao();
        mockContentDao.setArticleId(dbId);
        Mockito.doReturn(mockContentDao)
                .when(articleContentRepository)
                .findArticleContentDaoByContentId(
                        mockArticleDao.getContentId()
                );

        List<ArticleTagDao> mockTagDaoList = new ArrayList<>();
        ArticleTagDao mockTagDao = new ArticleTagDao();
        mockTagDaoList.add(mockTagDao);
        Mockito.doReturn(mockTagDao)
                .when(articleTagRepository)
                .findArticleTagDaoBy_id(tagID_s);

        ArticleDto mockArticleDto = new ArticleDto();
        mockArticleDto.setTitle(ARTICLE_TITLE);
        Mockito.doReturn(mockArticleDto)
                .when(articleMapper)
                .mergeDao2dto(mockArticleDao, mockContentDao, mockTagDaoList);

        ArticleResponseVo mockArticleResponseVo = new ArticleResponseVo();
        mockArticleResponseVo.setTitle(ARTICLE_TITLE);
        Mockito.doReturn(mockArticleResponseVo)
                .when(articleMapper)
                .dto2vo(mockArticleDto);


        // when
//        ArticleResponseVo articleResponseVo = articleService.getArticle(articleId, "1.1.0.0");

        // then
//        Assertions.assertEquals(
//                ARTICLE_TITLE, articleResponseVo.getTitle()
//        );

    }

    @Test
    @DisplayName("Test getArticleDtoList()")
    void testGetArticleDtoList(){
        //given
        ArticleListRequestParams articleListRequestParams = new ArticleListRequestParams();
        articleListRequestParams.setAuthorId(Long.toString(AUTHOR_ID));
        Sort sort = Sort.by(
                Sort.Direction.DESC,
                "createTime"
        );
        Pageable pageable = PageRequest.of(
                articleListRequestParams.getPageNumber()-1,
                articleListRequestParams.getLimit(),
                sort
        );

        List<ArticleDao> mockArticleDaoList = new ArrayList<>();
        ArticleDao mockArticleDao = new ArticleDao();
        mockArticleDao.setTitle(ARTICLE_TITLE);
        mockArticleDao.setContentId(CONTENT_ID);
        mockArticleDao.setAuthorId(AUTHOR_ID);
        Mockito.doReturn(mockArticleDao)
                .when(articleRepository)
                .findArticleDaoByArticleIdAndIsDeletedIsFalse(ARTICLE_ID);
        mockArticleDaoList.add(mockArticleDao);
        Mockito.when(articleRepository.findArticleDaoByAuthorIdAndIsDeletedIsFalse(
                Long.parseLong(articleListRequestParams.getAuthorId()), pageable
        )).thenReturn(new PageImpl<>(mockArticleDaoList, pageable, mockArticleDaoList.size()));

        List<ArticleDto> mockArticleDtoList = new ArrayList<>();
        ArticleDto mockArticleDto = new ArticleDto();
        mockArticleDto.setTitle(ARTICLE_TITLE);
        mockArticleDto.setContentId(CONTENT_ID);
        mockArticleDtoList.add(mockArticleDto);
//        Mockito.doReturn(mockArticleDtoList)
//                .when(articleMapper)
//                .toArticleDtos(mockArticleDaoList);

        // when
        // TODO: 这部分测试放在article list下面。另外article author逻辑部分有修改
//        List<ArticleDto> articleDtoList = articleListService.getArticleDtoList(articleListRequestParams);
        // then
//        Assertions.assertEquals(
//                mockArticleDtoList, articleDtoList
//        );
    }

    @Test
    @DisplayName("Test synchronizeViewCounts()")
    public void testSynchronizeViewCounts(){
        ArticleDao mockArticleDao = new ArticleDao();
        mockArticleDao.setTitle(ARTICLE_TITLE);
        mockArticleDao.setViewCount(VIEW_COUNT);
        List<ArticleDao> mockArticleDaoList = new ArrayList<>();
        mockArticleDaoList.add(mockArticleDao);
        Mockito.when(articleRepository.findAll())
                .thenReturn(mockArticleDaoList);
        String mockViewCountKey = "viewCount:" + mockArticleDao.getArticleId();
        redisUtil.set(mockViewCountKey, 1, ARTICLE_VIEW_EXPIRED_TIME, TimeUnit.SECONDS);

        //when
        articleService.synchronizeViewCounts();

        //then
        verify(articleRepository, times(1)).save(mockArticleDao);
        //verify(redisUtil, times(1)).delete(mockViewCountKey);
        Assertions.assertEquals(11, mockArticleDao.getViewCount());
    }
}
