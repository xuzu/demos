package com.fooffer.fooBackEnd.constant.article;

/**
 * 测试Article用的常量
 */
public class ArticleFieldConstant {
    public static final String ARTICLE_TITLE = "article title";
    public static final String ARTICLE_CONTENT = "article content";
    public static final Long ARTICLE_ID = 12345L;
    public static final Long CONTENT_ID = 1234567L;
    public static final int WORD_COUNT = 1000;
    public static final Long AUTHOR_ID = 123456789L;
    public static final int VIEW_COUNT = 10;
}
