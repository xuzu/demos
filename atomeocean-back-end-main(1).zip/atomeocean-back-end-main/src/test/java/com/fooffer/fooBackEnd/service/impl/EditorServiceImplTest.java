package com.fooffer.fooBackEnd.service.impl;

import com.fooffer.fooBackEnd.constant.ResourceOperationType;
import com.fooffer.fooBackEnd.mapper.EditorMapper;
import com.fooffer.fooBackEnd.model.dto.editor.EditorDto;
import com.fooffer.fooBackEnd.model.entity.ArticleContentDao;
import com.fooffer.fooBackEnd.model.entity.ArticleDao;
import com.fooffer.fooBackEnd.model.vo.EditorVo;
import com.fooffer.fooBackEnd.repository.ArticleContentRepository;
import com.fooffer.fooBackEnd.repository.EditorRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ActiveProfiles;

import java.time.LocalDateTime;
import java.util.Optional;

import static com.fooffer.fooBackEnd.constant.article.ArticleFieldConstant.*;
import static org.mockito.Mockito.*;


/**
 * Editor service 单元测试
 */
@SpringBootTest
@DisplayName("Editor Service Test")
@Slf4j
@ActiveProfiles("test")
class EditorServiceImplTest {

    @InjectMocks
    private EditorServiceImpl editorService;

    @Mock
    private EditorMapper editorMapper;

    @Mock
    private EditorRepository editorRepository;

    @Mock
    private ArticleContentRepository articleContentRepository;

    @Test
    @DisplayName("Test saveAnArticlePost()")
    void testSaveAnArticlePost(){
        EditorVo editorVo = EditorVo.builder()
                .title(ARTICLE_TITLE)
                .content(ARTICLE_CONTENT)
                .build();

        Authentication mockAuthentication = mock(Authentication.class);
        Mockito.when(mockAuthentication.getDetails()).thenReturn(AUTHOR_ID);
        SecurityContextHolder.getContext().setAuthentication(mockAuthentication);

        EditorDto mockEditorDto = EditorDto.builder()
                .title(ARTICLE_TITLE)
                .content(ARTICLE_CONTENT)
                .articleId(ARTICLE_ID)
                .contentId(CONTENT_ID)
                .authorId(AUTHOR_ID)
                .build();

        Mockito.doReturn(mockEditorDto)
                .when(editorMapper)
                .vo2dto(editorVo);

        ArticleDao mockArticleDao = new ArticleDao();
        Mockito.doReturn(mockArticleDao)
                .when(editorMapper)
                .dto2dao(mockEditorDto);
        Mockito.when(editorRepository.save(mockArticleDao)).thenReturn(mockArticleDao);

        ArticleContentDao mockContentDao = new ArticleContentDao();
        Mockito.doReturn(mockContentDao)
                .when(editorMapper)
                .dto2ContentDao(mockEditorDto);
        Mockito.when(articleContentRepository.save(mockContentDao)).thenReturn(mockContentDao);

        // when
        editorService.saveAnArticle(editorVo, ResourceOperationType.Post);

        // then
        verify(editorRepository, times(1)).save(mockArticleDao);
        verify(articleContentRepository, times(1)).save(mockContentDao);
    }


    @Test
    @DisplayName("Test saveAnArticlePatch()")
    void testSaveAnArticlePatch(){
        EditorVo editorVo = EditorVo.builder()
                .title(ARTICLE_TITLE)
                .content(ARTICLE_CONTENT)
                .build();

        EditorDto mockEditorDto = EditorDto.builder()
                .title(ARTICLE_TITLE)
                .content(ARTICLE_CONTENT)
                .articleId(ARTICLE_ID)
                .build();
        doReturn(mockEditorDto)
                .when(editorMapper)
                .vo2dto(editorVo);


        ArticleDao mockExistingArticleDao = new ArticleDao();
        when(editorRepository.findArticleDaoByArticleId(mockEditorDto.getArticleId())).thenReturn(Optional.of(mockExistingArticleDao));
        mockEditorDto.setLatestUpdateTime(LocalDateTime.now());
        doNothing().when(editorMapper).updateArticleDaoFromEditorDto(mockExistingArticleDao,mockEditorDto);
        when(editorRepository.save(mockExistingArticleDao)).thenReturn(mockExistingArticleDao);

        ArticleContentDao mockExistingContentDao = new ArticleContentDao();
        when(articleContentRepository.findArticleContentDaoByContentId(mockExistingArticleDao.getContentId())).thenReturn(mockExistingContentDao);
        doNothing().when(editorMapper).updateArticleContentDaoFromEditorDto(mockExistingContentDao,mockEditorDto);
        when(articleContentRepository.save(mockExistingContentDao)).thenReturn(mockExistingContentDao);

        // when
        editorService.saveAnArticle(editorVo, ResourceOperationType.Patch);

        // then
        verify(editorMapper, times(1)).updateArticleDaoFromEditorDto(mockExistingArticleDao,mockEditorDto);
        verify(editorMapper, times(1)).updateArticleContentDaoFromEditorDto(mockExistingContentDao,mockEditorDto);
        Mockito.verify(editorRepository, times(1)).findArticleDaoByArticleId(mockEditorDto.getArticleId());
        verify(articleContentRepository, times(1)).findArticleContentDaoByContentId(mockExistingArticleDao.getArticleId());
        verify(editorRepository, times(1)).save(mockExistingArticleDao);
        verify(articleContentRepository, times(1)).save(mockExistingContentDao);

    }

    @Test
    @DisplayName("Test saveAnArticleDelete()")
    void testSaveAnArticleDelete(){
        EditorVo editorVo = EditorVo.builder()
                .title(ARTICLE_TITLE)
                .articleId(Long.toString(ARTICLE_ID))
                .content(ARTICLE_CONTENT)
                .build();

        EditorDto mockEditorDto = EditorDto.builder()
                .title(ARTICLE_TITLE)
                .authorId(AUTHOR_ID)
                .contentId(CONTENT_ID)
                .build();
        Mockito.doReturn(mockEditorDto)
                .when(editorMapper)
                .vo2dto(editorVo);

        ArticleDao mockExistingArticleDao = new ArticleDao();
        Mockito.when(editorRepository.findArticleDaoByArticleId(mockEditorDto.getArticleId())).thenReturn(Optional.of(mockExistingArticleDao));
        mockEditorDto.setIsDeleted(true);
        doNothing().when(editorMapper).updateArticleDaoFromEditorDto(mockExistingArticleDao, mockEditorDto);
        Mockito.when(editorRepository.save(mockExistingArticleDao)).thenReturn(mockExistingArticleDao);

        // when
        editorService.saveAnArticle(editorVo, ResourceOperationType.Delete);

        // then
        Mockito.verify(editorRepository, times(1)).findArticleDaoByArticleId(mockEditorDto.getArticleId());
        Mockito.verify(editorMapper, Mockito.times(1)).updateArticleDaoFromEditorDto(Mockito.eq(mockExistingArticleDao), Mockito.eq(mockEditorDto));
        Mockito.verify(editorRepository, Mockito.times(1)).save(mockExistingArticleDao);
    }
}