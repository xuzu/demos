package com.fooffer.fooBackEnd.mapper;

import com.fooffer.fooBackEnd.model.dto.DynamicRouteDto;
import com.fooffer.fooBackEnd.model.entity.DynamicRouteDao;
import com.fooffer.fooBackEnd.model.vo.DynamicRouteVo;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;

import static com.fooffer.fooBackEnd.constant.dynamicRoute.DynamicRouteFieldConstant.*;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
@Slf4j
@DisplayName("DynamicRoute Mapper Test")
public class DynamicRouteMapperTest {
    @InjectMocks
    private DynamicRouteMapper dynamicRouteMapper = Mappers.getMapper(DynamicRouteMapper.class);

    @Test
    @DisplayName("dao -> dto mapper")
    void testDao2dto() {

        //given
        DynamicRouteDao dynamicRouteDao = DynamicRouteDao.builder()
                .path(DYNAMIC_ROUTE_PATH)
                .name(DYNAMIC_ROUTE_NAME)
                .parentRouteId(PARENT_ROUTE_ID)
                .childrenRoutes(CHILDREN_ROUTES)
                .build();

        //when
        DynamicRouteDto dtoResult = dynamicRouteMapper.dao2dto(dynamicRouteDao);

        // then
        assertNotNull(dtoResult);
        assertThat(dtoResult.getPath()).isEqualTo(dynamicRouteDao.getPath());
        assertThat(dtoResult.getName()).isEqualTo(dynamicRouteDao.getName());
        assertThat(dtoResult.getParentRouteId()).isEqualTo(dynamicRouteDao.getParentRouteId());
//        assertThat(dtoResult.getChildrenRoutes()).isEqualTo(dynamicRouteDao.getChildrenRoutes());

    }

    @Test
    @DisplayName("dto -> dao mapper")
    void testDto2dao() {

        //given
        DynamicRouteDto dynamicRouteDto = DynamicRouteDto.builder()
                .path(DYNAMIC_ROUTE_PATH)
                .name(DYNAMIC_ROUTE_NAME)
                .component(DYNAMIC_COMPONENT)
                .parentRouteId(PARENT_ROUTE_ID)
                .childrenRoutes(CHILDREN_ROUTES)
                .build();

        //when
        DynamicRouteDao daoResult = dynamicRouteMapper.dto2dao(dynamicRouteDto);

        //then
        assertNotNull(daoResult);
        assertThat(daoResult.getPath()).isEqualTo(dynamicRouteDto.getPath());
        assertThat(daoResult.getName()).isEqualTo(dynamicRouteDto.getName());
        assertThat(daoResult.getParentRouteId()).isEqualTo(dynamicRouteDto.getParentRouteId());
//        assertThat(daoResult.getChildrenRoutes()).isEqualTo(dynamicRouteDto.getChildrenRoutes());

    }

    @Test
    @DisplayName("dto -> vo mapper")
    void testDto2vo() {

        //given
        DynamicRouteDto dynamicRouteDto = DynamicRouteDto.builder()
                .path(DYNAMIC_ROUTE_PATH)
                .name(DYNAMIC_ROUTE_NAME)
                .component(DYNAMIC_COMPONENT)
                .parentRouteId(PARENT_ROUTE_ID)
                .childrenRoutes(CHILDREN_ROUTES)
                .build();

        //when
        DynamicRouteVo voResult = dynamicRouteMapper.dto2vo(dynamicRouteDto);

        //then
        assertNotNull(voResult);
        assertThat(voResult.getPath()).isEqualTo(dynamicRouteDto.getPath());
        assertThat(voResult.getName()).isEqualTo(dynamicRouteDto.getName());
        assertThat(voResult.getComponent()).isEqualTo(dynamicRouteDto.getComponent());
        assertThat(voResult.getParentRouteId()).isEqualTo(dynamicRouteDto.getParentRouteId());
    }


    @Test
    @DisplayName("vo -> dto mapper")
    void testVo2dto() {

        //given
        DynamicRouteVo dynamicRouteVo = DynamicRouteVo.builder()
                .path(DYNAMIC_ROUTE_PATH)
                .name(DYNAMIC_ROUTE_NAME)
                .component(DYNAMIC_COMPONENT)
                .parentRouteId(PARENT_ROUTE_ID)
                .build();

        //when
        DynamicRouteDto dtoResult = dynamicRouteMapper.vo2dto(dynamicRouteVo);

        //then
        assertNotNull(dtoResult);
        assertThat(dtoResult.getPath()).isEqualTo(dynamicRouteVo.getPath());
        assertThat(dtoResult.getName()).isEqualTo(dynamicRouteVo.getName());
        assertThat(dtoResult.getComponent()).isEqualTo(dynamicRouteVo.getComponent());
        assertThat(dtoResult.getParentRouteId()).isEqualTo(dynamicRouteVo.getParentRouteId());
    }

}
