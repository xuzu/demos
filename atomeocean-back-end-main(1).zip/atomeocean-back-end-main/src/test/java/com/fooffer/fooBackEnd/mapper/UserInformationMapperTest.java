package com.fooffer.fooBackEnd.mapper;

import com.fooffer.fooBackEnd.model.dto.UserInformationDto;
import com.fooffer.fooBackEnd.model.entity.UserInformationDao;
import com.fooffer.fooBackEnd.model.vo.UserInformationVo;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@Slf4j
@DisplayName("UserInformation Mapper Test")

class UserInformationMapperTest {

    @InjectMocks
    private UserInformationMapper userInformationMapper = Mappers.getMapper(UserInformationMapper.class);

    @Test
    @DisplayName("dao -> dto mapper")
    void testDao2dto() {

        // given
        UserInformationDao userInformationDao = UserInformationDao.builder()
                .nickname("nickname")
                .build();

        // when
        UserInformationDto dtoResult = userInformationMapper.dao2dto(userInformationDao);

        // then
        assertNotNull(dtoResult);
        assertThat(dtoResult.getNickname()).isEqualTo(userInformationDao.getNickname());
    }

    @Test
    @DisplayName("dto -> vo mapper")
    void testDto2Vo() {

        // given
        UserInformationDto userInformationDto = UserInformationDto.builder()
                .nickname("nickname")
                .avatarLink("avatarLink")
                .build();

        // when
        UserInformationVo voResult = userInformationMapper.dto2vo(userInformationDto);

        // then
        assertNotNull(voResult);
        assertThat(voResult.getNickname()).isEqualTo(userInformationDto.getNickname());
        assertThat(voResult.getAvatarLink()).isEqualTo(userInformationDto.getAvatarLink());
    }
}