package com.fooffer.fooBackEnd.constant;

public class EmailVerificationConstant {
    public static final String CODE = "123456";
    public static final String EMAIL = "test@gmail.com";
    public static final String EMAIL_CODE = EMAIL + " " + CODE;
    public static final String PASSWORD = "abcd123";
    public static final String REFER_ID = "-1";
}
