package com.fooffer.fooBackEnd.mapper;

import com.fooffer.fooBackEnd.model.dto.ArticleDto;
import com.fooffer.fooBackEnd.model.entity.ArticleDao;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import static com.fooffer.fooBackEnd.constant.article.ArticleFieldConstant.*;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@Slf4j
@DisplayName("Article Mapper Test")
class ArticleMapperTest {

    @InjectMocks
    private ArticleMapper articleMapper = ArticleMapper.INSTANCE;

    @Test
    @DisplayName("dao -> dto mapper")
    void testDao2dto() {

        // given
        ArticleDao articleDao = ArticleDao.builder()
                .title(ARTICLE_TITLE)
                .authorId(AUTHOR_ID)
                .wordCount(WORD_COUNT)
                .build();

        // when
        ArticleDto dtoResult = articleMapper.dao2dto(articleDao);

        // then
        assertNotNull(dtoResult);
        assertThat(dtoResult.getTitle()).isEqualTo(articleDao.getTitle());
        assertThat(dtoResult.getWordCount()).isEqualTo(articleDao.getWordCount());

    }
}