package com.fooffer.fooBackEnd.constant;

import com.google.common.collect.ImmutableList;

import java.util.List;

public class UserRoleFieldConstant {
    public static int ROLE_ID = 100;

    public static String ROLE_NAME = "Member";

    public static List<Integer> DYNAMIC_ROUTE_IDS = new ImmutableList.Builder<Integer>()
            .add(1000).build();

    public static List<String> DYNAMIC_ROUTE_NAMES = new ImmutableList.Builder<String>()
            .add("test").build();
}
