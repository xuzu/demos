package com.fooffer.fooBackEnd.mapper;

import com.fooffer.fooBackEnd.model.dto.UserRoleDto;
import com.fooffer.fooBackEnd.model.entity.UserRoleDao;
import com.fooffer.fooBackEnd.model.vo.UserRoleVo;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import static com.fooffer.fooBackEnd.constant.UserRoleFieldConstant.*;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@Slf4j
@DisplayName("User Role Mapper Test")
public class UserRoleMapperTest {
    @InjectMocks
    private UserRoleMapper userRoleMapper = UserRoleMapper.INSTANCE;

    @Test
    @DisplayName("dto -> vo mapper")
    void testDto2vo() {

        //given
        UserRoleDto userRoleDto = UserRoleDto.builder()
                .roleId(ROLE_ID)
                .roleName(ROLE_NAME)
                .dynamicRouteIds(DYNAMIC_ROUTE_IDS)
                .dynamicRouteNames(DYNAMIC_ROUTE_NAMES)
                .build();

        //when
        UserRoleVo voResult = userRoleMapper.dto2vo(userRoleDto);

        //then
        assertNotNull(voResult);
        assertThat(voResult.getRoleName()).isEqualTo(userRoleDto.getRoleName());
        assertThat(voResult.getDynamicRouteNames()).isEqualTo(userRoleDto.getDynamicRouteNames());
    }

    @Test
    @DisplayName("vo -> dto mapper")
    void testVo2dto() {

        //given
        UserRoleVo userRoleVo = UserRoleVo.builder()
                .roleName(ROLE_NAME)
                .dynamicRouteNames(DYNAMIC_ROUTE_NAMES)
                .build();

        //when
        UserRoleDto dtoResult = userRoleMapper.vo2dto(userRoleVo);

        //then
        assertNotNull(dtoResult);
        assertThat(dtoResult.getRoleName()).isEqualTo(userRoleVo.getRoleName());
        assertThat(dtoResult.getDynamicRouteNames()).isEqualTo(userRoleVo.getDynamicRouteNames());
    }

    @Test
    @DisplayName("dto -> dao mapper")
    void testDto2dao() {

        //given
        UserRoleDto userRoleDto = UserRoleDto.builder()
                .roleId(ROLE_ID)
                .roleName(ROLE_NAME)
                .dynamicRouteIds(DYNAMIC_ROUTE_IDS)
                .dynamicRouteNames(DYNAMIC_ROUTE_NAMES)
                .build();

        //when
        UserRoleDao daoResult = userRoleMapper.dto2dao(userRoleDto);

        //then
        assertNotNull(daoResult);
        assertThat(daoResult.getRoleId()).isEqualTo(userRoleDto.getRoleId());
        assertThat(daoResult.getRoleName()).isEqualTo(userRoleDto.getRoleName());
        assertThat(daoResult.getDynamicRouteIds()).isEqualTo(userRoleDto.getDynamicRouteIds());

    }

    @Test
    @DisplayName("dao -> dto mapper")
    void testDao2dto() {

        //given
        UserRoleDao userRoleDao = UserRoleDao.builder()
                .roleId(ROLE_ID)
                .roleName(ROLE_NAME)
                .dynamicRouteIds(DYNAMIC_ROUTE_IDS)
                .build();

        //when
        UserRoleDto dtoResult = userRoleMapper.dao2dto(userRoleDao);

        //then
        assertNotNull(dtoResult);
        assertThat(dtoResult.getRoleId()).isEqualTo(userRoleDao.getRoleId());
        assertThat(dtoResult.getRoleName()).isEqualTo(userRoleDao.getRoleName());
        assertThat(dtoResult.getDynamicRouteIds()).isEqualTo(userRoleDao.getDynamicRouteIds());
    }
}
