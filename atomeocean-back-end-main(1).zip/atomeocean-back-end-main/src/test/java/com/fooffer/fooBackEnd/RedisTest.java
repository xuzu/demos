package com.fooffer.fooBackEnd;

import com.fooffer.fooBackEnd.model.vo.EmailAuthVo;
import com.fooffer.fooBackEnd.utils.RedisUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.containers.MongoDBContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;

import static com.fooffer.fooBackEnd.constant.EmailVerificationConstant.*;
import static org.junit.jupiter.api.Assertions.assertTrue;


@SpringBootTest
@Testcontainers
@ActiveProfiles("test")
@DisplayName("Redis Test")
public class RedisTest {
    @Container
    public static MongoDBContainer mongoDBContainer = new MongoDBContainer(
            "mongo:6.0")
            .withExposedPorts(27017);

    @Container
    public static GenericContainer<?> redisContainer =
            new GenericContainer<>(
                    DockerImageName.parse("redis:7"))
                    .withExposedPorts(6379);

    @Autowired
    private RedisTemplate redisTemplate;

    static {
        mongoDBContainer.start();
        redisContainer.start();
    }
    @DynamicPropertySource
    static void registerProperties(DynamicPropertyRegistry registry) {
        registry.add(
                "spring.data.mongodb.uri",
                mongoDBContainer::getReplicaSetUrl
        );

        registry.add("spring.redis.host", redisContainer::getHost);
        registry.add("spring.redis.port", () -> redisContainer.getFirstMappedPort());
    }

    @Test
    @DisplayName("Test if containers are running")
    void testIsRunning(){
        assertTrue(redisContainer.isRunning());
        assertTrue(mongoDBContainer.isRunning());
    }

    @Test
    @DisplayName("Test Redis set and get")
    void testRedis() {
        redisTemplate.opsForValue().set("user_1", "test_1");
        Assertions.assertEquals(redisTemplate.opsForValue().get("user_1"), "test_1");

        RedisUtil.set("user_2", "test_2");
        Assertions.assertEquals(RedisUtil.get("user_2"), "test_2");
    }

    @Test
    @DisplayName("Test Redis set and get for EmailAuthVo")
    void testRedisSaveUser(){
        EmailAuthVo emailAuthVo = new EmailAuthVo();
        emailAuthVo.setUserEmail(EMAIL);
        emailAuthVo.setPassword(PASSWORD);
        emailAuthVo.setReferIdString(REFER_ID);

        RedisUtil.set(EMAIL, CODE);
        RedisUtil.set(EMAIL_CODE, emailAuthVo);

        String cacheCode = (String) RedisUtil.get(EMAIL);
        EmailAuthVo emailAuthVo1 = (EmailAuthVo) RedisUtil.get(EMAIL_CODE);

        Assertions.assertEquals(CODE, cacheCode);
        Assertions.assertEquals(emailAuthVo1.getUserEmail(), emailAuthVo.getUserEmail());
        Assertions.assertEquals(emailAuthVo1.getPassword(), emailAuthVo.getPassword());
    }
}
