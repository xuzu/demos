---
name: Feature request
about: Suggest a new idea for Fooffer backend.
title: ''
labels: ''
assignees: ''

---

## User story

<!--
 Brief description of the task
 As a developer/product manager/customer, I want ...
-->

## Prerequisites (if any)
<!--
- [ ] not ready
- [x] ready
-->

## Acceptance Criteria
<!--
    Things that need to be completed
    AKA Definition of Done
-->

## Testing steps + data (if available)

## Follow-up work (if applicable)
