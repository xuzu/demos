---
name: Bug report
about: For bugs that exist in Fooffer website
title: ""
labels: bug
assignees: ''
---

## Bug Description
<!--
    Describe the bug
-->