// 这个是webpack的配置文件，vue-cli没有显式的配置，得自己手动创建这个文件
const AutoImport = require('unplugin-auto-import/webpack')
const Components = require('unplugin-vue-components/webpack')
const { ElementPlusResolver } = require('unplugin-vue-components/resolvers')

module.exports = {
    publicPath: '/',
    productionSourceMap: process.env.NODE_ENV !== 'production', // 生产环境下设置 source map为false以加速构建
    devServer: {
        host: 'localhost',
        port: 3000,
        // 解决跨域问题
        proxy: {
            '^api': {
                target: 'http://localhost:8080',
                ws:true,
                changeOrigin:true,
                pathRewrite: {
                    '^api':''
                }
            }
        }
    },
    configureWebpack: {
        plugins: [
            AutoImport({
                resolvers: [ElementPlusResolver()],
            }),
            Components({
                resolvers: [ElementPlusResolver()],
            }),
        ]
    },
    css: {
        loaderOptions: {
            scss: {
                additionalData: `
                    @import "@/style/main.scss";
                `
            }
        }
    }
}
