
describe('HeaderInMain.vue', () => {
    test('Test header text', () => {
        // const wrapper = shallowMount(HeaderInMain)

        // const headerText = wrapper.get('[class="text-div"]')

        // expect(headerText.text()).toBe('Home')

    })
})
