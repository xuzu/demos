---
name: Bug report
about: For bugs that exist in atomeocean.com website
title: "[BUG] "
labels: bug
assignees: ''
---

## Bug Description
<!--
    Describe the bug
-->
