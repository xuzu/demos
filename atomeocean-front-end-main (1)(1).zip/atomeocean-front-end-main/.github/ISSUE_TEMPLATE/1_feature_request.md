---
name: Feature request
about: Suggest a new idea for atomeocean.com frontend.
title: ''
labels: ''
assignees: ''

---

## User story
<!--
 Brief description of the task
 As a customer/developer/product manager/, I want ...
-->

## Prerequisites (if any)
<!--
- [ ] not ready
- [x] ready
-->


## Acceptance Criteria
<!--
    Things that need to be completed
    AKA Definition of Done
-->


## Testing steps + data (if available)


## Follow-up work (if applicable)