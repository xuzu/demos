/**
 * tinymce 需要import多个插件
 */

import 'tinymce/themes/silver/theme'
import 'tinymce/icons/default'
import 'tinymce/models/dom'

// tinymce插件按需导入
import 'tinymce/plugins/table'
import 'tinymce/plugins/image' // 上传图片
import 'tinymce/plugins/wordcount' // 字数统计
import 'tinymce/plugins/lists' // 字数统计
import 'tinymce/plugins/save' //
import 'tinymce/plugins/media' //
import 'tinymce/plugins/preview' //
import 'tinymce/skins/ui/oxide/skin.min.css'
import 'tinymce/skins/ui/oxide/content.min.css'
import 'tinymce/skins/content/default/content.css'
