/**
 * 文章相关的常量
 */

// 首页中文章列表每次请求的数量
export const HOME_ARTICLE_LIST_LIMIT = 15

// profile页面读取的文章数量
export const PROFILE_ARTICLE_LIST_LIMIT = 5

// 作者名字的默认值
export const DEFAULT_AUTHOR_NAME = 'Anonymous'

/**
 * 文章分类Enum
 */
export enum ArticleCategory {
  JobPost = 'JobPost',
  Reference = 'Reference',
  Default = 'Default',
}

/**
 * 文章可读权限
 */
export enum ArticleVisibility {
  // 完全公开
  EveryoneCanSee = 'EveryoneCanSee',

  // 不在首页上显示
  NotOnFrontPage = 'NotOnFrontPage',

  // 仅作者自己可见
  AuthorSelfOnly = 'AuthorSelfOnly',

  // 登录后可见
  NeedSignIn = 'NeedSignIn',

  // 关注者可见
  FollowersOnly = 'FollowersOnly',
}
