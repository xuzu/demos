/**
 * 保存注册相关常量
 * 呈现给view层的信息
 */
export const EMAIL_TAKEN_MESSAGE = '这个邮箱已经注册过啦'
export const INVALID_CAPTCHA = '请输入正确的验证码'
export const INVALID_REGISTRATION_INFO = '注册信息不完整，请重新填写'
export const INVALID_REFER_LINK = '您的邀请链接不可用'
export const VERIFICATION_CODE_EXPIRED = '您的验证码已过期'
export const VERIFICATION_CODE_INCORRECT = '验证码错误'
export const REGISTRATION_INFO_EXPIRED = '注册信息过期'
