/**
 * 编辑器页面上的常量和文本
 *
 * todo: 考虑不同语言版本
 */

// 文章分类列表
export const CATEGORY_NAME_LIST = [
  // 分类列表
  { value: 1, label: 'Default' },
  { value: 2, label: 'Job Post' },
  { value: 3, label: 'Reference' },
]

export const VISIBILITY_LIST = [
  // 可见性设置列表
  { value: 1, label: '所有人可以查看' },
  { value: 2, label: '登录后可以查看' },
  // TODO: 暂不提供关注可见选项
  // { value: 3, label: "关注后可以查看" },
  // { value: 4, label: "互相关注者可见" },
  { value: 5, label: '只对自己可见' },
]

export const UPLOAD_ARTICLE = '提交文章'

export const ARTICLE_EDITED_RESPONSE_MESSAGE = 'your article has been submitted'

export const ARTICLE_ERRORED_RESPONSE_MESSAGE =
  'there was error submitting article'
