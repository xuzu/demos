export const TABS_LABEL = [
  {
    category: '动态',
    filters: ['全部', '点赞', '收藏', '发表'],
  },
  {
    category: '发表',
    filters: ['全部', '文章', '想法'],
  },
  {
    category: '收藏',
    filters: ['全部收藏'],
  },
  {
    category: '关注',
    filters: ['关注', '粉丝', '好友'],
  },
]
