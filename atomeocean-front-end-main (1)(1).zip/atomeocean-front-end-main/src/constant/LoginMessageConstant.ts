/**
 * 登录相关常量
 */

export const LOGIN_SUCCESSFUL_MESSAGE = '登录成功'
export const LOGIN_FAILURE_MESSAGE = '邮箱或密码不正确'
export const TOKEN_EXPIRED = '您的登录信息已过期，请重新登录'
