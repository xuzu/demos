export const FILE_UPLOAD_FAILED = '文件上传失败'
