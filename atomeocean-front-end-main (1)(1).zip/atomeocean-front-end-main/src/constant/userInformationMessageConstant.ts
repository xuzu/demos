export const FILE_LOAD_FAILED = '文件加载失败'
export const UPDATE_SUCCESS = '修改成功'
export const DEFAULT_NICKNAME = ''
export const DEFAULT_MOTTO = '这人有点懒，没写简介'
export const DEFAULT_SELF_INTRODUCTION = ''
export const DEFAULT_VISIBILITY = 1

export const REQUEST_TOO_OFTEN = '请求过于频繁'
export const USER_NOT_EXIST = '该用户不存在'
export const INVALID_INPUT = '填写的资料不符合规格'
export const UNAUTHORIZED_ACCESS = '没有权限访问该资源'
export const EXPERIENCE_EXISTED = '该经历已存在'
export const EXPERIENCE_NOT_EXISTED = '该经历不存在'
