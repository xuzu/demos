/**
 * 保存recaptcha action常量
 */

export const SIGN_UP_RECAPTCHA_ACTION = 'signup'

export const VERIFY_RECAPTCHA_ACTION = 'verify'

export const SIGN_IN_RECAPTCHA_ACTION = 'signin'

export const RESET_PASSWORD_RECAPTCHA_ACTION = 'reset'

/**
 * 保存recaptcha token请求中的异常
 */

export const RECAPTCHA_EXECUTION_EXCEPTION = '身份认证失败，请重试'
