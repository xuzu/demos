export const DEGREE_LEVEL = [
  {
    value: '0',
    label: 'High School',
  },
  {
    value: '1',
    label: 'Bachelor',
  },
  {
    value: '2',
    label: 'Master',
  },
  {
    value: '3',
    label: 'Doctor',
  },
  {
    value: '4',
    label: 'Postdoc',
  },
]
