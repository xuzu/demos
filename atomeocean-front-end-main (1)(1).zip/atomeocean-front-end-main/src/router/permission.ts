/**
 * @name permission
 * @description 全局路由过滤、权限过滤
 *
 * 路由守卫
 */
import router from '@/router'
import { usePermissionStore } from '@/store/permission'
import { useRouteStore } from '@/store/route'
import { useUserStore } from '@/store/user'
import { useUserInformationStore } from '@/store/userInformation'
import { useProfileStore } from '@/store/profile'
import { load } from '@/utils'
import { useEditorStore } from '@/store/editor'

// 一旦页面刷新，默认值是false，可以重新添加动态路由
let dynamicRoutesLoaded = false

/**
 * to: 将要访问的路径
 * from：从哪里来
 * next：强制放行的路径
 *
 * 检查to的路径是否在白名单或是动态路由表中
 */
router.beforeEach(async (to, from, next) => {
  const toName = to.name ?? to.path.slice(1)
  const permissionStore = usePermissionStore()
  const routeStore = useRouteStore()
  const userStore = useUserStore()
  const userInformationStore = useUserInformationStore()
  const profileStore = useProfileStore()
  const editorStore = useEditorStore()

  // 如果token已过期，为用户登出
  if (permissionStore.getExpired) {
    //取消之前的loading效果
    load.hide()
    //清空所有权限相关数据
    permissionStore.$reset()
    userStore.$reset()
    userInformationStore.$reset()
    profileStore.$reset()
    editorStore.$reset()
    // 重定向到首页
    next({ path: routeStore.homePagePath })
  }
  // 有token即为已登录
  else if (permissionStore.getToken) {
    if (to.path !== routeStore.logInPath) {
      // 如果动态路由没有加载过，需要加载一下，应对需要刷新的情况
      if (!dynamicRoutesLoaded) {
        const cachedDynamicRoutes =
          await permissionStore.generateDynamicRoutes()
        for (const cachedDynamicRoute of cachedDynamicRoutes) {
          router.addRoute({
            path: cachedDynamicRoute.path,
            name: cachedDynamicRoute.name,
            component: () =>
              import(`@/views/${cachedDynamicRoute.component}.vue`),
          })
        }
        // 防止重复加载
        dynamicRoutesLoaded = true
        // 获取动态路由表后，重新进入路由
        next({ ...to, replace: true })
      } else {
        if (router.hasRoute(toName)) {
          next()
        } else {
          // 重定向到首页
          next({ path: routeStore.homePagePath })
        }
      }
    }
    // 目标路径是登录页，引导到首页因为已经登陆
    else {
      // 应该发消息说已经登陆
      next({ path: routeStore.homePagePath })
    }
  }
  // 未登录，此时router只有静态路由表
  else {
    if (router.hasRoute(toName)) {
      next()
    }
    // 路径不在静态路由表中，引导到登录页面
    else {
      next({ path: routeStore.logInPath })
    }
  }
})
