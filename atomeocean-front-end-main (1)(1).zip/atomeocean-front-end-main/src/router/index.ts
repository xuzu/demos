import { createRouter, createWebHistory, RouteRecordRaw } from 'vue-router'

// 静态路由
const publicRoutes: Array<RouteRecordRaw> = [
  {
    path: '/',
    name: 'home',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import('@/views/HomeView.vue'),
  },
  {
    path: '/register',
    name: 'register',
    component: () => import('@/views/AuthenticationDialogView.vue'),
  },
  {
    path: '/emailverify',
    name: 'emailverify',
    component: () => import('@/views/AuthenticationDialogView.vue'),
  },
  {
    path: '/signin',
    name: 'signin',
    component: () => import('@/views/AuthenticationDialogView.vue'),
  },
  {
    path: '/resetpassword/email',
    name: 'resetpassword/email',
    component: () => import('@/views/AuthenticationDialogView.vue'),
  },
  {
    path: '/resetpassword/verify',
    name: 'resetpassword/verify',
    component: () => import('@/views/AuthenticationDialogView.vue'),
  },
  {
    path: '/resetpassword/newpassword',
    name: 'resetpassword/newpassword',
    component: () => import('@/views/AuthenticationDialogView.vue'),
  },
  {
    path: '/pro/:userId',
    name: 'profile',
    component: () => import('@/views/ProfileView.vue'),
  },
  {
    path: '/article/:articleId',
    name: 'article',
    component: () => import('@/views/ArticleView.vue'),
  },
  {
    path: '/editor',
    name: 'editor',
    component: () => import('@/views/PublishView.vue'),
  },
  {
    path: '/notfound',
    name: 'notfound',
    meta: {
      isCustomPage: true,
    },
    component: () => import('@/views/NotFoundView.vue'),
  },
  {
    path: '/error',
    name: 'error',
    meta: {
      isErrorPage: true,
    },
    component: () => import('@/views/ErrorPageView.vue'),
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes: publicRoutes,
})

export default router
