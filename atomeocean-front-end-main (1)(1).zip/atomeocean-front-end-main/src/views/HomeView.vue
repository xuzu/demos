<!-- 首页内容View -->
<template>
  <div class="home-div">
    <el-row class="home-wrap" type="flex">
      <el-col class="content-wrap display-flex-column-center">
        <div class="home-main-div">
          <div class="header-in-main-div">
            <HeaderInMain></HeaderInMain>
          </div>
          <div class="article-list-div" :class="showSiderbar ? 'mini' : ''">
            <el-tabs v-model="activeName" @tab-click="handleClick">
              <el-tab-pane label="推荐阅读" name="recommend"></el-tab-pane>
              <el-tab-pane
                v-if="userInformationStore.nickname"
                label="我的关注"
                name="follow"
              ></el-tab-pane>
            </el-tabs>

            <ArticleListView
              v-if="activeName === 'recommend'"
              :article-list-params="articleListParams"
            ></ArticleListView>

            <ArticleListView
              v-if="activeName === 'follow'"
              :article-list-params="articleListParams"
            ></ArticleListView>
          </div>
        </div>
      </el-col>
      <div class="home-side-bar-div" v-if="showSiderbar">
        <SideBarView></SideBarView>
      </div>
    </el-row>
  </div>
</template>

<script lang="ts" setup>
import ArticleListView from '@/views/ArticleListView.vue'
import { RequestArticleListParams } from '@/api/article/model'
import { HOME_ARTICLE_LIST_LIMIT } from '@/constant/articleAndListConstant'
import SideBarView from '@/views/SideBarView.vue'
import HeaderInMain from '@/components/HeaderInMain.vue'
import { ref } from 'vue'
import type { TabsPaneContext } from 'element-plus'
import { useUserInformationStore } from '@/store/userInformation'

const activeName = ref('recommend')
const showSiderbar = ref(false)
const handleClick = (tab: TabsPaneContext, event: Event) => {
  console.log(tab, event)
}
const userInformationStore = useUserInformationStore()

/**
 * 首页的文章请求
 */
const articleListParams: RequestArticleListParams = {
  limit: HOME_ARTICLE_LIST_LIMIT,
}
</script>

<style lang="scss" scoped>
.home-div {
  width: 1280px;
  margin-top: 20px;
  .home-wrap {
    flex-wrap: none;
    .content-wrap {
      flex: 1;
    }
    .home-side-bar-div {
      width: 296px;
    }
  }
  .home-main-div {
    height: 100%;
    width: $main-width-no-side-bar;

    .header-in-main-div {
      height: 376px;
      width: 100%;
    }

    .article-list-div {
      background-color: $background-white;
      padding: 32px 72px;
      min-height: 100vh;

      &.mini {
        padding: 16px 32px;
      }
    }
  }

  .home-side-bar-div {
    position: relative;
    width: 248px;
    height: 100%;
    padding: 16px 24px 16px 32px;
  }
  ::v-deep .el-tabs__content {
    overflow: visible;
  }
  ::v-deep .control_wrap .icon_item .content {
    z-index: 99;
  }

  ::v-deep .el-tabs {
    .el-tabs__active-bar {
      height: 1px;
      background-color: #212427;
    }
    .el-tabs__item.is-active {
      color: #212427;
    }
    .el-tabs__nav-wrap::after {
      background-color: #ececec;
    }
  }
}
</style>
