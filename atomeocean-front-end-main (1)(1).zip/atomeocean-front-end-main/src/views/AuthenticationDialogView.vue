<template>
  <el-dialog
    v-model="dialogVisible"
    :before-close="handleClose"
    :show-close="false"
    class="custom-dialog"
  >
    <template #header>
      <div class="header">
        <el-button @click="close">
          <Icon icon="maki:cross" class="cross" />
        </el-button>
      </div>
    </template>

    <SignInDialogContent v-if="showSignIn"></SignInDialogContent>
    <VerificationDialogContent
      v-else-if="showVerification"
    ></VerificationDialogContent>

    <!-- Reset Password related -->
    <ResetPasswordEmailInputDialogContent
      v-else-if="showResetPasswordEmailInput"
    >
    </ResetPasswordEmailInputDialogContent>
    <ResetPasswordEmailVerifyDialogContent
      v-else-if="showResetPasswordEmailVerify"
    >
    </ResetPasswordEmailVerifyDialogContent>
    <ResetPasswordPasswordInputDialogContent
      v-else-if="showResetPasswordPasswordInput"
    >
    </ResetPasswordPasswordInputDialogContent>
    <!-- Register -->
    <RegisterDialogContent v-else></RegisterDialogContent>
  </el-dialog>
</template>

<script lang="ts" setup>
import ResetPasswordEmailInputDialogContent from '@/components/ResetPasswordEmailInputDialogContent.vue'
import ResetPasswordEmailVerifyDialogContent from '@/components/ResetPasswordEmailVerifyDialogContent.vue'
import ResetPasswordPasswordInputDialogContent from '@/components/ResetPasswordPasswordInputDialogContent.vue'
import { ElMessageBox } from 'element-plus'
import { computed, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'

const route = useRoute()
const router = useRouter()
const showSignIn = computed(() => route.name === 'signin')
const showVerification = computed(() => route.name === 'emailverify')
import { Icon } from '@iconify/vue'

// Reset Password related
const showResetPasswordEmailInput = computed(
  () => route.name === 'resetpassword/email',
)
const showResetPasswordEmailVerify = computed(
  () => route.name === 'resetpassword/verify',
)
const showResetPasswordPasswordInput = computed(
  () => route.name === 'resetpassword/newpassword',
)

const dialogVisible = ref(true)

const handleClose = (done: () => void) => {
  ElMessageBox.confirm('Are you sure to go back?')
    .then(() => {
      close()
      done()
    })
    .catch((err) => {
      console.log(err)
    })
}

const close = () => {
  router.back()
}
</script>

<style lang="scss" scoped>
.header {
  display: flex;
  justify-content: end;
  height: 24px;

  .cross {
    width: 24px;
    height: 24px;
  }

  .el-button {
    border: none;
    border-radius: 50%;
    height: 20px;
    padding: 0;

    .el-icon {
      font-size: 20px;
    }
  }

  .el-button:hover {
    background-color: transparent;
    color: rgb(128, 129, 133);
  }
}
</style>

<style lang="scss">
.custom-dialog {
  width: 500px;

  .el-dialog__header {
    margin: 0;
    padding-bottom: 0;
  }

  .el-dialog__body {
    padding-top: 0;
  }
}
</style>
