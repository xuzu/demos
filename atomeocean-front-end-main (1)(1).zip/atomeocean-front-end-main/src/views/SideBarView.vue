<!-- 右侧side bar -->
<template>
  <div class="side-bar-div">
    <div class="section with-bottom">
      <h3>个人中心</h3>
    </div>
    <div class="section with-bottom"><h3>热门文章</h3></div>
    <div class="section with-bottom"><h3>推荐关注</h3></div>
    <div class="section"><h3>热门话题</h3></div>
    <div class="section">广告位</div>
    <div class="footer-container-div">
      <FooterView></FooterView>
    </div>
  </div>
</template>

<script lang="ts" setup>
import FooterView from '@/views/FooterView.vue'
</script>

<style lang="scss" scoped>
.side-bar-div {
  width: 248px;
  .section {
    padding: 0 8px 32px 8px;
    margin-bottom: 32px;
  }
  .footer-container-div {
    display: flex;
    height: 4vh;
    width: 100%;
    justify-content: center;
  }
  h3 {
    font-family: $text-font-family;
    font-size: 16px;
    font-weight: 500;
    line-height: 28px;
    letter-spacing: 0em;
    text-align: left;
    color: #212427;
    margin: 0;
  }
  .with-bottom {
    padding-bottom: 32px;
    border-bottom: 1px solid $border-color-grey;
  }
}
</style>
