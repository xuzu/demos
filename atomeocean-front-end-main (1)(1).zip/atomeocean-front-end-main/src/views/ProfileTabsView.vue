<template>
  <el-tabs v-model="activeTab" :stretch="true" @tab-change="handleTabChange">
    <el-tab-pane
      v-for="(tab, tabIndex) in TABS_LABEL"
      :key="tabIndex"
      :name="tabIndex"
    >
      <template #label>
        <div class="tab-label">
          <div class="categories" :class="{ active: activeTab === tabIndex }">
            {{ props.isCurrentUser ? '我的' : '' }}{{ tab.category }}
          </div>
          <div class="filters" v-show="activeTab === tabIndex">
            <div
              v-for="(filter, filterIndex) in tab.filters"
              :key="filterIndex"
              :class="{ filterActive: activeFilter === filterIndex }"
              @click="changeActiveFilter(filterIndex)"
            >
              {{ filter }}
            </div>
          </div>
        </div>
      </template>
    </el-tab-pane>
    <div class="tab-content" :class="{ blurring: props.hasNoVisibility }">
      <ArticleListView
        v-if="activeTab === 0 && activeFilter !== 1 && activeFilter !== 2"
        :article-list-params="articleListParams"
        :load-activity-in-profile="true"
      ></ArticleListView>
      <ArticleListView
        v-if="activeTab === 1 && activeFilter !== 2"
        :article-list-params="articleListParams"
      ></ArticleListView>
    </div>
    <div v-show="props.hasNoVisibility" class="blocked-content">
      <div class="text-box">该内容登陆后可见</div>
    </div>
  </el-tabs>
  <StripePaymentComponent />
</template>

<script lang="ts" setup>
import { ref, defineProps, watch } from 'vue'
import { TABS_LABEL } from '@/constant/profilePageConstants'
import ArticleListView from '@/views/ArticleListView.vue'
import { RequestArticleListParams } from '@/api/article/model'
import { PROFILE_ARTICLE_LIST_LIMIT } from '@/constant/articleAndListConstant'
import { useRoute } from 'vue-router'
import { useArticleListStore } from '@/store/articleList'
import StripePaymentComponent from '@/components/StripePaymentComponent.vue'

const props = defineProps({
  isCurrentUser: {
    type: Boolean,
  },
  hasNoVisibility: {
    type: Boolean,
  },
})

const activeTab = ref(0)
const activeFilter = ref(0)
const changeActiveFilter = (index: number) => {
  activeFilter.value = index
}

const handleTabChange = () => {
  // 每当跳转到另一个tab, filter的index恢复到0
  activeFilter.value = 0
}

const route = useRoute()
const articleListParams: RequestArticleListParams = {
  authorId: route.params.userId as string,
  limit: PROFILE_ARTICLE_LIST_LIMIT,
}

const articleListStore = useArticleListStore()

//监听路径上用户id变化，从而请求对应用户的文章
watch(
  () => route.params.userId,
  async (newId) => {
    if (route.path.startsWith('/pro') && newId) {
      articleListParams.authorId = newId as string
      await articleListStore.loadArticleList(articleListParams || {})
    }
  },
)
</script>

<style lang="scss" scoped>
.el-tabs {
  :deep(.el-tabs__header) {
    padding: 0;
    position: relative;
    margin: 0 0 0px;
  }

  :deep(.el-tabs__item) {
    height: 77px;
    padding: 0px;
    display: flex;
    justify-content: center;
    align-items: flex-start;
    &.is-active {
      color: black;
    }
  }

  :deep(.el-tabs__nav-wrap::after) {
    height: 1px;
    background-color: $gray-100;
    position: absolute;
    bottom: 35px;
  }

  :deep(.el-tabs__active-bar) {
    height: 5px;
    background-color: $blue-900;
    position: absolute;
    bottom: 35px;
  }

  .tab-label {
    .categories {
      padding-top: 7px;
      padding-bottom: 3px;
      font-family: $text-font-family;
      font-size: 16px;
      font-weight: 500;
      line-height: 28px;
      position: relative;
      color: $blue-900;

      &.active {
        font-weight: 700;
      }
    }

    .filters {
      display: flex;
      justify-content: space-between;
      gap: 23px;
      margin-top: 3px;
      font-family: $text-font-family;
      font-size: 14px;
      font-weight: 700;
      line-height: 28px;
      color: $blue-900;
      .filterActive {
        color: $blue-700;
      }
    }
  }
}

.tab-content {
  padding-left: 29px;
  padding-right: 27px;
}

.blurring {
  filter: blur(10px);
}

.blocked-content {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0);
  z-index: 9999;
  display: flex;
  .text-box {
    width: 240px;
    height: 150px;
    border: 1px solid $gray-300;
    box-shadow: 4px 4px 4px 0px rgba(0, 0, 0, 0.25);
    background-color: $background-white;
    position: relative;
    top: 300px;
    left: 200px;
    display: flex;
    align-items: center;
    justify-content: space-around;
    font-family: $text-font-family;
    font-size: 20px;
    font-weight: 500;
    line-height: 32px;
    color: $gray-500;
  }
}
</style>
