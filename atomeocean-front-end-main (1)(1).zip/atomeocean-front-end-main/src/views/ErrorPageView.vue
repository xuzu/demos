<template>
  <div class="page">
    <el-container>
      <el-header class="nav_header">
        <NavigationBar :isErrorPage="props.isErrorPage" />
      </el-header>
      <el-main class="main_content">
        <div class="tip_texts">
          <h1>网站维护中</h1>
          <p>你发现自己身处一片奇怪的海域，这里什么都没有。</p>
        </div>
        <div class="search_box">
          <el-input
            v-model="searchValue"
            placeholder="搜索感兴趣的内容"
          ></el-input>
          <i class="search_icon" @click="searchContent"></i>
        </div>
      </el-main>
    </el-container>
  </div>
</template>

<script setup>
import NavigationBar from '@/components/NavigationBar.vue'
import { ElMessage } from 'element-plus'
import { ref, defineProps } from 'vue'
const searchValue = ref('')
const props = defineProps({
  isErrorPage: {
    type: Boolean,
    default: false,
  },
})
// 搜索
const searchContent = () => {
  if (!searchValue.value) {
    ElMessage.error('请输入你要搜索的内容~')
    return false
  }
  ElMessage.success(`提交的内容是--> ${searchValue.value}`)
  searchValue.value = ''
}
</script>

<style lang="scss" scoped>
.page {
  margin: 0 auto;
  max-width: 1920px;
  height: 1080px;
  padding-top: 12px;
  box-sizing: border-box;
  background: url('@/assets/page_bg.jpg') no-repeat center center/100% 100%;
  :deep(.navigation-div),
  :deep(.navigation-div .el-menu) {
    background: none;
    border: none;
  }
  .nav_header {
    padding: 0 12px !important;
  }
  .main_content {
    padding-top: 215px;
    text-align: center;
    color: $background-white;
  }
  .tip_texts {
    h1 {
      margin: 0;
      font-family: $text-font-family;
      font-size: 64px;
      font-weight: 700;
      line-height: 1;
      letter-spacing: 0;
    }
    p {
      margin: 44px 0 0;
      font-family: $text-font-family;
      font-size: 20px;
      font-weight: 500;
      line-height: 1;
      letter-spacing: 0;
    }
  }
  .search_box {
    position: relative;
    padding-right: 47px;
    box-sizing: border-box;
    margin: 240px auto 0;
    width: 644px;
    height: 48px;
    border-radius: 50px;
    border: 2px solid $background-white;
    background: rgba($color: $background-white, $alpha: 0.2);
    :deep(.el-input) {
      height: 100%;
    }
    :deep(.el-input__wrapper) {
      padding-left: 35px;
      box-sizing: border-box;
      font-size: 18px;
      border: none;
      outline: none;
      box-shadow: none;
      background: none;
      color: $background-white;
    }
    :deep(.el-input__inner) {
      color: $background-white;
      &::placeholder {
        color: $background-white;
      }
    }
    .search_icon {
      position: absolute;
      top: 50%;
      right: 15px;
      margin-top: -16px;
      width: 32px;
      height: 32px;
      cursor: pointer;
      background: url('@/assets/search_icon.png') no-repeat center center/100%
        100%;
    }
  }
}
:deep(.navigation-div .el-menu .el-menu-item),
:deep(.navigation-div .el-menu .article-category-span),
:deep(.navigation-div .el-menu .signin-span) {
  color: $background-white;
}
:deep(.navigation-div .el-menu-item:hover *) {
  color: #0b4397;
}
:deep(.right-end-header-div-not-authenticated) {
  margin-left: 370px;
}
</style>
