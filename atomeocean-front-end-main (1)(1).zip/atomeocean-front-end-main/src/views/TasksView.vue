<template>
  <div></div>
</template>

<script lang="ts" setup>
import { createAxiosByInterceptors } from '@/utils/http'
import { onMounted } from 'vue'
import { useRouter } from 'vue-router'

const request = createAxiosByInterceptors({
  baseURL: process.env.VUE_APP_ROOT_API,
})
const router = useRouter()

onMounted(async () => {
  const currentPath = router.currentRoute.value.path
  const res = await request.get(currentPath)

  console.log('Get mapping 任务列表 => ' + res)

  const post = await request.post(currentPath)
  console.log('post mapping 创建了一个新任务 => ' + post)
})
</script>

<style scoped></style>
