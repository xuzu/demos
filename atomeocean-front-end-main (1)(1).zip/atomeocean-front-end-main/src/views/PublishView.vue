<script setup>
import editorView from './EditorView.vue'
</script>

<template>
  <div class="main">
    <div class="content">
      <editor-view />
    </div>
  </div>
</template>

<style lang="scss" scpoed>
.main {
  min-height: 1800px;
  background: #fafafa;
}
.content {
  margin: 32px auto 0;
  //width: 800px;
}
</style>
