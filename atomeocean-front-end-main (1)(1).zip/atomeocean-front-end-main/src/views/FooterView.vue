<template>
  <div class="footer-container-div display-flex">
    <div class="copyright-section">
      <el-link href="/"> AtomeOcean.com 2023 </el-link>
    </div>
    <mdicon name="CircleSmall" />
  </div>
</template>

<script lang="ts" setup>
/**
 * 这个view组件显示footer内容，包括careers，contact us等页面
 */
</script>

<style lang="scss" scoped>
.footer-container-div {
  .copyright-section {
    vertical-align: center;
    font-size: 12pt;
  }

  .careers-section {
    font-size: 12pt;
  }
}
</style>
