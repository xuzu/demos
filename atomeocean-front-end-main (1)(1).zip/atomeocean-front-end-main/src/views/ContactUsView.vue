<template>
  <div class="contact-us-div">
    <el-row justify="center" class="front-page-row">
      <el-col :md="16" :sm="20">
        <h1>邮件联系我们:</h1>
      </el-col>
    </el-row>
    <el-row justify="center">
      <el-col :span="20" :md="20" :sm="20">
        <div class="contact-us-form-div">
          <h3>Email: customer@atomeocean.com</h3>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<!-- 负责contact us的页面 -->
<script lang="ts" setup></script>

<style scoped>
.contact-us-div {
}
</style>
