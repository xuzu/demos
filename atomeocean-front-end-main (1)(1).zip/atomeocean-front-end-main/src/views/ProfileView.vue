<template>
  <div class="profile-div">
    <ProfileHeader :is-current-user="isCurrentUser" />
    <el-row class="main-container">
      <el-col :sm="24" :md="6" :lg="8" class="aside">
        <ProfileBasicInformation :is-current-user="isCurrentUser" />
        <ProfileDetailedInformation
          :is-current-user="isCurrentUser"
          :has-no-visibility="hasNoVisibility"
        />
      </el-col>
      <el-col :sm="24" :md="18" :lg="16" class="main">
        <ProfileTabsView
          :is-current-user="isCurrentUser"
          :has-no-visibility="hasNoVisibility"
        />
      </el-col>
    </el-row>
  </div>
</template>

<script lang="ts" setup>
import { computed, onMounted, reactive, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import { RequestUserInformationParams } from '@/api/userInformation/model'
import { useUserStore } from '@/store/user'
import { useProfileStore } from '@/store/profile'
import { ElMessage } from 'element-plus'
import to from 'await-to-js'
import { useRouter } from 'vue-router'
import ProfileTabsView from './ProfileTabsView.vue'
import ProfileBasicInformation from '@/components/profile/ProfileBasicInformation.vue'
import ProfileDetailedInformation from '@/components/profile/ProfileDetailedInformation.vue'
import ProfileHeader from '@/components/profile/ProfileHeader.vue'

const route = useRoute()
const userStore = useUserStore()
const profileStore = useProfileStore()
const router = useRouter()

const currentUser = reactive({
  userId: userStore.getUserId,
})

const isCurrentUser = ref(
  currentUser.userId === (route.params.userId as string),
)

const requestProfile = async () => {
  const requestUserInformationParams: RequestUserInformationParams = {
    encodedUserId: route.params.userId as string,
  }
  // 调用后端api拿回结果
  const [error, userInformationResponse] = await to(
    profileStore.getUserInformation(requestUserInformationParams),
  )

  // 网络请求异常
  if (error) {
    ElMessage.error(error.message)
    await router.replace('/error')
  } else if (userInformationResponse) {
    //请求失败
    if (userInformationResponse.status !== 100) {
      ElMessage.error(userInformationResponse.message)
      return
    }
    // 请求成功
  }
}

//监听路径上用户id变化，从而请求对应profile
watch(
  () => route.params.userId,
  async (newId) => {
    if (route.path.startsWith('/pro') && newId) {
      await requestProfile()
      // 更新isCurrentUser
      isCurrentUser.value = currentUser.userId === newId
    }
  },
)

// 加载时读取profile信息
onMounted(async () => {
  await requestProfile()
})

// 根据登陆状态与用户权限设定 判断是否加入模糊效果
const hasNoVisibility = computed(
  () => !userStore.getUserId && profileStore.getVisibility > 1,
)
</script>

<style lang="scss" scoped>
.profile-div {
  font-family: $text-font-family;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: $background-grey;
  height: 100vh;

  .main-container {
    width: 100%;
    max-width: $profile-width;
    background-color: $background-white;
    flex-grow: 1;
    flex-basis: 0;

    .aside {
      box-sizing: border-box;
      border-right: 1px solid $gray-300;
    }

    .main {
      flex: 1;
    }
  }
}
</style>
