<template>
  <div class="articles">
    <el-row justify="center">
      <el-col
        :span="24"
        :md="24"
        :sm="24"
        v-infinite-scroll="loadMoreArticleRows"
      >
        <div v-for="(article, index) in articleList" :key="index">
          <ArticleRow
            :article="article"
            :article-index="index"
            :load-activity-in-profile="props.loadActivityInProfile"
          ></ArticleRow>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script lang="ts" setup>
import ArticleRow from '@/components/ArticleRow.vue'
import { defineProps, onMounted, PropType } from 'vue'
import { RequestArticleListParams } from '@/api/article/model'
import { useArticleListStore } from '@/store/articleList'
import { storeToRefs } from 'pinia'
import { useArticleStore } from '@/store/article'

// 加载多个articles
const props = defineProps({
  articleListParams: {
    type: Object as PropType<RequestArticleListParams>,
  },
  loadActivityInProfile: {
    type: Boolean,
  },
})

const articleListStore = useArticleListStore()
const articleStore = useArticleStore()

const { articleList } = storeToRefs(articleListStore)

// 当组件被加载时触发
onMounted(async () => {
  // 强制更新文章列表，并清空文章缓存
  articleStore.$reset()
  articleListStore.$reset()

  await articleListStore.loadArticleList(props.articleListParams || {})
})

// todo: 支持分页加载更多文章
const loadMoreArticleRows = () => {
  // console.log("");
}
</script>

<style scoped lang="scss"></style>
