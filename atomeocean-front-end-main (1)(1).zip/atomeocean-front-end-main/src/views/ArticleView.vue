<!-- 单个文章所在的组件 -->
<template>
  <div class="article_wrap" ref="articleWrap">
    <div class="article_wrapper">
      <div class="author_msg" v-if="articleStore.article.articleAuthor">
        <div class="author_msg_con">
          <div
            class="avatar"
            @click="
              navigateToProfile(articleStore.article?.articleAuthor?.authorId)
            "
          >
            <AvatarComponent
              :avatar-src="
                articleStore.article.articleAuthor.avatarLink ||
                defaultAvatarImage.path
              "
              :avatar-height="48"
              :avatar-width="48"
            />
          </div>
          <div class="right_box">
            <p
              class="name"
              @click="
                navigateToProfile(articleStore.article?.articleAuthor?.authorId)
              "
            >
              {{
                articleStore.article.articleAuthor?.nickname ||
                DEFAULT_AUTHOR_NAME
              }}
            </p>
            <!--            关注可能需要隐藏掉 -->
            <div class="follow">
              <span class="follow_number"
                >{{ data.userData.followsNumbers }}个关注</span
              >
              <div
                @click="handlerFollowing"
                @mouseenter="followingEnter"
                @mouseleave="followingLeave"
                :class="{
                  follow_setting: true,
                  followed: data.userData.isFollowed,
                  hover: data.userData.isFollowHover,
                }"
              >
                <i></i>
                <span>{{ getFollowText }}</span>
              </div>
            </div>
          </div>
        </div>
        <div class="author_msg_intro">
          {{ articleStore.article.articleAuthor.motto }}
        </div>
      </div>
      <div class="article_msg">
        <div class="left_area">
          <span>{{ articleStore.article.latestUpdateTime }}发布</span>
          <span>{{ articleStore.article.readMinutes }}分钟阅读</span>

          <span>{{ articleStore.article.viewCount }}次浏览</span>
        </div>
        <div class="right_area">
          <ArticleControl :isAuthor="isOwnArticle" />
        </div>
      </div>
      <div class="article_detail">
        <h1 class="article_detail_title">{{ articleStore.article.title }}</h1>
        <div
          class="article_detail_con"
          v-html="articleStore.article.content"
        ></div>
        <div class="article_detail_label">
          <div
            class="label_item"
            v-for="item of articleStore.article.addTagArray"
            :key="item"
          >
            {{ item.title }}
          </div>
        </div>
        <div class="article_detail_msg">
          <div class="like_area">
            <div
              class="like"
              :class="{ active: data.articleData.isLiked }"
              @click="handlerLikedArticle"
            >
              <i></i>
              <span class="like_number">{{
                data.articleData.likedNumbers
              }}</span>
            </div>
            <div
              class="dislike"
              :class="{ active: data.articleData.isDisLiked }"
              @click="handlerDisLikedArticle"
            >
              <i></i>
            </div>
          </div>
          <div class="right_area">
            <ArticleControl :isAuthor="isOwnArticle" />
          </div>
        </div>
      </div>
    </div>
    <!-- 推荐阅读 -->
    <div class="suggested_reading">
      <h2 class="suggested_reading_title">推荐阅读</h2>
      <div class="suggested_reading_con">
        <div class="suggested_list">
          <div
            class="suggested_item"
            :class="{ not_poster: !item.poster }"
            v-for="item of data.suggestedReadingList"
            :key="item"
          >
            <div class="poster" v-if="item.poster">
              <img :src="item.poster" alt="" />
            </div>
            <div class="reading_msg">
              <div class="author">
                <div class="author_msg">
                  <div class="avatar">
                    <img src="../assets/icon_user.png" alt="" />
                  </div>
                  <p class="name">{{ item.name }}</p>
                </div>
                <div class="article_data">
                  <span>{{ item.read_num }}分钟阅读</span>
                  <span>{{ item.view_num }}次浏览</span>
                </div>
              </div>
              <div class="article_msg">
                <h3 class="article_msg_title">{{ item.title }}</h3>
                <p class="article_msg_desc">{{ item.desc }}</p>
              </div>
            </div>
            <div class="reading_setting">
              <div class="left_area">
                <span v-for="it of item.labelList" :key="it"> # {{ it }}</span>
              </div>
              <div class="right_area">
                <ArticleControl />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="loading_tips" v-if="data.showBottomBar">
      <p v-if="data.isLoading">内容加载中<span class="dot">......</span></p>
      <p v-else>没有更多内容</p>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { onMounted, ref, reactive, computed, onBeforeUnmount } from 'vue'
import { useRoute } from 'vue-router'
import { debounce } from 'lodash'
import ArticleControl from '@/components/ArticleControl.vue'
import { useArticleStore } from '@/store/article'
import { useUserInformationStore } from '@/store/userInformation'
import { RequestArticleParams } from '@/api/article/model'
import {
  ArticleCategory,
  DEFAULT_AUTHOR_NAME,
} from '@/constant/articleAndListConstant'
import { navigateToProfile } from '@/utils/navigation'
import AvatarComponent from '@/components/AvatarComponent.vue'
import { defaultAvatarImage } from '@/store/article'
import { isEmpty } from '@/utils/general'
import to from 'await-to-js'
import { ElMessage } from 'element-plus'
import router from '@/router'

const route = useRoute()
const articleStore = useArticleStore()
const userStore = useUserInformationStore()

//mock data需要删掉
const data = reactive({
  showBottomBar: false,
  isLoading: true, // 加载ing
  page: 1,
  items: [],
  userData: {
    avatar: require('../assets/icon_user__large.png'),
    name: '求职大佬',
    followsNumbers: 100,
    intro: '现任职位，经历介绍，等', // 简介
    isAuthor: false, // 当前权限是否是作者
    isFollowed: false, // 关注作者
    isFollowHover: false, // 悬浮是否取消关注
  },
  articleData: {
    content: '', // 文章html内容
    createdTime: '2023年3月10日', // 发布时间
    readNumber: '8分钟', // 阅读次数
    viewNumber: '1.1万', // 浏览次数
    labelList: ['求职 (548)', 'ChatGPT（100）'], // 文章标签
    likedNumbers: 0, // 喜欢次数
    isLiked: false, // 喜欢该文章
    isDisLiked: false, // 不喜欢该文章
  },
  suggestedReadingList: [
    {
      poster: require('../assets/article_poster.png'),
      name: '毕业萌新',
      read_num: 4,
      view_num: 4,
      title:
        '文章标题文章标题文章标题文章标题文章标题文章标题文章标题文章标题文章标题',
      desc: '文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介',
      labelList: ['转码'],
    },
    {
      poster: '',
      name: '毕业萌新',
      read_num: 4,
      view_num: 4,
      title:
        '文章标题文章标题文章标题文章标题文章标题文章标题文章标题文章标题文章标题',
      desc: '文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介',
      labelList: ['转码', '转码23'],
    },
    {
      poster: require('../assets/article_poster.png'),
      name: '毕业萌新',
      read_num: 4,
      view_num: 4,
      title:
        '文章标题文章标题文章标题文章标题文章标题文章标题文章标题文章标题文章标题',
      desc: '文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介文章简介',
      labelList: ['转码'],
    },
  ] as any, // 推荐阅读
}) //mock data需要删掉

const isOwnArticle = ref(false)
const articleWrap: any = ref(null)
const observer: any = ref(null)
const showCreateName = ref(true)

// 文章可能会被删除或无权限
// todo: 需要引导到404然后跳转到首页
const isValidArticle = ref(true)
const articleIdInUrl = route.params.articleId as string

// 加载后读取文章内容
onMounted(async () => {
  const requestArticleParams: RequestArticleParams = {
    articleId: articleStore.article.articleId ?? articleIdInUrl,
  }

  data.showBottomBar = true
  data.isLoading = true
  const [error, result] = await to(
    articleStore.loadFullArticle(requestArticleParams),
  )
  if (error) {
    ElMessage.error(error.message)
    await router.replace('/error')
  } else if (result) {
    if (!isEmpty(articleStore.getArticleId)) {
      isValidArticle.value = !(articleStore.article.isDeleted ?? false)

      // 判断是否是自己的文章
      // Todo: 这里需要添加一个高权限override这个值
      isOwnArticle.value =
        articleStore.article?.articleAuthor?.nickname === userStore.nickname

      // 默认分类的文章显示创建时间
      showCreateName.value =
        articleStore.article.categoryName === ArticleCategory.Default

      // 监听下拉行为
      const options = {
        root: articleWrap.value,
        threshold: 0.5, //将阈值设置为 0.5，表示当观察元素的一半进入视图时就触发回调函数
      }
      observer.value = new IntersectionObserver(
        debounce(([entry]: any) => {
          if (entry.isIntersecting && !data.showBottomBar) {
            data.page++
            data.isLoading = false
          }
        }, 500),
        options,
      )
      // 将观察器对象绑定在列表中的最后一个子元素上，以便能够监听它的可见性变化
      observer.value.observe(articleWrap.value.lastElementChild)
    }
  }
})

// TODO 删除
data.articleData.content = `<h1>这样用好ChatGPT，求职之路就像&ldquo;开了挂&rdquo;</h1><p>&nbsp;</p><p>这样用好<em>ChatGPT</em>，</p><p>求职之路就像&ldquo;<strong>开了挂&rdquo;。</strong></p>`

// 关注作者
const handlerFollowing = () => {
  data.userData.isFollowed = !data.userData.isFollowed
}
// 关注、已关注 鼠标悬浮
const followingEnter = () => {
  if (data.userData.isFollowed) {
    data.userData.isFollowHover = true
  }
}
const followingLeave = () => (data.userData.isFollowHover = false)

const getFollowText = computed(() => {
  let text = ''
  if (!data.userData.isFollowed) {
    text = '关注'
  } else {
    text = data.userData.isFollowHover ? '取消关注' : '已关注'
  }

  return text
})

// 喜欢/不喜欢文章
const handlerLikedArticle = () => {
  data.articleData.isLiked = !data.articleData.isLiked
}
const handlerDisLikedArticle = () => {
  data.articleData.isDisLiked = !data.articleData.isDisLiked
}

onBeforeUnmount(async () => {
  try {
    // 停止监听
    observer.value.disconnect()
  } catch (error) {
    await router.replace('/error')
  }
})
</script>

<style lang="scss" scoped>
* {
  margin: 0;
  padding: 0;
}
@mixin wh($w, $h, $url) {
  width: $w;
  height: $h;
  background: url('../assets/' + $url) no-repeat center center/100% 100%;
}
@mixin imgFill {
  width: 100%;
  height: 100%;
}

.article_wrap {
  min-width: 1280px;
  height: 100%;

  & *,
  & *::before,
  & *::after {
    box-sizing: border-box;
  }
}
.article_wrapper {
  margin: 30px auto 0;
  padding: 64px 144px;
  width: 1008px;
  background-color: #fff;
  border: 1px solid rgba($color: #ccc, $alpha: 0.3);

  .author_msg {
    &_con {
      display: flex;
      align-items: center;

      .avatar {
        margin-right: 16px;
        cursor: pointer;
      }
      .right_box {
        text-align: left;
      }
      .name {
        font-size: 16px;
        font-weight: 350;
        line-height: 28px;
        color: rgba(33, 36, 39, 1);
        cursor: pointer;
      }
      .follow {
        display: flex;
        align-items: center;

        &_number {
          font-size: 14px;
          font-weight: 400;
          line-height: 28px;
          color: rgba(151, 151, 151, 1);
        }
        &_setting {
          margin-left: 16px;
          display: flex;
          cursor: pointer;

          i {
            display: block;
            @include wh(24px, 24px, 'icon_add.png');
          }
          span {
            font-size: 14px;
            font-weight: 500;
            line-height: 24px;
            color: rgba(33, 124, 255, 1);
          }
          &.followed {
            i {
              background-image: url('../assets/icon_checked.png');
            }
            span {
              color: rgba(11, 67, 151, 1);
            }
          }
          &.hover {
            i {
              background-image: url('../assets/icon_cancel.png');
            }
            span {
              color: rgba(11, 67, 151, 1);
            }
          }
        }
      }
    }
    &_intro {
      margin-top: 18px;
      font-size: 14px;
      font-weight: 350;
      line-height: 28px;
      color: rgba(33, 36, 39, 1);
    }
  }
  .article_msg {
    margin-top: 32px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    line-height: 60px;
    border-top: 1px solid;
    border-bottom: 1px solid;
    border-color: rgba(236, 236, 236, 1);

    .left_area {
      span {
        font-size: 14px;
        font-weight: 400;
        line-height: 28px;
        color: rgb(115 112 112);

        &:not(:last-child)::after {
          content: '|';
          display: inline-block;
          margin: 0 8px;
          font-size: 14px;
          color: rgba(151, 151, 151, 1);
        }
      }
    }
  }
  .article_detail {
    padding-top: 32px;

    &_title {
      margin: 0;
      text-align: center;
      height: 100px;
      line-height: 100px;
      font-size: 32px;
      font-weight: 500;
      color: rgba(33, 36, 39, 1);
    }

    &_label {
      margin-top: 82px;
      display: flex;

      .label_item {
        height: 36px;
        padding: 4px 16px 4px 16px;
        border-radius: 24px;
        background: rgba(236, 236, 236, 1);
        font-size: 14px;
        font-weight: 400;
        line-height: 28px;
        color: rgba(33, 36, 39, 1);

        & + .label_item {
          margin-left: 16px;
        }
      }
    }
    &_msg {
      margin-top: 48px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      height: 24px;

      .like_area {
        display: flex;

        .like,
        .dislike {
          display: flex;
          align-items: center;

          i {
            display: block;
            width: 24px;
            height: 24px;
            background: no-repeat center center/100% 100%;
            cursor: pointer;
          }
        }
        .like {
          cursor: pointer;

          span {
            margin-left: 8px;
            font-size: 14px;
            color: rgba(33, 36, 39, 1);
          }
          i {
            background-image: url('../assets/icon_like.png');
          }
          &.active i {
            background-image: url('../assets/icon_like__active.png');
          }
        }
        .dislike {
          margin-left: 16px;

          i {
            background-image: url('../assets/icon_dislike.png');
          }
          &.active i {
            background-image: url('../assets/icon_dislike__active.png');
          }
        }
      }
    }
  }
}
.suggested_reading {
  margin: 96px auto 50px;
  width: 1008px;

  &_title {
    font-size: 16px;
    font-weight: 500;
    line-height: 28px;
    color: rgba(33, 36, 39, 1);
  }
  &_con {
    margin-top: 16px;

    .suggested_list {
      display: flex;
      justify-content: space-between;
    }
    .suggested_item {
      position: relative;
      width: 315px;
      height: 404px;
      border-radius: 8px;
      border: 1px solid rgba(236, 236, 236, 1);
      background: #fff;

      &:hover {
        transform: scale(1.02);
        box-shadow: 0px 0px 8px 0px rgba(198, 198, 198, 1);
        transition: transform 0.5s linear;
      }

      .poster {
        width: 315px;
        height: 188px;
        border-radius: 8px 8px 0px 0px;

        img {
          @include imgFill();
        }
      }

      &.not_poster {
        .article_msg {
          margin: 24px 0;
        }
        .article_msg_desc {
          -webkit-line-clamp: 8;
        }
      }
    }
  }
  .reading_msg {
    padding: 16px;

    .author {
      display: flex;
      align-items: center;
      justify-content: space-between;

      &_msg {
        display: flex;

        .avatar {
          width: 24px;
          height: 24px;

          img {
            @include imgFill();
          }
        }
        .name {
          margin-left: 8px;
          font-size: 14px;
          font-weight: 400;
          line-height: 28px;
          color: rgba(33, 36, 39, 1);
        }
      }
      .article_data {
        span {
          font-size: 14px;
          font-weight: 400;
          line-height: 28px;
          color: rgb(115 112 112);

          &:not(:last-child)::after {
            content: '|';
            display: inline-block;
            margin: 0 8px;
            font-size: 14px;
            color: rgba(151, 151, 151, 1);
          }
        }
      }
    }
    .article_msg {
      margin: 16px 0;

      &_title {
        width: 100%;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        font-size: 20px;
        font-weight: 700;
        line-height: 32px;
        color: rgba(33, 36, 39, 1);
      }
      &_desc {
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;
        overflow: hidden;
        text-overflow: ellipsis;
        margin-top: 8px;
        font-size: 16px;
        font-weight: 350;
        line-height: 28px;
        color: rgba(33, 36, 39, 1);
      }
    }
  }
  .reading_setting {
    position: absolute;
    bottom: 16px;
    left: 16px;
    right: 16px;
    margin: auto;
    display: flex;
    justify-content: space-between;
    align-items: center;

    .left_area {
      span {
        font-size: 14px;
        font-weight: 400;
        line-height: 28px;
        color: rgba(33, 36, 39, 1);

        & + span {
          margin-left: 8px;
        }
      }
    }
  }
}
.loading_tips {
  margin: 16px 0;
  padding: 0 8px;
  text-align: center;

  p {
    font-size: 16px;
    font-weight: 350;
    line-height: 28px;
    color: rgba(33, 36, 39, 1);
  }
  :deep(.dot) {
    display: inline-block;
    text-align: center;
    margin: 0 auto;
    overflow: hidden;
    height: 1em;
    line-height: 1em;
    vertical-align: -0.25em;
  }
  :deep(.dot::before) {
    display: block;
    content: '...\A..\A.';
    white-space: pre-wrap;
    animation: dot 2s infinite step-start both;
  }
  @keyframes dot {
    33% {
      transform: translateY(-2em);
    }
    66% {
      transform: translateY(-1em);
    }
  }
}
.addcollects_popup {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(151, 151, 151, 0.2);
}
</style>
