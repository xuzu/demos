<template>
  <el-dialog v-model="dialogVisible" class="profile-editor-dialog">
    <div class="dialog-container">
      <div class="side-bar-div">
        <div class="side-bar-title-div">编辑个人页</div>
        <el-menu class="side-bar-menu" :default-active="activeIndex">
          <el-menu-item index="0" @click="activeIndex = '0'">
            <Icon icon="mdi:information" class="information-icon" />
            基本信息
          </el-menu-item>
          <el-menu-item index="1" @click="activeIndex = '1'">
            <Icon icon="material-symbols:account-circle" class="user-icon" />
            详细资料
          </el-menu-item>
          <el-menu-item index="2" @click="activeIndex = '2'">
            <Icon icon="ic:baseline-visibility" class="visibility-icon" />
            可见性
          </el-menu-item>
        </el-menu>
      </div>
      <div class="contents-div">
        <div class="closeDialog">
          <Icon icon="maki:cross" class="close-dialog-icon" @click="close" />
        </div>
        <component :is="components[Number(activeIndex)]"></component>
      </div>
    </div>
  </el-dialog>
</template>

<script lang="ts" setup>
import { ref, defineProps } from 'vue'
import { Icon } from '@iconify/vue'
import EditBasicInformationDialogContent from '@/components/profile/editProfile/EditBasicInformationDialogContent.vue'
import EditDetailedInformationDialogContent from '@/components/profile/editProfile/EditDetailedInformationDialogContent.vue'
import EditVisibilityDialogContent from '@/components/profile/editProfile/EditVisibilityDialogContent.vue'

const dialogVisible = ref(true)
const close = () => {
  dialogVisible.value = false
}

/**
 * 控制menu item激活时高亮
 */
const props = defineProps({
  activeIndexProps: {
    type: String,
  },
})
const activeIndex = ref(props.activeIndexProps)

/**
 * 控制组件加载
 */
const components = [
  EditBasicInformationDialogContent,
  EditDetailedInformationDialogContent,
  EditVisibilityDialogContent,
]
</script>

<style lang="scss" scoped>
.dialog-container {
  display: flex;
  width: 700px;
  height: 680px;

  .side-bar-div {
    font-family: $text-font-family;
    font-style: normal;
    font-weight: 500;
    line-height: 28px;
    width: 195px;
    height: 680px;
    background-color: $blue-900;
    border-radius: 10px 0px 0px 10px;
    .side-bar-title-div {
      font-size: 18px;
      color: white;
      margin: 26px 28px;
    }
    .side-bar-menu {
      margin: 18px;
      background-color: $blue-900;
      border-right: none;

      .el-menu-item {
        font-size: 16px;
        color: white;
        width: 159px;
        height: 54px;
        border-radius: 5px;
        margin-bottom: 12px;

        &:hover,
        &.is-active {
          color: $blue-900;
          background-color: $blue-100;
        }
      }
    }
  }

  .contents-div {
    width: 505px;
    padding-left: 31px;
    padding-top: 27px;
    margin-bottom: 10px;
    overflow: auto;
    // 隐藏scroll bar (Chrome in Windows)
    &::-webkit-scrollbar {
      width: 0px;
    }
  }
}

.information-icon {
  width: 22px;
  height: 22px;
  padding-right: 14px;
}

.user-icon {
  width: 22px;
  height: 22px;
  padding-right: 14px;
}

.visibility-icon {
  width: 24px;
  height: 24px;
  padding-right: 12px;
}

.close-dialog-icon {
  position: absolute;
  width: 24px;
  height: 24px;
  left: 668px;
  top: 8px;
  color: $text-color-disabled;
}
</style>

<style lang="scss">
.profile-editor-dialog {
  width: 700px;
  height: 680px;
  box-shadow: 4px 4px 4px rgba(0, 0, 0, 0.25);
  border-radius: 10px;

  .el-dialog__header {
    display: none;
  }

  .el-dialog__body {
    padding: 0px;
  }
}
</style>
