<template>
  <div class="home">
    <el-row justify="center" class="contact-us-row">
      <el-col :md="16" :sm="20">
        <contact-us-view></contact-us-view>
      </el-col>
    </el-row>
  </div>
</template>

<script lang="ts" setup>
import ContactUsView from '@/views/ContactUsView.vue' // @ is an alias to /src
</script>

<style scoped>
.home {
  background-image: linear-gradient(white, lightgoldenrodyellow);
}

img {
  height: 200px;
}

.contact-us-row {
  /*background-image: linear-gradient(lightgreen, aliceblue);*/
}
</style>
