<template>
  <div class="container">
    <EditorTitleInput />
    <div class="editor_box">
      <TinymceEditor
        ref="refTinymce"
        :value="editorData.content"
        placeholder="请输入正文（不少于20个字）"
        :parentMethod="getEditorContent"
      ></TinymceEditor>
    </div>
    <div class="setting_box" id="setting_box">
      <h4 class="title">文章设置</h4>
      <div class="setting_con">
        <p>封面和摘要</p>
        <el-row>
          <el-col :span="8">
            <div class="upload_box">
              <UploadImage
                @updateCover="handleUpdateCover"
                :imgUrl="editorData.articleCoverImageLink"
              />
            </div>
          </el-col>
          <el-col :span="2"></el-col>
          <el-col :span="13">
            <EditorSummary />
          </el-col>
        </el-row>

        <div class="label_con">
          <p>添加标签</p>
          <div class="add_label">
            <el-input
              v-model="editorData.label"
              placeholder="请输入文章标签，至多可以添加五个"
              class="label_inp"
              type="text"
            />
            <div
              class="icon_return"
              @click="addTag({ title: editorData.label, type: 'isDefault' })"
            ></div>
          </div>
          <ul class="label_list">
            <li v-for="(tag, index) in editorData.addTagArray" :key="index">
              <span class="label">{{ tag.title }}</span>
              <span class="icon_add" @click="removeCurrentTag(index)">-</span>
            </li>
          </ul>
          <div class="hot_lable">
            <p>相关热门标签</p>
            <ul class="label_list">
              <li v-for="(tag, index) in editorData.hotTagArray" :key="index">
                <span class="label">{{ tag.title }}</span>
                <span
                  class="icon_add"
                  @click="addTag({ title: tag.title, type: 'isHot' })"
                  >+</span
                >
              </li>
            </ul>
          </div>
        </div>

        <el-row class="bottom_box">
          <el-col :span="11">
            <SelectBox
              title="文章分类"
              :options="CATEGORY_NAME_LIST"
              placeholder="请选择文章分类"
              v-model="editorData.categoryName"
            />
          </el-col>
          <el-col :span="1"></el-col>
          <el-col :span="11">
            <SelectBox
              title="可见性设置"
              :options="VISIBILITY_LIST"
              placeholder="请选择可见性设置"
              v-model="editorData.visibilityId"
            />
          </el-col>
        </el-row>
      </div>
    </div>
    <div class="fixed_bottombox">
      <div class="messages">
        <span
          class="m1"
          :class="{ rotate: editorData.isBottom }"
          @click="handlerView"
        >
          {{ editorData.isBottom ? '回到顶端' : '文章设置' }}</span
        >
        <span class="m2">正文字数：{{ editorData.wordCount }}</span>
      </div>
      <div class="btn_groups">
        <el-button type="default" class="btn btn_default" @click="handlePreview"
          >预览</el-button
        >
        <el-button
          :disabled="loading"
          type="primary"
          class="btn"
          @click="handlePublish"
          >发布</el-button
        >
      </div>
    </div>
  </div>
  <el-dialog v-model="dialogVisible">
    <img w-full :src="dialogImageUrl" alt="Preview Image" />
  </el-dialog>
</template>

<script lang="ts" setup>
import { onBeforeMount, onBeforeUnmount, ref } from 'vue'
import { useRouter } from 'vue-router'
import { useEditorStore } from '@/store/editor'
import TinymceEditor from '@/components/TinymceEditor.vue'
import { useArticleStore } from '@/store/article'
import {
  ElButton,
  ElCol,
  ElDialog,
  ElInput,
  ElMessage,
  ElRow,
} from 'element-plus'
import UploadImage from '@/components/UploadImage.vue'
import { storeToRefs } from 'pinia'
import { ArticleTag } from '@/store/article/types'
import {
  CATEGORY_NAME_LIST,
  VISIBILITY_LIST,
} from '@/constant/editor/editorTextConstant'
import EditorTitleInput from '@/components/EditorTitleInput.vue'
import EditorSummary from '@/components/EditorSummary.vue'
import SelectBox from '@/components/SelectBox.vue'
const loading = ref(false)
const editorStore = useEditorStore()
const articleStore = useArticleStore()
const router = useRouter()

const { editorData } = storeToRefs(editorStore)

// 编辑器
const refTinymce = ref()

const getEditorContent = (value: string) => {
  //从插件模版中获取内容长度
  editorData.value.wordCount = refTinymce.value?.getWordCountInEditor() ?? 0
}

// 上传图片
const dialogImageUrl = ref('')
const dialogVisible = ref(false)
const disabled = ref(false)

// 更新封面
const handleUpdateCover = (imgUrl: string) => {
  editorData.value.articleCoverImageLink = imgUrl
}

// 监听滚动条
const handleScroll = () => {
  const scrollTop = document.documentElement.scrollTop //滚动高度
  editorData.value.isBottom = scrollTop >= 600
}

// 跳转
const handlerView = () => {
  if (editorData.value.isBottom) {
    // 回到顶部
    document.documentElement.scrollTop = 0
  } else {
    // 文章设置
    document.getElementById('setting_box')?.scrollIntoView()
  }
}

// 添加标签
const addTag = ({ title, type }: ArticleTag) => {
  if ((editorData.value.addTagArray?.length ?? 0) >= 5) {
    ElMessage.error('最多只能添加5个标签！')
    return false
  }

  // 从热门标签添加
  if (type === 'isHot') {
    editorData.value.addTagArray?.push({
      title: title,
      type: type,
    })
    return false
  }
  // 从输入框添加
  if (editorData.value.label) {
    editorData.value.addTagArray?.push({
      title: editorData.value.label,
      type: 'isDefault',
    })
    editorData.value.label = ''
  }
}

// 删除标签
const removeCurrentTag = (index: number) => {
  if (index >= 0 && index < (editorData.value.addTagArray?.length ?? 0)) {
    editorData.value.addTagArray?.splice(index, 1)[0] // splice返回的是一个数组，[0]得到被删除的元素
  }
}

onBeforeMount(() => {
  //初始化判断是否在编辑已有的文章
  if (
    articleStore.article.isBeingEdited &&
    articleStore.article.articleId === editorData.value.articleId
  ) {
    const article = articleStore.article
    editorStore.loadFromArticle(article)
  } else {
    // 否则清空从头开始
    editorStore.$reset()
  }
  window.addEventListener('scroll', handleScroll, true)
})

onBeforeUnmount(() => {
  window.removeEventListener('scroll', handleScroll, true)
})

// 预览
const handlePreview = () => {
  refTinymce.value?.preview()
}

/**
 * 发布或更新一篇文章
 */
const handlePublish = async () => {
  editorData.value.content = refTinymce.value.getContent()

  // 操作按钮禁用
  loading.value = true
  await editorStore.uploadNewArticle()
  loading.value = false

  // 设置一个定时器，让用户有足够的时间看到消息
  setTimeout(async () => {
    await router.replace({
      path: '/',
    })
  }, 2000) // 2 秒后跳转
}
</script>

<style lang="scss" scoped>
::v-deep .is-disabled.el-button {
  background-color: $blue-disabled;
}

.center-text {
  text-align: center;
}

.container {
  min-height: 1600px;
  background-color: #fafafa;
}

.editor_box {
  margin-top: 24px;
  height: 712px;

  :deep(.tox-tinymce) {
    height: 100% !important;
    border-radius: 0 !important;
  }
  :deep(.tox .tox-edit-area__iframe) {
    background-color: $background-white !important;
  }
  :deep(.tox .tox-statusbar) {
    display: none;
  }
}
.setting_box {
  margin-top: 24px;
  padding: 14px 16px 100px;
  box-sizing: border-box;
  text-align: left;
  background: #fff;

  .el-input__inner {
    height: 100%;
    background: none;
  }
  :deep(.el-select .el-input__inner) {
    background: none;
  }

  .title {
    font-family: $text-font-family;
    font-style: normal;
    font-weight: 500;
    font-size: 16px;
    line-height: 28px;
    color: #212427;
  }
}
.setting_con {
  width: 90%;
  margin-top: 24px;
  margin-left: 60px;
  font-family: $text-font-family;
  font-style: normal;
  font-weight: 350;
  font-size: 16px;
  line-height: 28px;
  color: #212427;

  .upload_box {
    height: 100%;

    & > div {
      display: flex;
      height: 100%;
    }

    :deep(.el-upload-list__item.is-ready + .el-upload--picture-card) {
      display: none !important;
    }

    :deep(.el-upload-list),
    :deep(.el-upload--picture-card) {
      display: flex;
      justify-content: center;
      width: 100%;
      height: 120px;
      padding: 0;
      margin: 0;
    }

    :deep(.el-upload-list__item) {
      display: flex;
      justify-content: center;
      height: 100%;
      width: 100%;
      margin-right: 0;
    }

    :deep(input[type='file']) {
      display: none;
    }
  }

  .upload-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }

  .upload-text {
    text-align: center;
    font-family: $text-font-family;
    font-style: normal;
    font-size: 14px;
    line-height: 28px;
    color: #979797;
  }
}
.label_con {
  padding-top: 24px;
  padding-bottom: 32px;
  border-bottom: 1px solid #ececec;

  .add_label {
    margin-top: 22px;
    margin-bottom: 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 312px;
    border-bottom: 1px solid #979797;
  }
  .label_inp {
    width: 280px;
    height: 28px;

    .el-input__wrapper {
      padding: 0;
    }
    :deep(.el-input__inner) {
      background: none;
      padding: 0;
    }
    :deep(.el-input__wrapper) {
      padding: 1px 0;
      box-shadow: none !important;
    }
    :deep(.el-input__wrapper:hover),
    :deep(.el-input__wrapper.is-focus) {
      box-shadow: none !important;
    }
  }
  .icon_return {
    width: 18px;
    height: 14px;
    background: url('../assets/icon_return.png') no-repeat center center/100%
      100%;
  }
  .hot_lable {
    & > p {
      width: fit-content;

      &::after {
        content: '';
        margin-left: 5px;
        display: inline-block;
        width: 13px;
        height: 13px;
        background: url('../assets/icon_tan.png') no-repeat center center/100%
          100%;
      }
    }
  }
  ul {
    margin-block-start: 0;
    padding-inline-start: 0;
  }
  .label_list {
    width: 85%;
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(136px, 1fr));
    gap: 20px;

    li {
      display: flex;
      align-items: center;
      margin-right: 34px;
      width: 136px;
      height: 32px;
      background: #ececec;
      border-radius: 16px;

      span {
        font-family: $text-font-family;
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        color: #212427;
      }

      .label {
        width: 100px;
        text-align: center;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .icon_add {
        margin-left: 12px;
        cursor: pointer;
        font-weight: 700;
        font-size: 20px;
        color: #212427;
      }
    }
  }
}

.bottom_box {
  padding-top: 24px;
}

.fixed_bottombox {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  margin: auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 800px;
  height: 56px;
  padding: 0 64px 0 22px;
  box-sizing: border-box;
  background: #fff;

  .m1 {
    cursor: pointer;

    &::before {
      content: '';
      display: inline-block;
      margin-right: 14px;
      vertical-align: middle;
      width: 12px;
      height: 7px;
      background: url('../assets/icon_drow2.png') no-repeat center center/100%
        100%;
      transition: all 0.2s linear;
    }
    &.rotate::before {
      transform: rotate(180deg);
    }
  }
  .m2 {
    margin-left: 32px;
  }
  .btn_groups {
    .btn + .btn {
      margin-left: 54px;
    }
    .btn_default {
      color: #212427;
      border-color: #212427;
    }
  }
}

//提示信息样式
.error-text {
  color: red;
  font-size: 14px;
  margin-top: 5px;
}
</style>
