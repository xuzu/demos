/**
 * 跳转登录
 */
import { AxiosResponse } from 'axios'
import { ElMessage } from 'element-plus'

//page loading util部分开始
import { createApp, reactive } from 'vue'
import pageLoading from '@/components/PageLoading.vue'
import { LOADING } from '@/constant/loadingConstant'
import { useUserStore } from '@/store/user'
import { usePermissionStore } from '@/store/permission'
import { useUserInformationStore } from '@/store/userInformation'
import { useProfileStore } from '@/store/profile'

const msg = reactive({
  show: false,
  title: LOADING,
})

const $loading = createApp(pageLoading, { msg }).mount(
  document.createElement('div'),
)
export const load = {
  // 控制显示loading的方法
  show(title: any = LOADING) {
    msg.show = true
    msg.title = title
    document.body.appendChild($loading.$el)
  },

  // 控制loading隐藏的方法
  hide() {
    msg.show = false
  },
}
//page loading util部分结束

/**
 * 用户logout
 */
export const logout = () => {
  const userStore = useUserStore()
  const permissionStore = usePermissionStore()
  const userInformationStore = useUserInformationStore()
  const profileStore = useProfileStore()

  userStore.$reset()
  permissionStore.$reset()
  userInformationStore.$reset()
  profileStore.$reset()
}

export const jumpLogin = () => {
  // todo: 实现跳转到登录的功能，可能是鉴权失败后跳过去
  return 1
}

/**
 * 下载文件
 * @param response 请求返回的结果
 */
export const downloadFile = (response: AxiosResponse) => {
  console.log('response.data.type:', response.data.type)
  return new Promise((resolve, reject) => {
    const fileReader = new FileReader()
    fileReader.onload = function () {
      try {
        console.log('result: ', this.result)
        const jsonData = JSON.parse((this as any).result) // 成功，说明是普通对象数据
        if (jsonData?.code !== 200) {
          ElMessage.error(jsonData?.message ?? 'request failed')
          reject(jsonData)
        }
      } catch (e) {
        // 解析成对象失败，说明是正常的文件流
        const blob = new Blob([response.data])
        // 本地保存文件
        const url = window.URL.createObjectURL(blob)
        const link = document.createElement('a')
        link.href = url
        const fileName = response?.headers?.['content-disposition']
          ?.split('fileName*=')?.[1]
          ?.substring(7)
        link.setAttribute('download', decodeURI(fileName))
        document.body.appendChild(link)
        link.click()
        resolve(response.data)
      }
    }
    fileReader.readAsText(response.data)
  })
}
