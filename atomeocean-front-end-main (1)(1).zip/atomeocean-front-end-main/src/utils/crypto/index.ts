import CryptoJS from 'crypto-js'

//对Blob文件进行MD5加密
export function encryptMD5(file: Blob) {
  return new Promise<string>((resolve, reject) => {
    const fileReader = new FileReader()

    //添加文件加载监听事件
    fileReader.onload = (e: ProgressEvent<FileReader>) => {
      //将文件读取到ArrayBuffer中
      const arrayBuffer = e.target?.result as ArrayBuffer
      //将ArrayBuffer转换为number[]
      //NOTE: CryptoJS.lib.WordArray.create方法需要传入类型为number[]的参数
      const uint8Array = new Uint8Array(arrayBuffer)
      const byteArray = Array.from(uint8Array)
      const wordArray = CryptoJS.lib.WordArray.create(byteArray)
      //对文件进行MD5加密
      const md5Hash = CryptoJS.MD5(wordArray).toString()
      resolve(md5Hash)
    }

    //添加文件读取异常监听事件
    fileReader.onerror = () => {
      reject('文件加载失败')
    }

    fileReader.readAsArrayBuffer(file)
  })
}
