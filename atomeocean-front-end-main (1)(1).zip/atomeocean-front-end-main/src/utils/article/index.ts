/**
 * 和文章相关的util
 */

/**
 * 返回文章开头一段内容，默认为前100个字
 */
export function getCollapsedContent(content: string | undefined) {
  const regExp = /<[^>]+>/g
  // 清除文本中所有html标签
  const collapsedContent = content?.replace(regExp, '')
  return collapsedContent?.substring(0, 100).trim()
}

/**
 * 根据词数统计计算阅读时长
 * @param wordCount
 */
export function calculateReadMinutes(wordCount: number) {
  return Math.ceil(wordCount / 200)
}
