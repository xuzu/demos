/**
 * 和个人页相关的util
 */

import { CareerExperience, EducationExperience } from '@/store/profile/types'
import dayjs from 'dayjs'

/**
 * 排序用户的经历
 */
export const sortExperience = (
  experienceArray: CareerExperience[] | EducationExperience[],
) => {
  if (!experienceArray || experienceArray.length === 1) {
    return
  }
  experienceArray.sort((exp1, exp2) => {
    // 两个经历已结束
    if (exp1.isCompleted && exp2.isCompleted) {
      return dayjs(exp2.endDate).diff(exp1.endDate)
    }
    // 两个经历都没结束
    else if (!exp1.isCompleted && !exp2.isCompleted) {
      return dayjs(exp2.startDate).diff(exp1.startDate)
    }
    // 其中一个经历结束了
    return exp1.isCompleted ? 1 : -1
  })
}
