import router from '@/router'

/**
 * 跳转到Profile页面
 * 参数userId为压缩过的短id
 */
export const navigateToProfile = async (userId: string | undefined) => {
  await router.push({
    name: 'profile',
    params: { userId: userId },
  })
}
