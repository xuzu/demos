/**
 * 判断输入的值是否为empty、null、undefined的一种
 * @param value
 */
export function isEmpty(value: any) {
  return (
    value == null ||
    typeof value === 'undefined' ||
    (typeof value === 'string' && value.trim().length === 0)
  )
}

// 转换数字
export const formatNumber = (val: number) => {
  const num = 10000
  let sizesValue = ''
  /**
   * 判断取哪个单位
   */
  if (val < 1000) {
    // 如果小于1000则直接返回
    sizesValue = ''
    return val
  } else if (val > 1000 && val < 9999) {
    sizesValue = '千'
  } else if (val > 10000 && val < 99999999) {
    sizesValue = '万'
  } else if (val > 100000000) {
    sizesValue = '亿'
  }
  /**
   * 大于一万则运行下方计算
   */
  const i = Math.floor(Math.log(val) / Math.log(num))
  let sizes = (val / Math.pow(num, i)).toFixed(0)
  sizes = sizes + sizesValue
  return sizes
}
