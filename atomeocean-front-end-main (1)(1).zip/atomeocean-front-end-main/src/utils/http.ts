// 封装axios
import axios, { AxiosInstance, AxiosRequestConfig } from 'axios'
import { usePermissionStore } from '@/store/permission'
import { useRecaptchaStore } from '@/store/recaptcha'
import router from '@/router'
import { ElMessage } from 'element-plus'
import { TOKEN_EXPIRED } from '@/constant/LoginMessageConstant'

// 配置全局loading
// let requestNum = 0;
// let loadingInstance = ElLoading.service()

// const addLoading = () => {
//     // 先增加请求数，如果数量为1就弹出loading，防止重复弹出
//     requestNum ++;
//     if (requestNum == 1) {
//         loadingInstance = ElLoading.service({
//             text: "正在努力加载中....",
//             background:"rgba(0,0,0,0)",
//         });
//     }
// };

// const cancelLoading = () => {
//     // 在请求数为0的时候取消loading
//     requestNum --;
//     if (requestNum === 0) loadingInstance?.close();
// }
// 全局loading配置结束

/**
 * 对外暴露这个函数，创建一个axios实例
 * @param config axios的配置
 */
export const createAxiosByInterceptors = (
  config?: AxiosRequestConfig,
): AxiosInstance => {
  const instance = axios.create({
    timeout: 1000 * 60, //超时配置1分钟
    withCredentials: true, // 跨域携带cookie
    ...config, // 自定义配置覆盖基本配置
  })

  // 添加请求拦截器
  instance.interceptors.request.use(
    function (config) {
      // 发送之前全局修改config，添加token
      const permissionStore = usePermissionStore()
      const token = permissionStore.getToken
      if (token) {
        config.headers = {
          ...config.headers,
          Authorization: token,
        }
      }
      //发送前检查是否有recaptcha token需要发送
      const recaptchaStore = useRecaptchaStore()
      const recaptchaToken = recaptchaStore.getRecaptchaToken
      if (recaptchaToken) {
        config.headers = {
          ...config.headers,
          Recaptcha: recaptchaToken,
        }
      }
      return config
    },
    function (error) {
      // 请求错误
      return Promise.reject(error)
    },
  )

  // 添加响应拦截器
  instance.interceptors.response.use(
    function (response) {
      //如果注册信息过期，为用户logout
      if (response.data?.status === 1007) {
        ElMessage.error(TOKEN_EXPIRED)
        //将token标记为过期
        const permissionStore = usePermissionStore()
        permissionStore.setExpired(true)
        //跳转到homepage
        router.replace('/')
        //防止请求组件后续代码继续执行
        return
      }
      // 返回后端传递的ResultData
      return response.data
    },
    function (error) {
      //控制台打印error的message以及request和response信息
      console.log(error)
      if (error.request) {
        console.log(error.request)
      }
      if (error.response) {
        console.log(error.response)
      }

      //若该请求有响应体，则根据http status来自定义错误信息，否则重置错误信息
      if (error?.response) {
        switch (error.response.status) {
          case 400:
            error.message = '请求错误(400)'
            break
          case 401:
            error.message = '未授权，请重新登录(401)'
            break
          case 403:
            error.message = '拒绝访问(403)'
            break
          case 404:
            error.message = '请求出错(404)'
            break
          case 408:
            error.message = '请求超时(408)'
            break
          case 500:
            error.message = '服务器错误(500)'
            break
          case 501:
            error.message = '服务未实现(501)'
            break
          case 502:
            error.message = '网络错误(502)'
            break
          case 503:
            error.message = '服务不可用(503)'
            break
          case 504:
            error.message = '网络超时(504)'
            break
          case 505:
            error.message = 'HTTP版本不受支持(505)'
            break
          default:
            error.message = `连接出错(${error.response.status})`
        }
      } else {
        error.message = '连接服务器失败'
      }

      return Promise.reject(error)
    },
  )

  return instance
}
