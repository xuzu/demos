import dayjs from 'dayjs'
import 'dayjs/locale/zh-cn'
import { App } from 'vue'
import customParseFormat from 'dayjs/plugin/customParseFormat'

/**
 * 全局安装dayjs
 */

// 自定义时间格式
dayjs.extend(customParseFormat)
// dayjs.locale("zh-cn");

const DATE_PARSE_FORMAT = 'YYYY-MM-DD'
const DATE_DISPLAY_FORMAT = 'MMM DD YYYY'
const DATE_SAME_YEAR_DISPLAY_FORMAT = 'MMM DD'

/**
 * 将utc字符串转换为可读的日期
 * @param dateString 原始utc格式string
 * @param format 格式
 */
export function formatDateString(
  dateString: string | undefined,
  format: string = DATE_PARSE_FORMAT,
) {
  if (dateString && dayjs(dateString, format).isValid()) {
    const parsedDate = dayjs(dateString, format)

    let resultDate = parsedDate.format(DATE_DISPLAY_FORMAT)
    // 一年内文章不显示年份
    if (parsedDate.isAfter(dayjs().subtract(1, 'year'))) {
      resultDate = parsedDate.format(DATE_SAME_YEAR_DISPLAY_FORMAT)
    }
    return resultDate
  } else {
    // 对于非法时间格式，返回空字符串
    return ''
  }
}

declare module '@vue/runtime-core' {
  interface ComponentCustomProperties {
    $dayjs: any
  }
}

export default {
  install: (app: App<Element>): void => {
    app.config.globalProperties.$dayjs = dayjs
  },
}
