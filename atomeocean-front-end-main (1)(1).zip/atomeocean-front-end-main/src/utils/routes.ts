import { DynamicRouteResponse } from '@/api/user/model'

/**
 * 将返回的json数组转换成vue-router可以识别的数据
 * 返回格式为 RouteData[]
 */
export function arrayToRoutes(
  dynamicRoutes: DynamicRouteResponse[],
): RouteData[] {
  const vueRouterDynamicRoutes = []

  // 根据名字来寻找相应的动态路由
  for (const dynamicRoute of dynamicRoutes) {
    const routeName = dynamicRoute.name

    const route = dynamicRouteArray.find((routeItem) => {
      return routeItem.name == routeName
    })
    if (route) {
      vueRouterDynamicRoutes.push(route)
    }
  }

  return vueRouterDynamicRoutes
}

// 需要在前端保存的动态路由
export const dynamicRouteArray: Array<RouteData> = [
  {
    path: '/about',
    name: 'about',
    component: 'AboutUsView',
  },
  {
    path: '/articles/:id',
    component: 'ArticleView',
  },
  {
    path: '/editor',
    name: 'editor',
    component: 'PublishView',
  },
  {
    path: '/tasks',
    name: 'tasks',
    component: 'TasksView',
  },
]

export interface RouteData {
  path: string
  name?: string
  component: string
  redirect?: string
  alias?: string
}
