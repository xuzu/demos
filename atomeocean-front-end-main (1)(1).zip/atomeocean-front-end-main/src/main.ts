import dayjs from './utils/dayjs'
import { createApp } from 'vue'
import mdiVue from 'mdi-vue/v3'
import * as mdijs from '@mdi/js'
import App from './App.vue'
import router from './router'
import './router/permission'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from "element-plus"
import 'element-plus/theme-chalk/el-message.css'
import 'element-plus/theme-chalk/el-message-box.css'
import 'element-plus/theme-chalk/el-upload.css'
import 'element-plus/theme-chalk/el-select.css'
import 'element-plus/theme-chalk/el-option.css'
import VueGtag from "vue-gtag";
import { createPinia } from "pinia";
import piniaPluginPersistedstate from 'pinia-plugin-persistedstate';
import ScriptX from 'vue-scriptx';
import { VueReCaptcha } from 'vue-recaptcha-v3';

// 全局配置
const pinia = createPinia()
const app = createApp(App)
pinia.use(piniaPluginPersistedstate)
app.use(pinia)
app.use(ScriptX)

// dayjs日期库
app.use(dayjs)

app.use(router)


app.use(VueGtag, {
  config: {
    id: process.env.VUE_APP_VUEGTAG_ID as string
  }
})
app.use(mdiVue, {
  icons: mdijs
})

// 引入message和message box组件
app.config.globalProperties.$ELEMENT = {}
app.use(ElMessage)
app.use(ElMessageBox)

//引入recaptcha
app.use(VueReCaptcha, {
  siteKey: process.env.VUE_APP_RECAPTCHA_CLIENT_KEY || "",
  loaderOptions: {
    autoHideBadge: true
  }
})


// 引入element plus icons
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component)
}
app.mount('#app')
