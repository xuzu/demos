<template>
  <div class="hello">
    <div class="title-row-div">
      <h1>{{ title }}</h1>
    </div>
    <div class="subtitle-div">
      <h3>{{ subtitle }}</h3>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'HelloWorld',
  props: {
    title: String,
    subtitle: String,
  },
})
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  /*margin: 40px 0 0;*/
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
