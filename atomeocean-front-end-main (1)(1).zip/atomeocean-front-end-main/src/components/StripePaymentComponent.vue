<template>
  <div>
    金额：
    <el-input-number v-model="amount" :precision="2" :step="0.5" />
  </div>
  <div class="billing-form">
    <div class="row">
      <label for="name">名字</label>
      <input id="name" v-model="billingAddress.name" required />
    </div>

    <div class="row">
      <label for="address_line1">地址</label>
      <input
        id="address_line1"
        v-model="billingAddress.address_line1"
        required
      />
    </div>

    <div class="row" id="three-in-row">
      <div class="row">
        <label for="address_city">城市</label>
        <input
          id="address_city"
          v-model="billingAddress.address_city"
          required
        />
      </div>
      <div class="row">
        <label for="address_state">州</label>
        <input
          id="address_state"
          v-model="billingAddress.address_state"
          required
        />
      </div>
      <div class="row">
        <label for="address_zip">邮政编码</label>
        <input id="address_zip" v-model="billingAddress.address_zip" required />
      </div>
    </div>

    <div class="row">
      <label>卡号</label>
      <div id="card-number"></div>
    </div>

    <div class="row" id="two-in-row">
      <div class="row">
        <label class="cvc-text">
          <span>安全码</span>
          <span>(cvc)</span>
        </label>
        <div id="card-cvc"></div>
      </div>

      <div class="row">
        <label>有效期</label>
        <div id="card-expiry"></div>
      </div>
    </div>

    <div v-if="stripeValidationError" class="validation-error">
      {{ stripeValidationError }}
    </div>

    <div class="button">
      <el-button class="pay-button" @click="pay">Pay</el-button>
    </div>

    <div class="stripe-container">
      <a href="https://www.stripe.com" target="_blank">
        <img
          class="stripe-logo"
          src="../assets/Stripe_blurple.svg"
          alt="Stripe-logo"
        />
      </a>
    </div>
  </div>
</template>

<script setup lang="ts">
import {
  CreateTokenCardData,
  Stripe,
  StripeCardCvcElement,
  StripeCardExpiryElement,
  StripeCardNumberElement,
  StripeElementChangeEvent,
  TokenResult,
  loadStripe,
} from '@stripe/stripe-js'
import { ref, onBeforeMount } from 'vue'
import userApi from '@/api/user'
import to from 'await-to-js'
import { StripePaymentParam } from '@/api/user/model'
import { AxiosError } from 'axios'
import { ElMessage } from 'element-plus'

const stripeKey = ref(process.env.VUE_APP_STRIPE_PUBLISHABLE_KEY)
let stripe: Stripe | null
let cardNumberElement: StripeCardNumberElement | undefined
let cardCvcElement: StripeCardCvcElement | undefined
let cardExpiryElement: StripeCardExpiryElement | undefined

const style = {
  base: {
    fontFamily: 'Arial, sans-serif',
    color: '#000',
    fontSize: '18px',
  },
}

onBeforeMount(async () => {
  stripe = await loadStripe(stripeKey.value ?? '')
  const elements = stripe?.elements()

  cardNumberElement = elements?.create('cardNumber', {
    style: style,
    showIcon: true,
    placeholder: '',
  })
  cardNumberElement?.mount('#card-number')

  cardCvcElement = elements?.create('cardCvc', {
    style: style,
    placeholder: '',
  })
  cardCvcElement?.mount('#card-cvc')

  cardExpiryElement = elements?.create('cardExpiry', {
    style: style,
  })
  cardExpiryElement?.mount('#card-expiry')

  cardNumberElement?.on('change', setValidationError)
  cardExpiryElement?.on('change', setValidationError)
  cardCvcElement?.on('change', setValidationError)
})

const stripeValidationError = ref('')
const setValidationError = (event: StripeElementChangeEvent) => {
  stripeValidationError.value = event.error ? event.error.message : ''
}

const billingAddress = ref<CreateTokenCardData>({
  name: '',
  address_line1: '',
  address_city: '',
  address_state: '',
  address_zip: '',
})

const amount = ref()
const pay = () => {
  if (!cardNumberElement) {
    return
  }
  // Access instance methods, e.g. createToken()
  stripe
    ?.createToken(cardNumberElement, billingAddress.value)
    .then(async (result: TokenResult) => {
      // Handle result.error or result.token
      if (result.error) {
        console.log(result.error)
        ElMessage.error(result.error.message)
      } else if (result.token) {
        console.log(result.token.id)
        const stripePaymentParam: StripePaymentParam = {
          amount: amount.value * 100,
          stripeToken: result.token?.id,
        }
        const [error, resultData] = await to(
          userApi.sendPayment(stripePaymentParam),
        )
        if (error) {
          const errorMessage = (error as AxiosError).message
          ElMessage.error(errorMessage)
        } else if (resultData) {
          switch (resultData.status) {
            //修改成功
            case 100: {
              ElMessage.success('购买成功')
              break
            }
            default:
              break
          }
        }
      }
    })
}
</script>

<style lang="scss" scoped>
.billing-form {
  box-sizing: border-box;
  display: grid;
  gap: 25px;
  width: 500px;
  padding: 20px;
  border: 1px solid $gray-300;
  border-radius: 16px;
  box-shadow: 0px 4px 4px 0px rgba(0, 0, 0, 0.25);

  .row {
    display: grid;
    grid-template-columns: auto 1fr;
    gap: 15px;
    align-items: center;

    &#three-in-row {
      grid-template-columns: 2fr 1fr 2fr;

      #address_state {
        width: 80%;
      }

      #address_zip {
        width: 60%;
      }
    }

    &#two-in-row {
      grid-template-columns: 2fr 2fr 1fr;

      .cvc-text {
        display: flex;
        flex-direction: column;
      }
    }

    & input {
      border: 1px solid $gray-300;
      border-radius: 5px;
      height: 40px;
      padding-left: 10px;
      font-size: 18px;
      width: 90%;
    }

    #card-number {
      border: 1px solid $gray-300;
      border-radius: 5px;
      width: 90%;
      height: 40px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      padding-left: 10px;
    }

    #card-cvc,
    #card-expiry {
      border: 1px solid $gray-300;
      border-radius: 5px;
      width: 90%;
      height: 40px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      padding-left: 10px;
    }
  }

  .button {
    display: flex;
    justify-content: center;
    .pay-button {
      font-family: $text-font-family;
      font-style: normal;
      font-weight: 500;
      font-size: 14px;
      line-height: 28px;
      background-color: $blue-900;
      color: white;
      border-radius: 6px;
      border: 0px;
      height: 40px;
      width: 90%;
      padding: 2px 24px;
    }
  }

  .validation-error {
    color: red;
    font-size: 16px;
    display: flex;
    justify-content: center;
  }
  .stripe-container {
    display: flex;
    justify-content: center;
    .stripe-logo {
      height: 30px;
    }
  }
}
</style>
