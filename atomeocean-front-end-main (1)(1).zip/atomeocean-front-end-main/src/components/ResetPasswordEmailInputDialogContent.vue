<template>
  <div class="authentication-div">
    <h2>
      找回密码
      <el-link style="margin: 5px 0 0 10px" @click="goToSignIn"
        >已有账号？登录</el-link
      >
    </h2>

    <el-form ref="formRef" :model="resetPasswordForm" :rules="rules">
      <h4>邮箱</h4>
      <el-form-item prop="userEmail" class="form-item">
        <div class="input-wrapper">
          <el-input
            v-model="resetPasswordForm.userEmail"
            placeholder="请输入您在注册时使用的邮箱"
            clearable
            class="input-box"
            prop="email"
          >
          </el-input>
        </div>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" @click.prevent="submit(formRef)">
          下一步
        </el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script lang="ts" setup>
import { reactive, ref } from 'vue'
import { FormInstance, FormRules } from 'element-plus'
import { useUserStore } from '@/store/user'
import { useRouter } from 'vue-router'
import { useReCaptcha } from 'vue-recaptcha-v3'
import { useRecaptchaStore } from '@/store/recaptcha'
import { RESET_PASSWORD_RECAPTCHA_ACTION } from '@/constant/recaptchaActionConstant'

const formRef = ref<FormInstance>()
const userStore = useUserStore()
const router = useRouter()

const recaptchaInstance = useReCaptcha()
const recaptchaStore = useRecaptchaStore()

const resetPasswordForm = reactive({
  userEmail: userStore.getUserEmail,
})

const rules = reactive<FormRules>({
  userEmail: [
    {
      required: true,
      message: 'Email不能为空',
      trigger: 'blur',
    },
    {
      type: 'email',
      message: '请输入正确的Email',
      trigger: 'blur',
    },
  ],
})

const submit = async (formEl: FormInstance | undefined) => {
  if (!formEl) return
  await formEl.validate(async (valid) => {
    if (valid) {
      //加载recaptcha instance
      await recaptchaInstance?.recaptchaLoaded()

      //获取token
      const token = await recaptchaInstance?.executeRecaptcha(
        RESET_PASSWORD_RECAPTCHA_ACTION,
      )

      //保存recaptcha token
      recaptchaStore.setRecaptchaToken(token)

      // 保存用户输入
      userStore.setUserEmail(resetPasswordForm.userEmail)

      // 直接跳转密码输入页
      router.replace('/resetpassword/newpassword')
    } else {
      return false
    }
  })
}

const goToSignIn = () => {
  router.replace('/signin')
}
</script>

<style lang="scss" scoped>
.authentication-div {
  width: 90%;
  margin: 0 auto;
  font-family: $text-font-family;

  h2 {
    font-weight: normal;
  }

  h4 {
    text-align: left;
    margin-bottom: 15px;
  }

  .el-form-item {
    margin-bottom: 40px;
  }

  .input-wrapper {
    width: 100%;
    position: relative;

    .input-box {
      :deep(.el-input__wrapper) {
        border-radius: 0;
        padding: 0;
        box-shadow: 0 -1px 0 0 var(
            --el-input-border-color,
            var(--el-border-color)
          ) inset;
      }

      :deep(.el-input__wrapper:hover) {
        box-shadow: 0 -1px 0 0 var(--el-input-hover-border-color) inset;
      }

      :deep(.el-input__wrapper.is-focus) {
        box-shadow: 0 -1px 0 0 var(--el-input-focus-border-color) inset;
      }
    }

    .password-toggler {
      position: absolute;
      right: 0px;
      cursor: pointer;
      opacity: 0.8;
    }
  }

  :deep(.el-form-item.is-error .el-input__wrapper) {
    box-shadow: 0 -1px 0 0 var(--el-color-danger) inset;
  }

  .el-link {
    padding-bottom: 3px;
    color: var(--el-link-hover-text-color);
  }
}
</style>
