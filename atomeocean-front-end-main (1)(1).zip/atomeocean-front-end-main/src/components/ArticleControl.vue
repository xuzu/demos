<template>
  <div class="control_wrap">
    <div
      class="icon_item collect"
      :class="{ active: data.isShowCollect }"
      @click.self="handlerShowPop('collect')"
    >
      <div class="content collect_content" v-if="data.isShowCollect">
        <el-checkbox-group v-model="data.collectCheckList">
          <div class="collect_item">
            <el-checkbox label="默认收藏夹" size="large" />
          </div>
          <div class="collect_item">
            <el-checkbox label="自建收藏夹" size="large" />
          </div>
        </el-checkbox-group>
        <div class="collect_item add" @click="openAddCollectDialog">
          <i></i>
          <span>新建收藏夹</span>
        </div>
      </div>
    </div>
    <div
      class="icon_item share"
      :class="{ active: data.isShowShare }"
      @click.self="handlerShowPop('share')"
      @click="generateQRCode()"
    >
      <div class="content share_content" v-if="data.isShowShare">
        <div class="copy" @click="shareArticle()">
          <i></i>
          <span>复制链接</span>
        </div>
        <div class="scan">
          <p>或扫描二维码</p>
          <canvas id="canvas" width="80" height="80"></canvas>
        </div>
      </div>
    </div>
    <div
      class="icon_item edit"
      v-if="props.isAuthor"
      @click="editArticle"
    ></div>
    <div
      class="icon_item delete"
      v-if="props.isAuthor"
      @click.self="openDeleteDialog"
    ></div>
    <div
      class="icon_item more"
      v-if="!props.isAuthor"
      @click.self="handlerShowPop('more')"
    >
      <div class="content more_content" v-if="data.isShowMore">
        <div class="more_item" @click="feedbackArticle">举报该文章</div>
        <!--        <div class="more_item" @click="feedbackArticle('shield')">屏蔽该作者</div>-->
        <div class="more_item" @click="feedbackArticle">举报该作者</div>
      </div>
    </div>
    <!-- 新建收藏夹 -->
    <el-dialog
      v-model="data.dialogAddcollectsVisible"
      width="468px"
      class="collect_dialog"
      align-center
      :append-to-body="true"
    >
      <template #header="{ titleId, titleClass }">
        <div class="dialog_header">
          <h3 :id="titleId" :class="titleClass">新建收藏夹</h3>
        </div>
      </template>
      <div class="dialog_main">
        <div class="dialog_main__body">
          <el-input
            v-model="data.favorites.title"
            style="height: 44px"
            placeholder="收藏夹标题"
          />
          <el-input
            v-model="data.favorites.desc"
            :autosize="{ minRows: 5, maxRows: 7 }"
            type="textarea"
            class="textarea_inp"
            placeholder="收藏夹描述（可选）"
          />
        </div>
        <div class="dialog_main__footer">
          <div class="settings">
            <el-select
              v-model="data.favorites.visibilityVal"
              class=""
              placeholder="可见性设置"
            >
              <el-option
                v-for="item in VISIBILITY_LIST"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </div>
          <div class="buttons">
            <el-button @click="data.dialogAddcollectsVisible = false"
              >取消</el-button
            >
            <el-button
              type="primary"
              @click="data.dialogAddcollectsVisible = false"
              >确认</el-button
            >
          </div>
        </div>
      </div>
    </el-dialog>
    <!-- 是否删除文章 -->
    <el-dialog
      v-model="data.deleteDialogVisible"
      width="387px"
      class="delete_dialog"
    >
      <div class="delete_dialog_inner">
        <span>您确认需要删除该篇文章吗？</span>
        <div class="dialog-footer">
          <el-button @click="deleteArticle">删除</el-button>
          <el-button type="primary" @click="data.deleteDialogVisible = false">
            取消
          </el-button>
        </div>
      </div>
    </el-dialog>
    <!-- 已删除文章 -->
    <el-dialog
      v-model="data.deletedDialogVisible"
      :show-close="false"
      width="387px"
      class="deleted_dialog"
    >
      <div class="deleted_dialog_inner">
        <div class="title">
          <i></i>
          <span>文章已删除！</span>
        </div>
        <span class="tips">即将跳转至个人页面<span class="dot">...</span></span>
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { reactive, defineProps } from 'vue'
import { useRouter } from 'vue-router'
import { useClipboard } from '@vueuse/core'
import { ElMessage } from 'element-plus'
import { useArticleStore } from '@/store/article'
import { ResourceOperationType } from '@/api/ResourceOperationType'
import editorApi from '@/api/editor'
import { useArticleListStore } from '@/store/articleList'
import QRCode from 'qrcode'
import { useEditorStore } from '@/store/editor'
import { VISIBILITY_LIST } from '@/constant/editor/editorTextConstant'

const articleStore = useArticleStore()
const articleListStore = useArticleListStore()
const editorStore = useEditorStore()

const data = reactive({
  favorites: {
    title: '',
    desc: '',
    visibilityVal: '', // 可见性设置value
  },
  deleteDialogVisible: false, // 删除弹窗显示
  deletedDialogVisible: false, // 已删除弹窗
  dialogAddcollectsVisible: false, // 新建收藏夹弹窗显示
  collectCheckList: [], // 收藏弹窗复选框
  isShowCollect: false, // 显示收藏弹窗
  isShowShare: false, // 显示分享弹窗
  isShowMore: false, // 显示更多弹窗
})

//剪贴板
const { copy } = useClipboard()

const generateQRCode = async () => {
  try {
    // 生成二维码
    const canvas = document.getElementById('canvas')
    const qrCodeLink = articleStore.getArticleShareLink() // 获取生成二维码的链接
    await QRCode.toCanvas(canvas, qrCodeLink)
  } catch (err) {
    console.error(err)
  }
}

const router = useRouter()
const props = defineProps({
  isAuthor: {
    type: Boolean,
    default: false,
  },
  isValidArticle: {
    type: Boolean,
    default: true,
  },
})

const handlerShowPop = (type) => {
  if (type === 'collect') {
    showThisPop('collect', 'share', 'more')
  } else if (type === 'share') {
    showThisPop('share', 'collect', 'more')
  } else if (type === 'more') {
    showThisPop('more', 'collect', 'share')
  }
}
/**
 * @description: 显示当前弹窗，关闭其他弹窗
 * @showPopName {显示的弹窗}
 * @hidePopName {关闭的弹窗}
 * @return: null
 */
const showThisPop = (showPopName, hidePopName1, hidePopName2) => {
  const popupObject = {
    collect: 'isShowCollect',
    share: 'isShowShare',
    more: 'isShowMore',
  }

  data[popupObject[showPopName]] = !data[popupObject[showPopName]]
  data[popupObject[hidePopName1]] = false
  data[popupObject[hidePopName2]] = false
}

// 新建收藏夹弹窗
const openAddCollectDialog = () => {
  data.dialogAddcollectsVisible = true
}
const openDeleteDialog = () => {
  data.deleteDialogVisible = true
}

// 删除文章
const deleteArticle = async () => {
  const postArticleParams = {
    operationType: ResourceOperationType.Delete,
    articleId: articleStore.article.articleId,
  }
  //向后端发送删除请求
  const deleteArticleResponse = await editorApi.uploadArticle(postArticleParams)
  if (deleteArticleResponse) {
    ElMessage({
      message: 'your article has been deleted',
      type: 'success',
    })
    articleListStore.deleteArticleWithIndex(articleStore.indexInArticleList)

    // 清空article store本地数据
    articleStore.$reset()

    //更新模态框的状态
    data.deleteDialogVisible = false
    data.deletedDialogVisible = true

    // 设置一个定时器，让用户有足够的时间看到消息
    setTimeout(async () => {
      await router.replace({
        path: '/',
      })
    }, 2000) // 2 秒后跳转
  }
}

/**
 * 跳转到编辑界面
 */
const editArticle = () => {
  // 跳转到编辑器页面，并预先展示当前文章的内容，供编辑后上传
  articleStore.setIsBeingEdited(true)
  editorStore.refreshArticleId(articleStore.article.articleId)
  router.push({
    path: '/editor',
  })
}

// 举报/屏蔽
const feedbackArticle = (type) => {
  // type = type || 'report'
  ElMessage.success('举报成功~')
  // if ( type === 'report' ) {
  //   // 举报
  //   ElMessage.success('举报成功~')
  // } else {
  //   // 屏蔽
  //   ElMessage.success('屏蔽成功~')
  // }
  data.isShowMore = false
}

/**
 * 将文章的链接复制到剪贴板
 */
const shareArticle = () => {
  copy(articleStore.getArticleShareLink())
  ElMessage({
    message: '文章分享链接已经复制到剪贴板',
    type: 'success',
  })
}
</script>
<style lang="scss" scpoed>
.control_wrap {
  display: flex;

  & *,
  & *::before,
  & *::after {
    box-sizing: border-box;
  }

  .icon_item {
    position: relative;
    width: 24px;
    height: 24px;
    background: no-repeat center center/100% 100%;
    cursor: pointer;

    .content {
      position: absolute;
      top: 28px;
      left: -10px;
      padding: 15px;
      background: linear-gradient(0deg, $background-white, $background-white),
        linear-gradient(0deg, #ececec, #ececec);
      border: 1px solid rgba(236, 236, 236, 1);
      box-shadow: 0px 1px 2px 0px rgba(236, 236, 236, 1);
    }
  }

  .icon_item:not(:last-child) {
    margin-right: 11px;
  }

  .collect {
    background-image: url('../assets/icon_collect.png');

    &.active {
      background-image: url('../assets/icon_collect__active.png');
    }

    &_content {
      width: 126px;
      height: 140px;
    }

    &_item {
      display: flex;
      align-items: center;
      height: 28px;

      & + .collect_item {
        margin-top: 8px;
      }

      &.add {
        position: relative;
        margin-top: 16px;

        i {
          display: block;
          margin-left: -3px;
          margin-right: 3px;
          width: 24px;
          height: 24px;
          background: url('../assets/icon_add.png') no-repeat center center/100%
            100%;
        }

        span {
          font-size: 14px;
          font-weight: 500;
          line-height: 28px;
          color: rgba(33, 124, 255, 1);
        }

        &::before {
          content: '';
          position: absolute;
          top: -8px;
          width: 100%;
          height: 1px;
          background: rgb(236, 236, 236);
        }
      }
    }
  }

  .share {
    background-image: url('../assets/icon_share.png');

    &.active {
      background-image: url('../assets/icon_share__active.png');
    }

    &_content {
      width: 116px;
      height: 176px;
      font-size: 14px;
      font-weight: 400;
      line-height: 28px;
      color: rgba(151, 151, 151, 1);

      .copy {
        display: flex;
        align-items: center;

        i {
          display: inline-block;
          width: 20px;
          height: 20px;
          background: url('../assets/icon_link.png') no-repeat center
            center/100% 100%;
          margin-right: 6px;
        }
      }

      .scan {
        p {
          margin: 5px 0;
        }

        canvas {
          height: 80px !important;
          width: 80px !important;
        }
      }
    }
  }

  .edit {
    background-image: url('../assets/icon_edit.png');

    &:hover {
      background-image: url('../assets/icon_edit__active.png');
    }
  }

  .delete {
    background-image: url('../assets/icon_delete.png');

    &:hover {
      background-image: url('../assets/icon_delete__active.png');
    }
  }

  .more {
    background-image: url('../assets/icon_more.png');

    &_content {
      width: 102px;
      height: 96px;
    }

    &_item {
      font-size: 14px;
      font-weight: 400;
      line-height: 28px;
      color: rgba(151, 151, 151, 1);

      & + .more_item {
        margin-top: 8px;
      }
    }
  }
}

.collect_dialog {
  height: 396px;

  .dialog_header {
    .el-dialog__title {
      padding: 0;
      margin: 0;
    }

    .el-dialog__title {
      font-size: 24px;
      text-align: center;
    }
  }

  .el-dialog__header {
    padding: 48px 0 32px;
    margin: 0;
  }

  .el-dialog__close {
    font-size: 24px;
  }

  .el-dialog__body {
    padding: 0 32px;

    .textarea_inp {
      margin-top: 16px;
      height: 115px;
    }
  }

  .dialog_main__footer {
    margin-top: 48px;
    height: 32px;
    display: flex;
    justify-content: space-between;

    .el-select {
      display: block;
    }

    .buttons {
      line-height: 32px;
    }
  }
}

.el-select-dropdown__item.hover::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 3px;
  height: 100%;
  background: rgba(33, 124, 255, 1);
}

.delete_dialog {
  .el-dialog__body {
    padding: 20px 48px 40px;
  }

  &_inner {
    & > span {
      display: block;
      height: 28px;
      line-height: 28px;
      font-size: 16px;
      text-align: center;
      color: rgba(0, 0, 0, 1);
    }

    .dialog-footer {
      margin-top: 40px;
      display: flex;
      justify-content: space-between;
      color: #fff;
    }
  }
}

.deleted_dialog {
  height: 228px;

  .el-dialog__header {
    height: 0;
  }

  .el-dialog__body {
    // padding: 20px 48px 40px;
  }

  &_inner {
    text-align: center;
    color: rgba(33, 36, 39, 1);

    .title {
      display: flex;
      justify-content: center;

      i {
        display: block;
        margin-right: 8px;
        width: 32px;
        height: 32px;
        background: url('../assets/icon_deleted.png') no-repeat center
          center/100% 100%;
      }

      span {
        display: block;
        font-size: 24px;
        font-weight: 400;
        line-height: 32px;
      }
    }

    .tips {
      display: block;
      margin-top: 48px;
      font-size: 14px;
      font-weight: 400;
      line-height: 28px;

      .dot {
        display: inline-block;
        text-align: center;
        margin: 0 auto;
        overflow: hidden;
        height: 1em;
        line-height: 1em;
        vertical-align: -0.25em;
      }

      .dot::before {
        display: block;
        content: '...\A..\A.';
        white-space: pre-wrap;
        animation: dot 2s infinite step-start both;
      }

      @keyframes dot {
        33% {
          transform: translateY(-2em);
        }
        66% {
          transform: translateY(-1em);
        }
      }
    }
  }
}
</style>
