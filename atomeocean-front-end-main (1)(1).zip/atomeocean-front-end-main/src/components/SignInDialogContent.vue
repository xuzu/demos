<template>
  <div class="authentication-div">
    <div class="authentication-div-title">
      <h2 class="login-h2">登录atomeocean</h2>
      <div>
        尚未注册？
        <el-link @click="goToRegister">注册</el-link>
      </div>
    </div>

    <el-form ref="formRef" :model="signInForm" :rules="rules">
      <h4 class="login-h4">邮箱</h4>
      <el-form-item prop="userEmail" class="form-item">
        <div class="input-wrapper">
          <el-input
            v-model="signInForm.userEmail"
            placeholder="请输入注册时的邮箱"
            clearable
            class="input-box"
          >
          </el-input>
        </div>
      </el-form-item>

      <h4 class="login-h4">
        密码
        <span class="reset-password-link"
          >忘记密码？<el-link @click="goToResetPassword"
            >点击这里找回</el-link
          ></span
        >
      </h4>
      <el-form-item prop="password" class="form-item">
        <div class="input-wrapper">
          <el-input
            v-model="signInForm.password"
            placeholder="请输入密码"
            :type="passwordVisible ? 'text' : 'password'"
            ref="passwordInput"
            autocomplete="off"
            class="input-box"
          >
          </el-input>
          <span class="password-toggler" @click="toggleShow">
            <span v-if="passwordVisible" class="toggle-icon">
              <mdicon name="eye-off-outline"></mdicon>
            </span>
            <span v-else class="toggle-icon">
              <mdicon name="eye-outline"></mdicon>
            </span>
          </span>
        </div>
      </el-form-item>
      <!--添加recaptcha token组件-->
      <RecaptchaComponent ref="recaptchaComponentRef" />
      <el-form-item>
        <el-button @click="submit(formRef)"> 登录 </el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script lang="ts" setup>
import { reactive, ref } from 'vue'
import { ElMessage, FormInstance, FormRules } from 'element-plus'
import { useUserStore } from '@/store/user'
import { useRouter } from 'vue-router'
import { useRecaptchaStore } from '@/store/recaptcha'
import { SIGN_IN_RECAPTCHA_ACTION } from '@/constant/recaptchaActionConstant'
import { RequestUserInformationParams } from '@/api/userInformation/model'
import { useUserInformationStore } from '@/store/userInformation'
import {
  LOGIN_FAILURE_MESSAGE,
  LOGIN_SUCCESSFUL_MESSAGE,
} from '@/constant/LoginMessageConstant'
import { BAD_NETWORK_ENV } from '@/constant/generalMessageConstant'
import { load } from '@/utils'
import { LOGIN } from '@/constant/loadingConstant'
import to from 'await-to-js'
import { AxiosError } from 'axios'

const formRef = ref<FormInstance>()
const passwordVisible = ref(false)
const userStore = useUserStore()
const router = useRouter()
const userInformationStore = useUserInformationStore()

const recaptchaStore = useRecaptchaStore()
//创建recaptcha组件引用
const recaptchaComponentRef = ref<any>()

const signInForm = reactive({
  userEmail: '',
  password: '',
})

const rules = reactive<FormRules>({
  userEmail: [
    {
      required: true,
      message: 'Email cannot be empty.',
      trigger: 'blur',
    },
  ],
  password: [
    {
      required: true,
      message: 'Password cannot be empty.',
      trigger: 'blur',
    },
  ],
})

function toggleShow() {
  passwordVisible.value = !passwordVisible.value
}

const submit = async (formEl: FormInstance | undefined) => {
  if (!formEl) return
  await formEl.validate(async (valid) => {
    if (valid) {
      //添加loading效果
      load.show(LOGIN)
      //生成recaptcha token
      await recaptchaComponentRef.value.generateRecaptchaToken(
        SIGN_IN_RECAPTCHA_ACTION,
      )
      //如果生成recaptcha token的请求出现异常，则关闭加载动画
      if (!recaptchaStore.getRecaptchaToken) {
        load.hide()
        return
      }

      //发送登录请求
      const [error, resultData] = await to(userStore.signIn(signInForm))

      //清除recaptcha token
      recaptchaComponentRef.value.clearRecaptchaToken()

      //如果登录发生异常
      if (error) {
        //取消loading效果
        load.hide()

        //如果error为登录请求未验证通过
        if ((error as AxiosError).response?.data) {
          const data: any = (error as AxiosError).response?.data
          if (data.status === 601) {
            ElMessage.error(BAD_NETWORK_ENV)
          } else if (data.status === 1013 || data.status === 1014) {
            ElMessage.error(LOGIN_FAILURE_MESSAGE)
          } else {
            ElMessage.error(error.message)
            await router.replace('/error')
          }
        }
        //其余异常行为(服务器宕机等)
        else {
          ElMessage.error(error.message)
          await router.replace('/error')
        }
      }
      //成功登录后
      else if (resultData) {
        //登录成功后发送获取用户头像信息的请求
        const requestUserInformationParams: RequestUserInformationParams = {
          encodedUserId: userStore.getUserId as string,
        }
        const [error, resultData] = await to(
          userInformationStore.getUserInformation(requestUserInformationParams),
        )
        //取消loading效果
        load.hide()
        if (error) {
          ElMessage.error(error.message)
          await router.replace('/error')
        } else if (resultData) {
          ElMessage.success(LOGIN_SUCCESSFUL_MESSAGE)
          //跳转首页
          await router.replace('/')
        }
      }
    } else {
      return false
    }
  })
}

const goToRegister = () => {
  router.replace('/register')
}

const goToResetPassword = () => {
  router.replace('/resetpassword/email')
}
</script>

<style lang="scss" scoped>
.authentication-div {
  text-align: center;
  width: 90%;
  margin: 0 auto;
  font-family: $text-font-family;

  .authentication-div-title {
    display: flex;
    flex-direction: row;
    height: 24px;
    align-items: center;
  }

  .authentication-div-title div {
    margin-left: 20px;
    margin-top: 10px;
    align-content: end;
    color: $text-color-interactive;
    font-weight: bolder;
  }

  .el-form-item {
    margin-bottom: 40px;
  }

  .input-wrapper {
    width: 100%;
    position: relative;

    .input-box {
      :deep(.el-input__wrapper) {
        border-radius: 0;
        padding: 0;
        box-shadow: 0 -1px 0 0 var(
            --el-input-border-color,
            var(--el-border-color)
          ) inset;
      }

      :deep(.el-input__wrapper:hover) {
        box-shadow: 0 -1px 0 0 var(--el-input-hover-border-color) inset;
      }

      :deep(.el-input__wrapper.is-focus) {
        box-shadow: 0 -1px 0 0 var(--el-input-focus-border-color) inset;
      }
    }

    .password-toggler {
      position: absolute;
      right: 0px;
      cursor: pointer;
      opacity: 0.8;
    }
  }

  :deep(.el-form-item.is-error .el-input__wrapper) {
    box-shadow: 0 -1px 0 0 var(--el-color-danger) inset;
  }

  .el-button {
    width: 100%;
    height: 48px;
    margin-left: 0;
    padding: 10px;
    background: $logo-blue;
    border: none;
    color: white;
  }

  .el-button:hover {
    filter: brightness(1.05);
  }

  .el-link {
    padding-bottom: 3px;
    color: $text-color-interactive;
    font-weight: $login-small-blue-font-weight;
  }

  .reset-password-link {
    color: $text-color-interactive;
    font-weight: bolder;
    margin-left: 8px;
  }
}
</style>
