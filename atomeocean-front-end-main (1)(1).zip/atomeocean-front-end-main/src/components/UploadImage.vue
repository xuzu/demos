<template>
  <div class="upload-image">
    <el-upload
      ref="originalcoverImageFile"
      :auto-upload="false"
      :limit="1"
      :on-change="onSelectcoverImageFile"
      :show-file-list="false"
      class="upload-popover-div"
      list-type="picture-card"
    >
      <template #trigger>
        <div class="upload-content">
          <div>
            <el-icon>
              <Plus />
            </el-icon>
          </div>
          <div class="upload-text">上传文章封面（选填）</div>
        </div>
      </template>
      <div v-if="cover" class="preview">
        <img class="el-upload-list__item-thumbnail" :src="cover" alt="" />
        <div class="delete-cover" @click="handleRemove">
          <el-icon>
            <Delete />
          </el-icon>
        </div>
      </div>
    </el-upload>
    <CropperEditor
      v-show="showcoverImageCropper"
      :img="croppercoverImageImg"
      @update:hide-cropper="hideCropper"
      @save-cropped-img="sendCroppedImg"
      :fixedRatio="[225, 120]"
    />
  </div>
</template>

<script lang="ts" setup>
import { useUserInformationStore } from '@/store/userInformation'
import { ElMessage, UploadInstance } from 'element-plus'
import { ref, watch, defineEmits, defineProps } from 'vue'
import to from 'await-to-js'
import CropperEditor from '@/components/CropperEditor.vue'
import { encryptMD5 } from '@/utils/crypto'
import {
  FILE_LOAD_FAILED,
  UPDATE_SUCCESS,
} from '@/constant/userInformationMessageConstant'
import { load } from '@/utils'
import { AxiosError } from 'axios'
import { useRouter } from 'vue-router'
import { FILE_UPLOAD_FAILED } from '@/constant/FileOperationMessageConstant'
import userApi from '@/api/user'
import eidtorApi from '@/api/editor'
import { usePermissionStore } from '@/store/permission'
import { useArticleStore } from '@/store/article'
import { TOKEN_INVALID } from '@/constant/generalMessageConstant'
import { UPLOADING } from '@/constant/loadingConstant'

// 定义事件
const emit = defineEmits(['updateCover'])
const props = defineProps(['imgUrl'])
//监听父级图片地址变化
watch(
  () => props.imgUrl,
  (newValue, oldValue) => {
    cover.value = newValue
  },
)
const userInformationStore = useUserInformationStore()
const handleRemove = () => {
  cover.value = ''
  emit('updateCover', '')
}
// 用户上传文件
const originalcoverImageFile = ref<UploadInstance>()
//该变量用于保存用户上传的文件在浏览器中的相对路径
const croppercoverImageImg = ref<any>()
const showcoverImageCropper = ref(false)
const router = useRouter()
const permissionStore = usePermissionStore()
const articleStore = useArticleStore()
const cover = ref(props.imgUrl)
// 用户在选择头像文件时触发
const onSelectcoverImageFile = (file: any) => {
  //检查文件类型和大小
  const { raw } = file
  const allowedTypes = ['image/jpg', 'image/jpeg', 'image/png']
  const maxSize = 1
  if (!allowedTypes.includes(raw.type)) {
    ElMessage.error('文件必须是jpg或png的格式')
    originalcoverImageFile.value?.clearFiles()
    return
  } else if (raw.size / 1024 / 1024 > maxSize) {
    ElMessage.error(`文件大小不能超过${maxSize}MB`)
    originalcoverImageFile.value?.clearFiles()
    return
  }
  //打开图片裁剪界面
  openCropper(raw)
}

//触发后读取文件，并打开图片剪切界面
function openCropper(file: File) {
  const reader = new FileReader()
  //为file reader设置监听函数，触发后执行
  reader.onload = (e) => {
    let data
    if (
      e &&
      e.target &&
      e.target.result &&
      typeof e.target.result === 'object'
    ) {
      // 把Array Buffer转化为blob 如果是base64不需要
      data = window.URL.createObjectURL(new Blob([e.target.result]))
    } else if (e && e.target && e.target.result) {
      data = e.target.result
    }
    //为cropper弹窗设置image-url(data)
    croppercoverImageImg.value = data
  }
  //读取图片，触发上面定义的监听函数
  reader.readAsArrayBuffer(file)
  //打开cropper弹窗
  showcoverImageCropper.value = true
}

//隐藏剪裁界面
const hideCropper = () => {
  //隐藏剪裁板
  showcoverImageCropper.value = false
  //清除cropperImg的值
  croppercoverImageImg.value = ''
  //清空当前组件上传的文件
  originalcoverImageFile.value?.clearFiles()
}

//子组件传递回剪裁后的图片，计算图片md5并发送请求
const sendCroppedImg = async (croppedImg: Blob) => {
  //隐藏剪裁界面
  hideCropper()
  let md5Hash
  try {
    //计算剪切后图片的md5值
    md5Hash = await encryptMD5(croppedImg)
  } catch (error) {
    ElMessage.error(FILE_LOAD_FAILED)
    return
  }
  //构造参数
  const params = new FormData()
  const extension = croppedImg.type === 'image/jpeg' ? '.jpg' : '.png'
  const fileName = 'coverImage' + extension
  params.append('coverImage', croppedImg, fileName)
  params.append('hash', md5Hash)

  //添加loading动画
  load.show(UPLOADING)
  //   emit("updateCover", "http://localhost:3000/img/logo.pic.960d1612.jpg");
  //   cover.value = "http://localhost:3000/img/logo.pic.960d1612.jpg";
  //发送请求
  const [error, resultData] = await to(eidtorApi.updateArticleCoverImg(params))
  //关闭加载动画
  load.hide()

  //网络请求异常
  if (error) {
    const errorMessage = (error as AxiosError).message
    ElMessage.error(errorMessage)
    await router.replace('/error')
  } else if (resultData) {
    switch (resultData.status) {
      //修改成功
      case 100: {
        ElMessage.success(UPDATE_SUCCESS)
        emit('updateCover', resultData.data)
        cover.value = resultData.data
        break
      }
      //上传失败
      case 1017: {
        ElMessage.error(FILE_UPLOAD_FAILED)
        break
      }
      //账号信息异常，退出登录状态
      default: {
        const res = await userApi.logout()
        if (res) {
          ElMessage.error(TOKEN_INVALID)
          userInformationStore.$reset()
          permissionStore.$reset()
          articleStore.$reset()
          await router.replace('/')
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.upload-image {
  width: 100%;
  flex-direction: column;

  .upload-popover-div {
    text-align: center;
  }
}

.upload-text {
  text-align: center;
  font-family: $text-font-family;
  font-style: normal;
  font-size: 14px;
  line-height: 28px;
  color: #979797;
}

.cropper-dialog {
  transform: translate(-15%, -70%);
  width: 500px;
  z-index: 999;
}

.preview {
  position: absolute;
  top: 0;
  left: 0;
  width: 225px;
  height: 122px;
  background-color: #fff;
  border: 1px dashed var(--el-border-color-darker);

  &:hover {
    .delete-cover {
      display: flex;
      background: rgba(0, 0, 0, 0.8);
      border-radius: 4px;

      .el-icon {
        cursor: pointer;
        color: #fff;
      }
    }
  }

  img {
    display: inline-block;
    width: 100%;
    height: 100%;
  }

  .delete-cover {
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    display: none;
  }
}
</style>
