<template>
  <div></div>
</template>

<script setup lang="ts">
import { defineExpose } from 'vue'
import { useReCaptcha } from 'vue-recaptcha-v3'
import { useRecaptchaStore } from '@/store/recaptcha'
import { RECAPTCHA_EXECUTION_EXCEPTION } from '@/constant/recaptchaActionConstant'
import { ElMessage } from 'element-plus'

const recaptchaInstance = useReCaptcha()
const recaptchaStore = useRecaptchaStore()
const generateRecaptchaToken = async (action: string) => {
  try {
    //加载recaptcha instance
    await recaptchaInstance?.recaptchaLoaded()
    //获取token
    const token = await recaptchaInstance?.executeRecaptcha(action)
    //保存recaptcha token
    recaptchaStore.setRecaptchaToken(token)
  } catch (error) {
    ElMessage.error(RECAPTCHA_EXECUTION_EXCEPTION)
    //清除recaptcha token
    recaptchaStore.clearRecaptchaToken()
  }
}

const clearRecaptchaToken = () => {
  //清除recaptcha token
  recaptchaStore.clearRecaptchaToken()
}

//暴露方法
defineExpose({ generateRecaptchaToken, clearRecaptchaToken })
</script>

<style scoped></style>
