<template>
  <div class="loading" v-show="msg.show">
    <div class="load-box">
      <img id="loading-image" src="../assets/loading.svg" alt="Loading" />
      <span class="loading-text">{{ msg.title }}</span>
    </div>
  </div>
</template>

<script>
export default {
  name: 'PageLoading',
  props: {
    msg: Object,
  },
}
</script>

<style lang="scss" scoped>
.loading {
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
}

.load-box {
  background-color: rgba(0, 0, 0, 0.55);
  width: 263px;
  height: 214px;
  border-radius: 20px;
  box-shadow: 0px 1px 15px rgba(0, 0, 0.5);
  color: #fff;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  letter-spacing: 0.8px;
  font-size: 13px;
}

#loading-image {
  width: 64px;
  height: 64px;
}

.loading-text {
  font-size: 18px;
  font-family: $text-font-family;
  font-weight: bold;
  margin-top: 30px;
}
</style>
