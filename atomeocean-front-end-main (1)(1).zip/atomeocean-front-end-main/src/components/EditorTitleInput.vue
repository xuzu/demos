<template>
  <div class="title_box">
    <el-input
      v-model="editorData.title"
      maxlength="100"
      placeholder="请输入标题"
      show-word-limit
      type="text"
    />
  </div>
</template>

<script lang="ts" setup>
import { useEditorStore } from '@/store/editor'
import { storeToRefs } from 'pinia/dist/pinia'

const editorStore = useEditorStore()
const { editorData } = storeToRefs(editorStore)
</script>

<style lang="scss" scoped>
.title_box {
  height: 56px;

  .el-input__wrapper {
    height: 100%;
  }

  .el-input {
    height: 100%;
    font-family: $text-font-family;
    font-style: normal;
    font-weight: 400;
    font-size: 24px;
    line-height: 32px;
    color: #979797;
  }
}
</style>
