<template>
  <div class="cropper-dialog">
    <div class="cropper-content">
      <div class="cropper" style="text-align: center">
        <vueCropper
          ref="cropper"
          :img="img"
          :output-size="option.size"
          :output-type="option.outputType"
          :info="true"
          :full="option.full"
          :can-move="option.canMove"
          :can-move-box="option.canMoveBox"
          :fixed-box="option.fixedBox"
          :original="option.original"
          :auto-crop="option.autoCrop"
          :auto-crop-width="option.autoCropWidth"
          :auto-crop-height="option.autoCropHeight"
          :center-box="option.centerBox"
          :high="option.high"
          :info-true="option.infoTrue"
          :enlarge="option.enlarge"
          :fixed="option.fixed"
          :fixed-number="option.fixedRatio"
        />
      </div>
    </div>
    <div class="dialog-footer">
      <el-button @click="cancel">取 消</el-button>
      <el-button type="primary" @click="saveImage">确认</el-button>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, defineProps, defineEmits } from 'vue'
import { VueCropper } from 'vue-cropper'
import 'vue-cropper/dist/index.css'

const props = defineProps({
  img: {
    type: String,
  },
  fixedRatio: {
    type: Array,
    default: () => [1, 1],
  },
})

const emits = defineEmits(['update:hide-cropper', 'save-cropped-img'])

const option = ref({
  size: 1, // 裁剪生成图片的质量
  full: false, // 是否输出原图比例的截图 默认false
  outputType: 'jpeg', // 裁剪生成图片的格式 默认jpg
  canMove: false, // 上传图片是否可以移动
  fixedBox: false, // 固定截图框大小 不允许改变
  original: false, // 上传图片按照原始比例渲染
  canMoveBox: true, // 截图框能否拖动
  autoCrop: true, // 是否默认自动生成截图框
  // 只有自动截图开启 宽度高度才生效
  autoCropWidth: 200, // 默认生成截图框宽度
  autoCropHeight: 200, // 默认生成截图框高度
  centerBox: true, // 截图框是否被限制在图片里面
  high: false, // 是否按照设备的dpr 输出等比例图片
  enlarge: 1, // 图片根据截图框输出比例倍数
  mode: 'contain', // 图片默认渲染方式
  maxImgSize: 2000, // 限制图片最大宽度和高度
  limitMinSize: [100, 120], // 更新裁剪框最小属性
  infoTrue: false, // true 为展示真实输出图片宽高 false 展示看到的截图框宽高
  fixed: true, // 是否开启截图框宽高固定比例  (默认:true)
  fixedRatio: props.fixedRatio, // 截图框的宽高比例
})

const cropper = ref<any>()

//用户点击取消按钮时触发
const cancel = () => {
  //向父组件发送隐藏剪裁板指令
  emits('update:hide-cropper')
}

//用户点击确认按钮时触发该事件
const saveImage = () => {
  //获取截取的图片
  cropper.value.getCropBlob(async (croppedImg: any) => {
    //向父组件传递用户截取的图片
    emits('save-cropped-img', croppedImg)
  })
}
</script>

<style scoped>
.cropper-dialog {
  transform: translate(-60%, -70%);
}

.cropper {
  width: 500px;
  height: 500px;
}

.dialog-footer {
}
</style>
