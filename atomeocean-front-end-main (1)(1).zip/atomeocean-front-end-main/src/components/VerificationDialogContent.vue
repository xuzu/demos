<template>
  <div class="email-verification-div">
    <div class="authentication-div-title">
      <h2 class="login-h2">注册atomeocean</h2>
      <div>
        已有账号？
        <el-link @click="goToSignIn">登录</el-link>
      </div>
    </div>

    <el-form ref="formRef" :model="emailVerificationForm">
      <p>
        若您所输入的邮箱曾在atomeocean完成注册，我们将向该邮箱地址（{{
          emailVerificationForm.email
        }}）发送验证码。
      </p>
      <p>请在15分钟内输入你所收到的验证码：</p>

      <div class="code-div">
        <input
          v-for="(item, index) in captchas"
          :key="index"
          v-model="item.num"
          :id="'captcha' + index"
          @input="inputFinish(index)"
          @click="focusOnIndex(index)"
          @keydown="inputDirection(index, $event)"
          @paste="pasteCode($event)"
          class="code"
          type="text"
          maxlength="1"
        />
      </div>
      <!--添加recaptcha token组件-->
      <RecaptchaComponent ref="recaptchaComponentRef" />

      <el-button
        class="verifyButton"
        @click.prevent="resendCode"
        :disabled="disableResendButton"
      >
        未收到验证码？点这里重新发送（{{ resendCounter }}s）
      </el-button>

      <div class="btn-div">
        <el-button class="lastButton" @click="goBack"> 上一步 </el-button>

        <el-form-item>
          <el-button
            type="primary"
            class="finishButton"
            @click.prevent="submit(formRef)"
          >
            完成验证并注册
          </el-button>
        </el-form-item>
      </div>
    </el-form>
  </div>
</template>

<script lang="ts" setup>
import { reactive, ref } from 'vue'
import { ElMessage, FormInstance } from 'element-plus'
import { useUserStore } from '@/store/user'
import { useRouter } from 'vue-router'
import to from 'await-to-js'
import { AxiosError } from 'axios'
import {
  SIGN_IN_RECAPTCHA_ACTION,
  VERIFY_RECAPTCHA_ACTION,
} from '@/constant/recaptchaActionConstant'
import { VERIFICATION_CODE_LENGTH } from '@/constant/VerificationCodeConstant'
import {
  EMAIL_TAKEN_MESSAGE,
  INVALID_CAPTCHA,
  INVALID_REGISTRATION_INFO,
  REGISTRATION_INFO_EXPIRED,
  VERIFICATION_CODE_EXPIRED,
  VERIFICATION_CODE_INCORRECT,
} from '@/constant/registerMessageConstant'
import { load } from '@/utils'
import { LoginRequestParams } from '@/api/user/model'
import { useRecaptchaStore } from '@/store/recaptcha'
import {
  BAD_NETWORK_ENV,
  BAD_REQUEST,
  EMAIL_SEND_FAILED,
  EXPIRED_INFO,
  UNKNOWN_ERROR,
} from '@/constant/generalMessageConstant'
import {
  LOGIN_FAILURE_MESSAGE,
  LOGIN_SUCCESSFUL_MESSAGE,
} from '@/constant/LoginMessageConstant'
import { VERIFICATION, LOGIN } from '@/constant/loadingConstant'
import { RequestUserInformationParams } from '@/api/userInformation/model'
import { useUserInformationStore } from '@/store/userInformation'

const formRef = ref<FormInstance>()

const captchas = reactive([
  { num: '' },
  { num: '' },
  { num: '' },
  { num: '' },
  { num: '' },
  { num: '' },
])
const captchaRule = /^[a-zA-Z0-9]*$/

const userStore = useUserStore()
const router = useRouter()
const recaptchaStore = useRecaptchaStore()
const userInformationStore = useUserInformationStore()
//创建recaptcha组件引用
const recaptchaComponentRef = ref<any>()

const emailVerificationForm = reactive({
  email: userStore.getUserEmail,
  code: '',
})

const goToSignIn = () => {
  router.replace('/signin')
}

function inputFinish(index: number) {
  const value = captchas[index].num
  const nextDom = document.getElementById('captcha' + (index + 1))
  //如果当前的值为字母或数字，则光标向后跳转一位
  if (value !== '' && captchaRule.test(value)) {
    captchas[index].num = value.toUpperCase()
    if (nextDom) {
      nextDom.focus()
    }
  } else {
    captchas[index].num = ''
  }
}

function focusOnIndex(index: number) {
  const dom = document.getElementById('captcha' + index) as HTMLInputElement
  if (dom) {
    dom.focus()
    //添加一个timeout，保证光标位置设置代码发生在光标focus之后
    setTimeout(() => {
      dom.selectionStart = dom.value.length
      dom.selectionEnd = dom.value.length
    }, 0)
  }
}

function inputDirection(index: number, event: KeyboardEvent) {
  const leftDom = document.getElementById(
    'captcha' + (index - 1),
  ) as HTMLInputElement
  const rightDom = document.getElementById(
    'captcha' + (index + 1),
  ) as HTMLInputElement

  if (event.key == 'ArrowLeft' && leftDom) {
    leftDom.focus()
    //添加一个timeout，保证光标位置设置代码发生在光标focus之后
    setTimeout(() => {
      leftDom.selectionStart = leftDom.value.length
      leftDom.selectionEnd = leftDom.value.length
    }, 0)
  }
  if (event.key == 'ArrowRight' && rightDom) {
    rightDom.focus()
  }
}

function pasteCode(event: ClipboardEvent) {
  //阻止默认复制行为
  event.preventDefault()
  //获取复制数据
  const clipboardData = event.clipboardData
  let pastedText = ''
  if (clipboardData) {
    pastedText = clipboardData.getData('text').trim().toUpperCase()
  }
  //如果长度过长，则只取前6位字符
  if (pastedText.length > VERIFICATION_CODE_LENGTH) {
    pastedText = pastedText.substring(0, VERIFICATION_CODE_LENGTH)
  }
  //如果复制到字符串不符合规范，提示信息不改变值
  if (!captchaRule.test(pastedText)) {
    ElMessage.error('验证码格式错误')
    return
  }
  //分割字符串
  const inputArr = pastedText.split('')
  for (let i = 0; i < inputArr.length; ++i) {
    //修改值
    captchas[i].num = inputArr[i]
    //光标后移动
    focusOnIndex(i + 1 == VERIFICATION_CODE_LENGTH ? i : i + 1)
  }
}

// Resend Verification Code
const resendCounter = ref(60)
const disableResendButton = ref(false)

const resendCode = async () => {
  disableResendButton.value = true
  const timer = setInterval(() => {
    resendCounter.value--
    if (resendCounter.value <= 0) {
      clearInterval(timer)
      disableResendButton.value = false
      resendCounter.value = 60
    }
  }, 1000)

  //校验参数
  if (!emailVerificationForm.email) {
    ElMessage.error(INVALID_REGISTRATION_INFO)
  } else {
    //创建请求参数
    const params = new URLSearchParams()
    params.append('email', emailVerificationForm.email)

    //生成recaptcha token
    await recaptchaComponentRef.value.generateRecaptchaToken(
      VERIFY_RECAPTCHA_ACTION,
    )

    if (recaptchaStore.getRecaptchaToken) {
      //发送请求
      const [error, resultData] = await to(
        userStore.resendVerificationCode(params),
      )

      //清除recaptcha token
      recaptchaComponentRef.value.clearRecaptchaToken()

      if (error) {
        const errorMessage = (error as AxiosError).message
        ElMessage.error(errorMessage)
        await router.replace('/error')
      } else if (resultData) {
        if (resultData.status === 100) {
          ElMessage.success(resultData.data)
        } else if (resultData.status === 601) {
          ElMessage.error(BAD_REQUEST)
        } else if (resultData.status === 1004) {
          ElMessage.error(INVALID_REGISTRATION_INFO)
        } else if (resultData.status === 1010) {
          ElMessage.error(EXPIRED_INFO)
        } else if (resultData.status === 1006) {
          ElMessage.error(EMAIL_SEND_FAILED)
        }
      }
    }
  }
}

const submit = async (formEl: FormInstance | undefined) => {
  if (!formEl) return

  emailVerificationForm.code = captchas.map((captcha) => captcha.num).join('')
  if (emailVerificationForm.code.length != 6) {
    ElMessage.error(INVALID_CAPTCHA)
    return
  }

  await formEl.validate(async (valid) => {
    if (valid) {
      //加载动画显示
      load.show(VERIFICATION)

      //创建请求参数
      const params = new URLSearchParams()
      params.append('email', emailVerificationForm.email)
      params.append('code', emailVerificationForm.code)

      //生成recaptcha token
      await recaptchaComponentRef.value.generateRecaptchaToken(
        VERIFY_RECAPTCHA_ACTION,
      )
      //如果生成recaptcha token的请求出现异常，则关闭加载动画
      if (!recaptchaStore.getRecaptchaToken) {
        load.hide()
        return
      }

      // 符合标准提交注册
      const [error, resultData] = await to(userStore.verifyEmail(params))
      //清除recaptcha token
      recaptchaComponentRef.value.clearRecaptchaToken()

      //关闭动画显示
      load.hide()

      //如果请求返回为error则跳转到错误页
      if (error) {
        const errorMessage = (error as AxiosError).message
        ElMessage.error(errorMessage)
        await router.replace('/error')
      }
      // 验证成功后跳转登陆
      else if (resultData) {
        //注册成功，转为登录状态
        if (resultData.status == 100) {
          //邮箱密码完整，自动登录
          if (userStore.getUserEmail && userStore.getPassword) {
            //加载动画显示
            load.show(LOGIN)

            //创建登录参数
            const loginParams: LoginRequestParams = {
              userEmail: userStore.getUserEmail,
              password: userStore.getPassword,
            }

            //生成recaptcha token
            await recaptchaComponentRef.value.generateRecaptchaToken(
              SIGN_IN_RECAPTCHA_ACTION,
            )
            //如果生成recaptcha token的请求出现异常，则关闭加载动画，跳转到登录页面
            if (!recaptchaStore.getRecaptchaToken) {
              load.hide()
              await router.replace('/signin')
            }

            //发送登录请求
            const [error, resultData] = await to(userStore.signIn(loginParams))

            //清除recaptcha token
            recaptchaComponentRef.value.clearRecaptchaToken()

            //如果登录发生异常
            if (error) {
              //取消loading效果
              load.hide()

              //如果error为登录请求未验证通过
              if ((error as AxiosError).response?.data) {
                const data: any = (error as AxiosError).response?.data
                if (data.status === 601) {
                  ElMessage.error(BAD_NETWORK_ENV)
                } else if (data.status === 1013 || data.status === 1014) {
                  ElMessage.error(LOGIN_FAILURE_MESSAGE)
                } else {
                  ElMessage.error(error.message)
                  await router.replace('/error')
                }
              }
              //其余异常行为
              else {
                ElMessage.error(error.message)
                await router.replace('/error')
              }
            } else if (resultData) {
              //登录成功后发送获取用户default用户名的请求
              const requestUserInformationParams: RequestUserInformationParams =
                {
                  encodedUserId: userStore.getUserId as string,
                }
              const [error, resultData] = await to(
                userInformationStore.getUserInformation(
                  requestUserInformationParams,
                ),
              )
              //取消loading效果
              load.hide()
              if (error) {
                ElMessage.error(error.message)
                await router.replace('/error')
              } else if (resultData) {
                ElMessage.success(LOGIN_SUCCESSFUL_MESSAGE)
                //跳转首页
                await router.replace('/')
              }
            }
          }
          //否则跳转到登录页
          else {
            await router.replace('/signin')
          }
        } else {
          switch (resultData.status) {
            case 601: {
              ElMessage.error(BAD_NETWORK_ENV)
              break
            }
            case 1005: {
              ElMessage.error(EMAIL_TAKEN_MESSAGE)
              break
            }
            case 1010: {
              ElMessage.error(VERIFICATION_CODE_EXPIRED)
              break
            }
            case 1011: {
              ElMessage.error(VERIFICATION_CODE_INCORRECT)
              break
            }
            case 1012: {
              ElMessage.error(REGISTRATION_INFO_EXPIRED)
              break
            }
            default: {
              ElMessage.error(UNKNOWN_ERROR)
              break
            }
          }
        }
      }
    } else {
      return false
    }
  })
}

const goBack = () => {
  router.replace('/register')
}
</script>

<style lang="scss" scoped>
.email-verification-div {
  width: 90%;
  margin: 0 auto;
  font-family: $text-font-family;

  .authentication-div-title {
    display: flex;
    flex-direction: row;
    height: 24px;
    align-items: center;
  }

  .authentication-div-title div {
    margin-left: 20px;
    margin-top: 10px;
    color: $text-color-interactive;
    font-weight: bolder;
  }

  .el-form-item {
    margin-bottom: 40px;
  }

  .verifyButton {
    font-family: $text-font-family;
    margin-bottom: 30px;
    height: 40px;
    width: 349px;
    border: 1px solid $logo-blue;
    font-size: 16px;
    color: $logo-blue;
  }

  .lastButton {
    font-family: $text-font-family;
    border: 1px solid $logo-blue;
    width: 114px;
    height: 48px;
    font-size: 18px;
    color: $logo-blue;
  }

  .finishButton {
    font-family: $text-font-family;
    margin-left: 20px;
    font-size: 18px;
    background-color: $logo-blue;
    height: 48px;
    width: 193px;
  }

  .input-wrapper {
    width: 100%;
    position: relative;

    .input-box {
      :deep(.el-input__wrapper) {
        border-radius: 0;
        padding: 0;
        box-shadow: 0 -1px 0 0 var(
            --el-input-border-color,
            var(--el-border-color)
          ) inset;
      }

      :deep(.el-input__wrapper:hover) {
        box-shadow: 0 -1px 0 0 var(--el-input-hover-border-color) inset;
      }

      :deep(.el-input__wrapper.is-focus) {
        box-shadow: 0 -1px 0 0 var(--el-input-focus-border-color) inset;
      }
    }

    .password-toggler {
      position: absolute;
      right: 0px;
      cursor: pointer;
      opacity: 0.8;
    }
  }

  :deep(.el-form-item.is-error .el-input__wrapper) {
    box-shadow: 0 -1px 0 0 var(--el-color-danger) inset;
  }

  .el-link {
    padding-bottom: 3px;
    font-weight: $login-small-blue-font-weight;
    color: $text-color-interactive;
  }

  .code-div {
    margin: 30px 0;

    .code {
      width: 40px;
      height: 40px;
      border-radius: 5px;
      border: 1px solid;
      text-align: center;
      margin-right: 15px;
      font-size: 20px;
    }
  }

  .btn-div {
    display: flex;
  }
}
</style>
