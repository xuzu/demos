<template>
  <div v-if="article?.isDeleted"></div>
  <div v-else class="article-row-div">
    <el-row class="activity-header" v-if="props.loadActivityInProfile">
      {{ article?.articleAuthor?.nickname }} 发表了:
    </el-row>
    <el-row v-else class="article-header" type="flex" justify="space-between">
      <el-col
        :span="12"
        @click="navigateToProfile(article?.articleAuthor?.authorId)"
      >
        <el-row type="flex" align="middle">
          <AvatarComponent
            :avatar-src="
              article?.articleAuthor?.avatarLink || defaultAvatarImage.path
            "
            :avatar-height="24"
            :avatar-width="24"
          />
          <span class="name">
            {{ article?.articleAuthor?.nickname }}
          </span>
          <span class="date">{{ article?.createTime || '' }} 发布</span>
        </el-row>
      </el-col>
      <el-col :span="6">
        <el-row class="row-bg" justify="end">
          <ArticleControl />
        </el-row>
      </el-col>
    </el-row>
    <el-row
      class="article-body"
      type="flex"
      justify="space-between"
      @click="requestFullArticle()"
    >
      <el-row class="main-content" type="flex" justify-content="space-between">
        <div class="main-content-top">
          <div class="title">
            {{ article?.title }}
          </div>
          <div class="content">{{ article?.collapsedContent }}</div>
          <div v-if="article?.promote" class="promote-mark">推广</div>
        </div>
        <div v-if="props.loadActivityInProfile">
          <el-row
            class="main-content-bottom activity-profile-top"
            justify="start"
          >
            <span class="text-2-regular"
              >{{ formatNumber(article?.viewCount) }}浏览</span
            >
            <span class="text-2-regular"
              >{{ article?.readMinutes }}分钟阅读</span
            >
          </el-row>
          <el-row
            class="main-content-bottom activity-profile-bottom"
            type="flex"
            justify="space-between"
          >
            <el-col :span="12">
              <el-row class="row-bg" justify="start">
                <ArticleControl />
              </el-row>
            </el-col>
          </el-row>
        </div>
        <el-row
          v-else
          class="main-content-bottom"
          type="flex"
          justify="space-between"
        >
          <el-col :span="12">
            <span
              class="tag"
              v-for="(tag, idx) in article?.articleTagList"
              :key="idx"
              >#{{ tag.title }}</span
            >
          </el-col>
          <el-row class="row-bg" justify="end">
            <span class="count">{{ article?.readMinutes }}分钟阅读</span>
            <span class="count"
              >{{ formatNumber(article?.viewCount) }}次浏览</span
            >
          </el-row>
        </el-row>
      </el-row>
      <div v-if="article?.articleCoverImageLink" class="cover">
        <el-image :src="article?.articleCoverImageLink" fit="cover"> </el-image>
      </div>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { defineProps, PropType } from 'vue'
import { ArticleData } from '@/store/article/types'
import { useRouter } from 'vue-router'
import { useArticleStore } from '@/store/article'
import { RequestArticleParams } from '@/api/article/model'
import { useClipboard } from '@vueuse/core'
import { navigateToProfile } from '@/utils/navigation'
import ArticleControl from '@/components/ArticleControl.vue'
import { formatNumber } from '@/utils/general'
import { defaultAvatarImage } from '@/store/article'
import AvatarComponent from '@/components/AvatarComponent.vue'

// 点击获取全文时保存文章相关数据
const articleStore = useArticleStore()

// 从父组件拿到article row信息
const props = defineProps({
  article: {
    type: Object as PropType<ArticleData>,
  },
  // 文章所在位置
  articleIndex: {
    type: Number,
    default: -1,
  },
  loadActivityInProfile: {
    type: Boolean,
  },
})

const router = useRouter()

const { copy } = useClipboard()

// 点击卡片请求文章全部，并跳转
const requestFullArticle = async () => {
  const propsArticle = props?.article
  if (propsArticle) {
    // 清空已有的article，并准备补全新的article
    articleStore.$reset()
    articleStore.$patch((state) => {
      state.indexInArticleList = props?.articleIndex
      state.article = propsArticle
    })
  }

  const requestArticleParams: RequestArticleParams = {
    articleId: articleStore.article.articleId ?? '',
  }

  // 跳转到新tab，加载全文内容
  await router.push({
    name: 'article',
    params: { articleId: requestArticleParams.articleId },
  })
}
</script>

<style lang="scss" scoped>
.article-row-div {
  padding: 6px 8px 32px;
  border-bottom: 1px solid $border-color-grey;
  margin-top: 32px;

  &:hover {
    cursor: pointer;
    border-radius: 15px;
    transform: scale(1.02);
    box-shadow: 0px 0px 8px 0px rgba(198, 198, 198, 1);
    transition: transform 0.5s linear;
  }

  .article-header {
    height: 28px;
    line-height: 28px;
    margin-bottom: 24px;

    .name {
      margin: 0 8px;
    }

    .date {
      display: inline-block;
      height: 14px;
      padding-left: 8px;
      font-family: $text-font-family;
      font-size: 14px;
      font-weight: 350;
      line-height: 14px;
      letter-spacing: 0em;
      text-align: left;
      color: #727272;
      border-left: 1px solid #727272;
    }
  }

  .activity-header {
    margin-bottom: 6px;
    font-family: $text-font-family;
    font-size: 16px;
    font-weight: 500;
    line-height: 28px;
    color: $text-color-neutral;
  }

  .article-body {
    .el-image {
      width: 160px;
      height: 168px;
      border-radius: 16px;
      margin-left: 24px;
      margin-bottom: 8px;
    }

    .main-content {
      flex: 1;
      margin: 0;
      flex-direction: column;
      justify-content: space-between;

      .main-content-top {
        min-height: 132px;
        position: relative;

        .title {
          font-family: $text-font-family;
          font-size: 20px;
          font-weight: 700;
          line-height: 32px;
          letter-spacing: 0em;
        }

        .content {
          margin-top: 8px;
          font-family: $text-font-family;
          font-size: 16px;
          font-weight: 350;
          line-height: 28px;
          letter-spacing: 0em;
          display: -webkit-box;
          overflow: hidden;
          white-space: normal !important;
          text-overflow: ellipsis;
          word-wrap: break-word;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
        }

        .promote-mark {
          height: 28px;
          padding: 0 8px;
          position: absolute;
          bottom: 0;
          right: 0;
          border-radius: 8px;
          background: #c6c6c64d;
          font-family: $text-font-family;
          font-size: 14px;
          font-weight: 700;
          line-height: 28px;
          letter-spacing: 0em;
          text-align: left;
          color: rgba(255, 255, 255, 0.8);
        }
      }

      .main-content-bottom {
        margin-top: 24px;
        height: 28px;

        .tag {
          margin-right: 16px;
          font-family: $text-font-family;
          font-size: 14px;
          font-weight: 500;
          line-height: 28px;
          letter-spacing: 0em;
          color: #212427;
        }

        .count {
          margin-left: 16px;
          font-family: $text-font-family;
          font-size: 14px;
          font-weight: 350;
          line-height: 28px;
          letter-spacing: 0em;
          color: #727272;
        }
      }

      .activity-profile {
        &-top {
          margin-top: 9px;
          gap: 13px;
        }

        &-bottom {
          margin-top: 15px;
        }
      }
    }
  }

  .article-row {
    margin: 0 24px;

    .author-information-row {
      padding-top: 24px;

      .author-information-row-span {
        display: flex;
        justify-content: flex-start;

        .article-display-date {
          color: $text-color-grey;
        }
      }
    }

    .title-and-content-row {
      .row-div {
        margin-top: 12px;

        .row-title-div {
          display: flex;
          justify-content: space-between;
          font-size: $title-text-font-size;
          font-weight: bold;

          padding-bottom: 8px;
        }

        .collapsed-content-div {
          display: flex;
          justify-content: space-between;
        }
      }
    }

    .bottom-information-row {
      padding: 8px 0 10px 0;

      display: flex;
      align-items: center;

      .bottom-left-div {
        color: $text-color-grey;
      }

      .bottom-right-div {
        text-align: end;
      }
    }
  }
}
</style>
