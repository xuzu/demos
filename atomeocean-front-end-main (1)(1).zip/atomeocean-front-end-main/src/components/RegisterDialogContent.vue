<template>
  <div class="authentication-div">
    <div class="authentication-div-title">
      <h2 class="login-h2">注册atomeocean</h2>
      <div>
        已有账号？
        <el-link @click="goToSignIn">登录</el-link>
      </div>
    </div>

    <el-form ref="formRef" :model="registerForm" :rules="rules">
      <h4 class="login-h4">邮箱</h4>
      <el-form-item prop="userEmail" class="form-item">
        <div class="input-wrapper">
          <el-input
            v-model="registerForm.userEmail"
            placeholder="请输入Email"
            clearable
            class="input-box"
            prop="email"
          >
          </el-input>
        </div>
      </el-form-item>

      <h4 class="login-h4">密码</h4>
      <el-form-item prop="password" class="form-item">
        <div class="input-wrapper">
          <el-input
            v-model="registerForm.password"
            placeholder="请输入密码"
            :type="passwordVisible ? 'text' : 'password'"
            ref="passwordInput"
            autocomplete="off"
            class="input-box"
          >
          </el-input>
          <span class="password-toggler" @click="passwordToggleShow">
            <span v-if="passwordVisible" class="toggle-icon">
              <mdicon name="eye-off-outline"></mdicon>
            </span>
            <span v-else class="toggle-icon">
              <mdicon name="eye-outline"></mdicon>
            </span>
          </span>
        </div>
        <div class="password-prompt">
          <div class="prompt-item">
            <span v-if="lengthRule" class="password-success">
              <mdicon name="check-outline"></mdicon>
            </span>
            <span v-else class="password-fail">
              <mdicon name="close-circle"></mdicon>
            </span>
            <span class="prompt-text">密码长度应在6到20位</span>
          </div>
          <div class="prompt-item">
            <span v-if="containsUpperCaseRule" class="password-success">
              <mdicon name="check-outline"></mdicon>
            </span>
            <span v-else class="password-fail">
              <mdicon name="close-circle"></mdicon>
            </span>
            <span class="prompt-text">包含至少一个大写字母</span>
          </div>
          <div class="prompt-item">
            <span v-if="containsLowerCaseRule" class="password-success">
              <mdicon name="check-outline"></mdicon>
            </span>
            <span v-else class="password-fail">
              <mdicon name="close-circle"></mdicon>
            </span>
            <span class="prompt-text">包含至少一个小写字母</span>
          </div>
          <div class="prompt-item">
            <span v-if="containsNumberRule" class="password-success">
              <mdicon name="check-outline"></mdicon>
            </span>
            <span v-else class="password-fail">
              <mdicon name="close-circle"></mdicon>
            </span>
            <span class="prompt-text">包含至少一个数字</span>
          </div>
        </div>
      </el-form-item>
      <!--添加recaptcha token组件-->
      <RecaptchaComponent ref="recaptchaComponentRef" />
      <el-form-item>
        <el-button @click.prevent="submit(formRef)"> 下一步 </el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script lang="ts" setup>
import { reactive, ref, watch } from 'vue'
import { ElMessage, FormInstance, FormRules } from 'element-plus'
import { useUserStore } from '@/store/user'
import { useRouter } from 'vue-router'
import to from 'await-to-js'
import { AxiosError } from 'axios'
import { SIGN_UP_RECAPTCHA_ACTION } from '@/constant/recaptchaActionConstant'
import { load } from '@/utils'
import { REGISTRATION } from '@/constant/loadingConstant'
import { useRecaptchaStore } from '@/store/recaptcha'
import {
  EMAIL_TAKEN_MESSAGE,
  INVALID_REFER_LINK,
  INVALID_REGISTRATION_INFO,
} from '@/constant/registerMessageConstant'
import {
  BAD_NETWORK_ENV,
  EMAIL_SEND_FAILED,
  UNKNOWN_ERROR,
} from '@/constant/generalMessageConstant'

const formRef = ref<FormInstance>()
const passwordVisible = ref(false)

const userStore = useUserStore()
const recaptchaStore = useRecaptchaStore()
const router = useRouter()

const registerForm = reactive({
  userEmail: userStore.getUserEmail,
  password: userStore.getPassword,
})

//创建recaptcha组件引用
const recaptchaComponentRef = ref<any>()

const checkLength = /^.{6,20}$/
const checkUpperCase = /^(?=.*[A-Z]).+$/
const checkLowerCase = /^(?=.*[a-z]).+$/
const checkNumber = /^(?=.*\d).+$/

const lengthRule = ref(checkLength.test(registerForm.password))
const containsUpperCaseRule = ref(checkUpperCase.test(registerForm.password))
const containsLowerCaseRule = ref(checkLowerCase.test(registerForm.password))
const containsNumberRule = ref(checkNumber.test(registerForm.password))

const validatePassword = () => {
  return (
    checkLength.test(registerForm.password) &&
    checkNumber.test(registerForm.password) &&
    checkLowerCase.test(registerForm.password) &&
    checkUpperCase.test(registerForm.password)
  )
}

const rules = reactive<FormRules>({
  userEmail: [
    {
      required: true,
      message: 'Email不能为空',
      trigger: 'blur',
    },
    {
      type: 'email',
      message: '请输入正确的Email',
      trigger: 'blur',
    },
  ],
  password: [
    {
      required: true,
      message: '',
      trigger: 'blur',
    },
    {
      validator: validatePassword,
      message: '',
      trigger: 'blur',
    },
  ],
})

watch(
  () => registerForm.password,
  (newVal) => {
    if (checkLength.test(registerForm.password)) {
      lengthRule.value = true
    } else {
      lengthRule.value = false
    }
    if (checkUpperCase.test(registerForm.password)) {
      containsUpperCaseRule.value = true
    } else {
      containsUpperCaseRule.value = false
    }
    if (checkLowerCase.test(registerForm.password)) {
      containsLowerCaseRule.value = true
    } else {
      containsLowerCaseRule.value = false
    }
    if (checkNumber.test(registerForm.password)) {
      containsNumberRule.value = true
    } else {
      containsNumberRule.value = false
    }
  },
)

function passwordToggleShow() {
  passwordVisible.value = !passwordVisible.value
}

const submit = async (formEl: FormInstance | undefined) => {
  if (!formEl) return

  await formEl.validate(async (valid) => {
    if (valid) {
      //加载动画显示
      load.show(REGISTRATION)

      //保存用户输入
      userStore.setUserEmail(registerForm.userEmail)
      userStore.setPassword(registerForm.password)

      //生成recaptcha token
      await recaptchaComponentRef.value.generateRecaptchaToken(
        SIGN_UP_RECAPTCHA_ACTION,
      )
      //如果生成recaptcha token的请求出现异常，则关闭加载动画
      if (!recaptchaStore.getRecaptchaToken) {
        load.hide()
        return
      }

      // 符合标准提交注册
      const [error, resultData] = await to(userStore.register(registerForm))

      //清除recaptcha token
      recaptchaComponentRef.value.clearRecaptchaToken()

      //关闭加载动画
      load.hide()

      //如果请求返回为error则跳转到错误页
      if (error) {
        const errorMessage = (error as AxiosError).message
        ElMessage.error(errorMessage)
        await router.replace('/error')
      }
      //如果响应成功，则根据后端的返回结果进行处理
      else if (resultData) {
        switch (resultData.status) {
          case 100: {
            await router.replace('/emailverify')
            break
          }
          case 601: {
            ElMessage.error(BAD_NETWORK_ENV)
            break
          }
          case 1004: {
            ElMessage.error(INVALID_REGISTRATION_INFO)
            break
          }
          case 1005: {
            ElMessage.error(EMAIL_TAKEN_MESSAGE)
            break
          }
          case 1006: {
            ElMessage.error(EMAIL_SEND_FAILED)
            break
          }
          case 1009: {
            ElMessage.error(INVALID_REFER_LINK)
            await router.replace('/emailverify')
            break
          }
          default: {
            ElMessage.error(UNKNOWN_ERROR)
            break
          }
        }
      }
    } else {
      return false
    }
  })
}

const goToSignIn = () => {
  router.replace('/signin')
}
</script>

<style lang="scss" scoped>
.authentication-div {
  text-align: center;
  width: 90%;
  margin: 0 auto;
  font-family: $text-font-family;

  .authentication-div-title {
    display: flex;
    flex-direction: row;
    height: 24px;
    align-items: center;
  }

  .authentication-div-title div {
    margin-left: 20px;
    margin-top: 10px;
    color: $text-color-interactive;
    font-weight: bolder;
  }

  .el-link {
    padding-bottom: 3px;
    color: $text-color-interactive;
    font-weight: $login-small-blue-font-weight;
  }

  .el-form-item {
    margin-bottom: 40px;
  }

  .input-wrapper {
    width: 100%;
    position: relative;

    .input-box {
      :deep(.el-input__wrapper) {
        border-radius: 0;
        padding: 0;
        box-shadow: 0 -1px 0 0 var(
            --el-input-border-color,
            var(--el-border-color)
          ) inset;
      }

      :deep(.el-input__wrapper:hover) {
        box-shadow: 0 -1px 0 0 var(--el-input-hover-border-color) inset;
      }

      :deep(.el-input__wrapper.is-focus) {
        box-shadow: 0 -1px 0 0 var(--el-input-focus-border-color) inset;
      }
    }

    .password-toggler {
      position: absolute;
      right: 0px;
      cursor: pointer;
      opacity: 0.8;
    }
  }

  :deep(.el-form-item.is-error .el-input__wrapper) {
    box-shadow: 0 -1px 0 0 var(--el-color-danger) inset;
  }

  .password-prompt {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 0.8em;

    margin-top: 10px;
  }

  .prompt-item {
    grid-column: span 1;
    justify-self: start;
    align-self: center;
  }

  .password-success {
    height: 32px;
    color: $check-green;
  }

  .password-fail {
    height: 32px;
    color: $check-red;
  }

  .prompt-text {
    font-size: 0.9em;
    margin-left: 3px;
  }

  .el-button {
    width: 30%;
    margin-left: 0;
    padding: 10px;
    background: $logo-blue;
    border: none;
    color: white;
  }

  .el-button:hover {
    filter: brightness(1.05);
  }
}
</style>
