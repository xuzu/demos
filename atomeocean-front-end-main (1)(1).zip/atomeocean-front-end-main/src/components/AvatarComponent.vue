<template>
  <img
    id="avatar-img"
    :src="avatarSrc"
    :height="avatarHeight"
    :width="avatarWidth"
    alt="Avatar"
  />
</template>

<script lang="ts" setup>
import { defineProps } from 'vue'

const props = defineProps({
  avatarSrc: {
    type: String,
    required: true,
  },
  avatarHeight: {
    type: Number,
    required: true,
  },
  avatarWidth: {
    type: Number,
    required: true,
  },
})
</script>

<style lang="scss" scoped>
#avatar-img {
  object-fit: cover;
  border-radius: 50%;
}
</style>
