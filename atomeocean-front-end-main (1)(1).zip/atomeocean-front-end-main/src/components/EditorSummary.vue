<template>
  <div class="summary_box">
    <el-input
      v-model="editorData.summary"
      maxlength="100"
      placeholder="请输入摘要（选填），如不填写则默认为正文前100字"
      show-word-limit
      type="textarea"
    />
  </div>
</template>

<script lang="ts" setup>
import { useEditorStore } from '@/store/editor'
import { storeToRefs } from 'pinia/dist/pinia'

const editorStore = useEditorStore()
const { editorData } = storeToRefs(editorStore)
</script>

<style lang="scss" scoped>
.summary_box {
  height: 120px;
  border: 1px solid $gray-100;

  :deep(.el-textarea),
  :deep(.el-textarea .el-textarea__inner) {
    height: 100%;
  }

  :deep(.el-textarea .el-textarea__inner) {
    background: $background-grey;
  }
}
</style>
