<template>
  <div class="authentication-div">
    <h2>重置密码</h2>

    <el-form ref="formRef" :model="resetPasswordForm" :rules="rules">
      <p>请输入您希望使用的新密码：</p>
      <el-form-item prop="password" class="form-item">
        <div class="input-wrapper">
          <el-input
            v-model="resetPasswordForm.password"
            placeholder="请输入密码"
            :type="passwordVisible ? 'text' : 'password'"
            ref="passwordInput"
            autocomplete="off"
            class="input-box"
          >
          </el-input>
          <span class="password-toggler" @click="passwordToggleShow">
            <span v-if="passwordVisible" class="toggle-icon">
              <mdicon name="eye-off-outline"></mdicon>
            </span>
            <span v-else class="toggle-icon">
              <mdicon name="eye-outline"></mdicon>
            </span>
          </span>
        </div>
        <el-row class="rules-div">
          <el-col :span="12">
            <mdicon
              v-if="lengthRule"
              name="check-outline"
              class="satisfy-icon"
            ></mdicon>
            <mdicon
              v-else
              name="close-circle"
              class="not-satisfy-icon"
            ></mdicon>
            <span class="rules-span">密码长度应在6-20位</span>
          </el-col>
          <el-col :span="12">
            <mdicon
              v-if="containsUpperCaseRule"
              name="check-outline"
              class="satisfy-icon"
            ></mdicon>
            <mdicon
              v-else
              name="close-circle"
              class="not-satisfy-icon"
            ></mdicon>
            <span class="rules-span">包含至少一个大写字母</span>
          </el-col>
        </el-row>
        <el-row class="rules-div">
          <el-col :span="12">
            <mdicon
              v-if="containsLowerCaseRule"
              name="check-outline"
              class="satisfy-icon"
            ></mdicon>
            <mdicon
              v-else
              name="close-circle"
              class="not-satisfy-icon"
            ></mdicon>
            <span class="rules-span">包含至少一个小写字母</span>
          </el-col>
          <el-col :span="12">
            <mdicon
              v-if="containsNumberRule"
              name="check-outline"
              class="satisfy-icon"
            ></mdicon>
            <mdicon
              v-else
              name="close-circle"
              class="not-satisfy-icon"
            ></mdicon>
            <span class="rules-span">包含至少一个数字</span>
          </el-col>
        </el-row>
      </el-form-item>

      <p>请再次输入您希望使用的新密码</p>
      <el-form-item prop="repeatPassword" class="form-item">
        <div class="input-wrapper">
          <el-input
            v-model="resetPasswordForm.repeatPassword"
            placeholder="请输入密码"
            :type="verificationPasswordVisible ? 'text' : 'password'"
            ref="repeatPasswordInput"
            autocomplete="off"
            class="input-box"
          >
          </el-input>
          <span
            class="password-toggler"
            @click="verificationPasswordToggleShow"
          >
            <span v-if="verificationPasswordVisible" class="toggle-icon">
              <mdicon name="eye-off-outline"></mdicon>
            </span>
            <span v-else class="toggle-icon">
              <mdicon name="eye-outline"></mdicon>
            </span>
          </span>
        </div>
      </el-form-item>
      <!--添加recaptcha token组件-->
      <RecaptchaComponent ref="recaptchaComponentRef" />
      <div class="btn-div">
        <el-button @click="goToResetPasswordEmailInput"> 上一步 </el-button>

        <el-form-item>
          <el-button
            type="primary"
            style="margin-left: 20px"
            @click.prevent="submit(formRef)"
          >
            下一步
          </el-button>
        </el-form-item>
      </div>
    </el-form>
  </div>
</template>

<script lang="ts" setup>
import { reactive, ref, watch } from 'vue'
import { ElMessage, FormInstance, FormRules } from 'element-plus'
import { useUserStore } from '@/store/user'
import { useRouter } from 'vue-router'
import { useRecaptchaStore } from '@/store/recaptcha'
import { RESET_PASSWORD_RECAPTCHA_ACTION } from '@/constant/recaptchaActionConstant'
import to from 'await-to-js'
import { AxiosError } from 'axios'
import { load } from '@/utils'

const formRef = ref<FormInstance>()
const passwordVisible = ref(false)
const verificationPasswordVisible = ref(false)

const userStore = useUserStore()
const router = useRouter()

const recaptchaStore = useRecaptchaStore()
//创建recaptcha组件引用
const recaptchaComponentRef = ref<any>()

const resetPasswordForm = reactive({
  userEmail: userStore.getUserEmail,
  password: '',
  repeatPassword: '',
})

const checkLength = /^.{6,20}$/
const checkUpperCase = /^(?=.*[A-Z]).+$/
const checkLowerCase = /^(?=.*[a-z]).+$/
const checkNumber = /^(?=.*\d).+$/

const lengthRule = ref(checkLength.test(resetPasswordForm.password))
const containsUpperCaseRule = ref(
  checkUpperCase.test(resetPasswordForm.password),
)
const containsLowerCaseRule = ref(
  checkLowerCase.test(resetPasswordForm.password),
)
const containsNumberRule = ref(checkNumber.test(resetPasswordForm.password))

const validatePassword = () => {
  return (
    checkLength.test(resetPasswordForm.password) &&
    checkNumber.test(resetPasswordForm.password) &&
    checkLowerCase.test(resetPasswordForm.password) &&
    checkUpperCase.test(resetPasswordForm.password)
  )
}

const validateRepeatPasswod = () => {
  return resetPasswordForm.repeatPassword === resetPasswordForm.password
}

const rules = reactive<FormRules>({
  password: [
    {
      required: true,
      message: '',
      trigger: 'blur',
    },
    {
      validator: validatePassword,
      message: '',
      trigger: 'blur',
    },
  ],
  repeatPassword: [
    {
      required: true,
      message: '',
      trigger: 'blur',
    },
    {
      validator: validateRepeatPasswod,
      message: '',
      trigger: 'blur',
    },
  ],
})

watch(
  () => resetPasswordForm.password,
  (newVal) => {
    if (checkLength.test(resetPasswordForm.password)) {
      lengthRule.value = true
    } else {
      lengthRule.value = false
    }
    if (checkUpperCase.test(resetPasswordForm.password)) {
      containsUpperCaseRule.value = true
    } else {
      containsUpperCaseRule.value = false
    }
    if (checkLowerCase.test(resetPasswordForm.password)) {
      containsLowerCaseRule.value = true
    } else {
      containsLowerCaseRule.value = false
    }
    if (checkNumber.test(resetPasswordForm.password)) {
      containsNumberRule.value = true
    } else {
      containsNumberRule.value = false
    }
  },
)

function passwordToggleShow() {
  passwordVisible.value = !passwordVisible.value
}

function verificationPasswordToggleShow() {
  verificationPasswordVisible.value = !verificationPasswordVisible.value
}

const goToResetPasswordEmailInput = () => {
  router.replace('/resetpassword/email')
}

const submit = async (formEl: FormInstance | undefined) => {
  if (!formEl) return

  await formEl.validate(async (valid) => {
    if (valid) {
      //添加loading效果
      load.show()

      //创建请求参数
      const resetPasswordParams = {
        userEmail: resetPasswordForm.userEmail,
        password: resetPasswordForm.password,
      }

      //生成recaptcha token
      await recaptchaComponentRef.value.generateRecaptchaToken(
        RESET_PASSWORD_RECAPTCHA_ACTION,
      )
      //如果生成recaptcha token的请求出现异常，则关闭加载动画
      if (!recaptchaStore.getRecaptchaToken) {
        load.hide()
        return
      }

      //符合标准提交注册
      const [error, resultData] = await to(
        userStore.emailVerify(resetPasswordParams),
      )

      //清除recaptcha token
      recaptchaComponentRef.value.clearRecaptchaToken()

      //关闭加载动画
      load.hide()

      //如果请求返回为error则跳转到错误页
      if (error) {
        const errorMessage = (error as AxiosError).message
        ElMessage.error(errorMessage)
      } else if (resultData) {
        // 跳转至验证码输入页
        if (resultData.status === 100) {
          await router.replace('/resetpassword/verify')
        }
        //操作失败后，提示异常信息
        else {
          ElMessage.error(resultData.message)
        }
      }
    } else {
      return false
    }
  })
}
</script>

<style lang="scss" scoped>
.authentication-div {
  width: 90%;
  margin: 0 auto;
  font-family: Arial, Helvetica, sans-serif;

  h4 {
    text-align: left;
    margin-bottom: 15px;
  }

  .el-form-item {
    margin-bottom: 40px;
  }

  .input-wrapper {
    width: 100%;
    position: relative;

    .input-box {
      :deep(.el-input__wrapper) {
        border-radius: 0;
        padding: 0;
        box-shadow: 0 -1px 0 0 var(
            --el-input-border-color,
            var(--el-border-color)
          ) inset;
      }

      :deep(.el-input__wrapper:hover) {
        box-shadow: 0 -1px 0 0 var(--el-input-hover-border-color) inset;
      }

      :deep(.el-input__wrapper.is-focus) {
        box-shadow: 0 -1px 0 0 var(--el-input-focus-border-color) inset;
      }
    }

    .password-toggler {
      position: absolute;
      right: 0px;
      cursor: pointer;
      opacity: 0.8;
    }
  }

  :deep(.el-form-item.is-error .el-input__wrapper) {
    box-shadow: 0 -1px 0 0 var(--el-color-danger) inset;
  }

  .rules-div {
    width: 100%;
    margin-top: 10px;

    .satisfy-icon {
      color: rgba(51, 140, 56, 1);
      margin-right: 10px;
    }

    .not-satisfy-icon {
      color: rgba(198, 40, 40, 1);
      margin-right: 10px;
    }

    .rules-span {
      position: relative;
      top: 1px;
    }
  }

  .btn-div {
    display: flex;
  }
}
</style>
