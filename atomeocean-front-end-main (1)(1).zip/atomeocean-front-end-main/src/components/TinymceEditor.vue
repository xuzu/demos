<template>
  <div class="editor_box">
    <editor
      v-model="textContent"
      :api-key="editorApiKey"
      :init="customInit(init)"
      :disabled="disabled"
    >
    </editor>
  </div>
</template>

<script setup lang="ts">
import tinymce from 'tinymce/tinymce'
import Editor from '@tinymce/tinymce-vue'
// 导入Tinymce配置文件
import '@/assets/ts/importTinymce.ts'
import { init, editorApiKey } from '@/config/tinymceConfig'
import { defineExpose, defineProps, onMounted, ref, watchEffect } from 'vue'

const props = defineProps({
  value: {
    type: String,
    default: '',
  },
  disabled: {
    type: Boolean,
    default: false,
  },
  // 默认样式
  style: {
    type: Object,
    default: () => {
      return { width: '100%', height: '100%' }
    },
  },
  placeholder: {
    type: String,
    default: '请输入内容，不少于20个字',
  },
  parentMethod: {
    type: Function,
  },
})

// 初始化编辑器
const customInit = (init: any) => {
  // 允许外界传进来高度和placeholder
  init.height = props.style?.height
  init.placeholder = props.placeholder

  // 自定义图片上传
  // init.images_upload_handler = imageUpload

  return init
}

const textContent = ref(props.value)

watchEffect(() => {
  props.parentMethod(textContent.value)
})

// 组件挂载完毕
onMounted(() => {
  tinymce.init({})
})

// 编辑器相关方法
const clear = () => {
  textContent.value = ''
}

const setContent = (value: any) => {
  textContent.value = value
}

// 返回编辑器内的html字符串
const getContent = () => {
  return textContent.value
}

const getPlainTextContent = () => {
  const plainTextContent = tinymce.activeEditor?.getContent({ format: 'text' })
  return plainTextContent
}

/**
 * 根据wordCount插件获取词数统计
 * 返回文章词的数目
 */
const getWordCountInEditor = (): number => {
  const wordCount = tinymce.activeEditor?.plugins.wordcount
  return wordCount?.body?.getWordCount()
}

//调用预览功能
const preview = () => {
  return tinymce?.activeEditor?.execCommand('mcePreview')
}

defineExpose({
  setContent,
  getContent,
  getWordCountInEditor,
  getPlainTextContent,
  preview,
})
</script>

<style scoped></style>
