<template>
  <div>
    <p>{{ title }}</p>
    <div class="select_box">
      <el-select v-model="internalModelValue" :placeholder="placeholder">
        <el-option
          v-for="item in options"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        />
      </el-select>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, watchEffect, defineProps, defineEmits } from 'vue'

// props 和 emits
const props = defineProps({
  title: { type: String, required: true },
  options: { type: Array, required: true },
  placeholder: { type: String, default: '请选择' },
  modelValue: { type: [String, Number] },
})
const emits = defineEmits(['update:modelValue'])

// 设置内部的modelValue
const internalModelValue = ref(props.modelValue)

// 监听internalModelValue的变化，并发出事件
watchEffect(() => {
  emits('update:modelValue', internalModelValue.value)
})

// 同步外部的modelValue到内部
watchEffect(() => {
  internalModelValue.value = props.modelValue
})
</script>

<style lang="scss" scoped>
.select_box {
  margin-top: 12px;
  display: flex;
  width: 100%;
  height: 25px;
  box-sizing: border-box;

  ::v-deep .el-select-dropdown,
  ::v-deep .el-select {
    width: 100%;
  }

  ::v-deep .el-input__inner {
    &::placeholder {
      color: #606266 !important;
    }

    &::-webkit-input-placeholder {
      color: #606266 !important;
    }
  }
}
</style>
