<template>
  <div class="navigation-div">
    <div class="navigation-bar-container">
      <el-menu :ellipsis="false" mode="horizontal">
        <el-menu-item index="/" @click="menuItemRoute(0)">
          <el-image :src="logoPng"></el-image>
        </el-menu-item>

        <el-menu-item index="1" @click="menuItemRoute(0)"> 首页</el-menu-item>

        <el-menu-item index="2">
          <el-dropdown popper-class="article-category-dropdown">
            <span class="article-category-span"> 文章分类 </span>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item @click="articleCategoryRoute(0)"
                  >简历
                </el-dropdown-item>
                <el-dropdown-item @click="articleCategoryRoute(1)"
                  >面试
                </el-dropdown-item>
                <el-dropdown-item @click="articleCategoryRoute(2)"
                  >职场心得
                </el-dropdown-item>
                <el-dropdown-item @click="articleCategoryRoute(3)"
                  >更多
                </el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </el-menu-item>

        <el-menu-item index="3" @click="menuItemRoute(1)">
          发现作者
        </el-menu-item>

        <el-menu-item index="4" @click="menuItemRoute(2)">
          编辑精选
        </el-menu-item>

        <el-menu-item index="5" @click="menuItemRoute(3)">
          关于我们/合作
        </el-menu-item>

        <el-menu-item
          index="6"
          v-if="!props.isCustomPage || !props.isErrorPage"
        >
          <div class="search-bar-div">
            <el-input
              v-model="searchText"
              class="search_input"
              :prefix-icon="Search"
              @keyup.enter="searchGoogle"
            />
          </div>
        </el-menu-item>

        <div v-if="isAuthenticated" class="right-end-header-div-authenticated">
          <el-menu-item
            index="7-1"
            @click="navigateToEditor"
            class="write-idea"
          >
            <Icon icon="ic:round-edit-note" />
            写想法
          </el-menu-item>

          <el-menu-item
            index="7-2"
            @click="navigateToEditor"
            class="write-article"
          >
            <Icon icon="material-symbols:edit-document-outline" />
            写文章
          </el-menu-item>

          <el-menu-item class="user-sub-menu">
            <el-dropdown popper-class="avatar-dropdown" trigger="click">
              <div class="avatar-title">
                <AvatarComponent
                  :avatar-src="avatarLink"
                  :avatar-height="24"
                  :avatar-width="24"
                />
                <Icon
                  icon="material-symbols:arrow-drop-down-rounded"
                  class="avatar-dropdown-arrow"
                />
              </div>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item @click="profileRoute(0)">
                    <Icon icon="clarity:user-solid" class="user-icon" />
                    个人页面
                  </el-dropdown-item>
                  <el-dropdown-item @click="profileRoute(1)">
                    <Icon icon="ic:baseline-settings" class="setting-icon" />
                    设置
                  </el-dropdown-item>
                  <el-dropdown-item @click="logout">
                    <Icon
                      icon="ic:round-power-settings-new"
                      class="logout-icon"
                    />
                    退出登录
                  </el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </el-menu-item>
        </div>

        <div v-else class="right-end-header-div-not-authenticated">
          <el-menu-item index="/signin" @click="navigateToSignin">
            <span class="signin-span"> 登录 </span>
          </el-menu-item>

          <el-menu-item index="/register">
            <router-link to="/register">
              <el-button type="primary" class="register-button">
                注册
              </el-button>
            </router-link>
          </el-menu-item>
        </div>
      </el-menu>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, watch, defineProps } from 'vue'
import { useRouter } from 'vue-router'
import userApi from '@/api/user'
import { usePermissionStore } from '@/store/permission'
import { Search } from '@element-plus/icons-vue'
import logoPng from '@/assets/logo.pic.jpg'
import AvatarComponent from '@/components/AvatarComponent.vue'
import { useArticleStore } from '@/store/article'
import { Icon } from '@iconify/vue'
import { useUserInformationStore } from '@/store/userInformation'
import { useUserStore } from '@/store/user'
import to from 'await-to-js'
import { useProfileStore } from '@/store/profile'
import { useEditorStore } from '@/store/editor'

const userInformationStore = useUserInformationStore()
const permissionStore = usePermissionStore()
const articleStore = useArticleStore()
const userStore = useUserStore()
const router = useRouter()
const profileStore = useProfileStore()
const editorStore = useEditorStore()

const props = defineProps({
  isCustomPage: {
    type: Boolean,
    default: false,
  },
  isErrorPage: {
    type: Boolean,
    default: false,
  },
})

const isAuthenticated = ref(permissionStore.token !== '')
// 监听permissionStore，本地有token即已登录
watch(
  () => permissionStore.token,
  (newToken) => {
    isAuthenticated.value = newToken !== ''
  },
)

const nickname = ref(userInformationStore.nickname)
watch(
  () => userInformationStore.nickname,
  (newNickname) => {
    nickname.value = newNickname
  },
)

const avatarLink = ref(userInformationStore.getAvatarLink)
//监听store中头像链接的变化，如果发生改变，则同步更新为新头像
watch(
  () => userInformationStore.avatarLink,
  (newLink) => {
    avatarLink.value = newLink ? newLink : avatarLink.value
  },
)

/**
 * 文章分类下拉菜单跳转
 */
const articleCategoryRoute = async (index: number) => {
  //TODO:页面全部实现后修改每个case对应跳转到路径
  switch (index) {
    case 0: {
      await router.push({ path: '/' })
      break
    }
    case 1: {
      await router.push({ path: '/' })
      break
    }
    case 2: {
      await router.push({ path: '/' })
      break
    }
    case 3: {
      await router.push({ path: '/' })
      break
    }
    default: {
      await router.push({ path: '/' })
      break
    }
  }
}

/**
 * 导航栏左边 非下拉菜单跳转
 */
const menuItemRoute = async (index: number) => {
  //TODO:页面全部实现后修改每个case对应跳转到路径
  switch (index) {
    case 0: {
      await router.push({ path: '/' })
      break
    }
    case 1: {
      await router.push({ path: '/' })
      break
    }
    case 2: {
      await router.push({ path: '/' })
      break
    }
    case 3: {
      await router.push({ path: '/' })
      break
    }
    default: {
      await router.push({ path: '/' })
      break
    }
  }
}

/**
 * profile下拉菜单跳转
 */
const profileRoute = async (index: number) => {
  switch (index) {
    //跳转个人主页
    case 0: {
      await router.push({ path: `/pro/${userStore.getUserId}` })
      break
    }
    //跳转设置页
    case 1: {
      await router.push({ path: '/' })
      break
    }
    default: {
      await router.push({ path: '/' })
      break
    }
  }
}

/**
 * 跳转到editor
 * 之前清空article中编辑状态
 */
const navigateToEditor = async () => {
  articleStore.article.isBeingEdited = false
  await router.push({
    path: '/editor',
  })
}

/**
 * 登入
 */
const navigateToSignin = async () => {
  await router.push({ path: '/signin' })
}

/**
 * 登出并清空本地数据，并回到首页
 */
const logout = async () => {
  const [error, resultData] = await to(userApi.logout())
  userStore.$reset()
  userInformationStore.$reset()
  permissionStore.$reset()
  articleStore.$reset()
  profileStore.$reset()
  editorStore.$reset()
  if (error) {
    await router.replace('/error')
  } else {
    await router.replace('/')
  }
}

// 搜索词
const searchText = ref('')
const googleSearchPrefix = 'https://www.google.com/search?q='
const googleSearchQueryPrefix = `site:atomeocean.com`

/**
 * 将搜索词放进Google搜索
 */
const searchGoogle = () => {
  if (searchText.value === '') return

  const googleSearchText = googleSearchQueryPrefix + searchText.value
  window.open(googleSearchPrefix + googleSearchText, '_blank', 'noreferrer')
}
</script>

<style lang="scss" scoped>
.navigation-div {
  border-right: none;
  border-left: none;
  border-bottom: 1px solid $gray-100;
  display: flex;
  flex-direction: row;
  align-items: inherit;
  justify-content: center;
  width: 100%;
  height: 56px;
  background-color: white;

  .navigation-bar-container {
    width: 1280px;
    height: 56px;
  }

  .el-menu * {
    font-weight: 400;
    font-size: 16px;
    line-height: 28px;
    font-family: $text-font-family;
    font-style: normal;
    color: $text-color-neutral;
  }

  .el-menu {
    flex: 1;
    justify-content: space-between;
    width: 1280px;
    height: 56px;
    background-color: white;
    border: none;
    text-align: center;
    color: $text-color-neutral;

    .el-menu-item {
      &:hover {
        color: $logo-blue-dark;
        background-color: white;
      }

      &.is-active {
        border: none;
        background-color: white;
        color: $text-color-neutral !important;
      }
    }
  }

  .el-image {
    width: 60px;
    height: 42px;
  }

  .search-bar-div {
    position: relative;
    margin-left: 49px;
    display: flex;
    align-items: center;
    padding-right: 30px;
    padding-left: 0px;
    box-sizing: border-box;
    width: 281px;
    height: 39px;

    :deep(.el-input__wrapper) {
      border: 1px solid #f6f6f6;
      border-radius: 50px;
      background-color: #fafafa;
      background-image: url('../assets/icon_search.png');
      background-repeat: no-repeat;
      background-position: bottom 7px left 12px;
      background-size: 17.6px 17.58px;

      svg {
        display: none;
      }
    }

    :deep(.el-input__wrapper .el-input__inner) {
      color: $text-color-neutral;
    }
  }

  .right-end-header-div-authenticated {
    display: flex;
    align-items: center;
    padding-bottom: 2px;

    .el-menu-item {
      &:hover {
        color: $logo-blue-dark;
        background-color: white;

        svg {
          color: $logo-blue-dark;
        }
      }

      &.is-active {
        color: $logo-blue-bright !important;
        border: none;
        background-color: white;

        svg {
          color: $logo-blue-bright;
        }
      }
    }

    .write-idea {
      display: none;
    }

    .write-article {
      font-size: 14px;

      svg {
        width: 22px;
        height: 24px;
        padding-top: 2px;
        padding-right: 7.5px;
      }
    }

    .user-sub-menu {
      .avatar-title {
        padding-left: 0;
        padding-right: 10%;
        display: flex;
        align-items: center;

        // 头像旁边的箭头
        .avatar-dropdown-arrow {
          height: 26px;
          width: 26px;
          left: 15%;
          border-radius: 0px;
        }
      }

      :global(.avatar-dropdown .el-dropdown-menu__item) {
        font-family: $text-font-family;
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 28px;
        color: $text-color-neutral;
      }

      :global(.avatar-dropdown .el-dropdown-menu__item:hover) {
        background-color: white !important;
        color: $logo-blue-dark;
      }
    }
  }

  .right-end-header-div-not-authenticated {
    display: flex;
    align-items: center;

    .signin-span {
      font-weight: 500;
    }

    .register-button {
      background-color: $logo-blue-bright;
      border-radius: 6px;
      font-weight: 500;
      color: white;

      &:hover {
        background-color: $logo-blue-bright;
        color: white;
      }

      :deep(span) {
        &:hover {
          background-color: $logo-blue-bright;
          color: white;
        }
      }
    }
  }

  .el-dropdown {
    .article-category-span {
      outline: none !important;

      &:hover {
        color: $logo-blue-dark;
      }
    }

    :global(.article-category-dropdown .el-dropdown-menu__item) {
      font-family: $text-font-family;
      font-style: normal;
      font-weight: 400;
      font-size: 16px;
      line-height: 28px;
      letter-spacing: 0.05em;
      color: $text-color-neutral;
    }

    :global(.article-category-dropdown .el-dropdown-menu__item:hover) {
      background-color: white !important;
      color: $logo-blue-dark;
    }
  }
}

.user-icon {
  width: 16px;
  height: 17.07px;
  position: relative;
  top: 0.75px;
  padding-right: 5px;
}

.setting-icon {
  width: 18.68px;
  height: 19.2px;
  position: relative;
  top: 1px;
  padding-right: 5px;
}

.logout-icon {
  width: 18px;
  height: 17.99px;
  position: relative;
  top: 1px;
  padding-right: 5px;
}

/* 去掉router-link 里面文字的下划线 */
a {
  text-decoration: none;
  color: $text-color-neutral;

  &:hover {
    color: $logo-blue-dark;
  }
}
</style>
