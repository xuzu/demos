<template>
  <div class="header">
    <div class="background-container">
      <img
        id="background-img"
        :src="backgroundImageLink"
        alt="Background Image"
      />
    </div>
    <div class="header-content-container">
      <div class="avatar-container">
        <AvatarComponent
          :avatar-src="profileStore.getAvatarLink"
          :avatar-height="136"
          :avatar-width="136"
        />
      </div>
      <div
        class="report-icon-container"
        v-show="!props.isCurrentUser"
        @click="toggleShowReportContainer"
      >
        <Icon icon="material-symbols:more-horiz" class="report-icon" />
      </div>
      <div
        class="report-container-content"
        v-show="showReportContainer"
        @click="openReportDialog"
      >
        报告不当内容
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { useProfileStore } from '@/store/profile'
import { ElMessage } from 'element-plus'
import { ref, defineProps } from 'vue'
import { Icon } from '@iconify/vue'
import AvatarComponent from '@/components/AvatarComponent.vue'

const props = defineProps({
  isCurrentUser: {
    type: Boolean,
  },
})

const profileStore = useProfileStore()
const backgroundImageLink = ref(profileStore.getBackgroundImageLink)

// 举报
const showReportContainer = ref(false)
const toggleShowReportContainer = () => {
  showReportContainer.value = !showReportContainer.value
}
const openReportDialog = () => {
  // placeholder (实现Report dialog之后删掉此msg)
  ElMessage.success('举报成功')
}
</script>

<style lang="scss" scoped>
.header {
  width: 100%;
  max-width: $profile-width;
  height: 200px;
  border-bottom: 1px solid $gray-100;
  display: flex;
  align-items: flex-end;
  flex-direction: row;
  justify-content: space-between;
  position: relative;
  flex-shrink: 0;

  .background-container {
    position: absolute;
    height: 200px;
    width: $profile-width;

    #background-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
  }

  .header-content-container {
    display: flex;
    flex-direction: row;
    align-items: flex-end;
    justify-content: space-between;
    width: 100%;
    position: absolute;

    .avatar-container {
      display: flex;
      justify-content: center;
      align-items: center;
      position: relative;
      top: 53px;
      left: 70px;
      z-index: 1;
      border-radius: 50%;
      border: 4px solid $background-white;
    }

    .report-icon-container {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 37px;
      height: 37px;
      border-radius: 37px;
      background: $gray-900-50;
      margin-right: 16px;
      margin-bottom: 12px;
      cursor: pointer;

      .report-icon {
        width: 24px;
        height: 24px;
        color: white;
      }
    }

    .report-container-content {
      font-size: 14px;
      font-weight: 500;
      line-height: 28px;
      width: 104px;
      height: 36px;
      border: 1px solid $gray-100;
      box-shadow: 4px 4px 4px 0px rgba(0, 0, 0, 0.25);
      background-color: $background-white;
      display: flex;
      align-items: center;
      justify-content: space-around;
      z-index: 3000;
      position: absolute;
      top: 115px;
      left: 1100px;
    }
  }
}
</style>
