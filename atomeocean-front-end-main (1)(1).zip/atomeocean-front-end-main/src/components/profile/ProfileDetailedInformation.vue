<template>
  <div class="detail-information" :class="{ blurring: props.hasNoVisibility }">
    <div v-show="props.hasNoVisibility" class="blocked-content"></div>
    <div class="progress" v-show="props.isCurrentUser">
      <div class="profile-completeness text-2-regular">
        完善详细资料，获得更多关注与机会：
        <div class="edit-button-2">
          <Icon
            icon="mdi:account-edit-outline"
            class="edit-profile-icon"
            @click="openProfileEditor('1')"
          />
          <ProfileEditorDialogView
            v-if="isProfileEditorOpen"
            @close="toggleProfileEditorOpen"
            :activeIndexProps="activeMenuItemIndex"
          ></ProfileEditorDialogView>
        </div>
      </div>
      <div class="progress-bar-container">
        <el-progress
          :percentage="profileStore.getProfileCompleteness"
          :stroke-width="17"
        />
      </div>
    </div>

    <div class="self-introduction">
      <div class="section-header text-2-regular">自我介绍</div>
      <div class="self-introduction-content">
        {{ profileStore.getSelfIntroduction }}
      </div>
    </div>
    <div
      class="work-experience"
      v-show="
        props.isCurrentUser || profileStore.careerExperience?.length !== 0
      "
    >
      <div class="section-header text-2-regular">职业经历</div>
      <el-timeline>
        <el-timeline-item
          v-for="experience in profileStore.careerExperience"
          :key="experience.careerId"
        >
          <div class="job text-1-medium">{{ experience.position }}</div>
          <div class="date" v-if="experience.isCompleted">
            {{ experience.startDate?.slice(0, 4) }} 年
            {{ experience.startDate?.slice(5, 7) }} 月 -
            {{ experience.endDate?.slice(0, 4) }} 年
            {{ experience.endDate?.slice(5, 7) }} 月
          </div>
          <div class="date" v-else>
            {{ experience.startDate?.slice(0, 4) }} 年
            {{ experience.startDate?.slice(5, 7) }} 月 至今
          </div>
          <div class="company-name">
            {{ experience.companyName }}
          </div>
        </el-timeline-item>
      </el-timeline>
    </div>

    <div
      class="education-experience"
      v-show="
        props.isCurrentUser || profileStore.educationExperience?.length !== 0
      "
    >
      <div class="section-header text-2-regular">教育背景</div>
      <div
        class="experience-contents"
        v-for="experience in profileStore.educationExperience"
        :key="experience.educationId"
      >
        <div class="degree text-1-medium">
          {{ DEGREE_LEVEL[Number(experience.degreeLevel)].label }} in
          {{ experience.major }}
        </div>
        <div class="date" v-if="experience.isCompleted">
          {{ experience.startDate?.slice(0, 4) }} 年 -
          {{ experience.endDate?.slice(0, 4) }} 年
        </div>
        <div class="date" v-else>
          {{ experience.startDate?.slice(0, 4) }} 年 至今
        </div>
        <div class="institution-name">
          {{ experience.institutionName }}
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, defineProps } from 'vue'
import ProfileEditorDialogView from '@/views/ProfileEditorDialogView.vue'
import { useProfileStore } from '@/store/profile'
import { Icon } from '@iconify/vue'
import { DEGREE_LEVEL } from '@/constant/detailedInformationConstant'

const props = defineProps({
  isCurrentUser: {
    type: Boolean,
    required: true,
  },
  hasNoVisibility: {
    type: Boolean,
    required: true,
  },
})

const profileStore = useProfileStore()

// 点击进入编辑个人页组建
const isProfileEditorOpen = ref(false)
const activeMenuItemIndex = ref('0')
const openProfileEditor = (index: string) => {
  isProfileEditorOpen.value = true
  activeMenuItemIndex.value = index
}
const toggleProfileEditorOpen = () => {
  isProfileEditorOpen.value = !isProfileEditorOpen.value
}
</script>

<style lang="scss" scoped>
.detail-information {
  box-sizing: border-box;
  padding-top: 24.5px;
  padding-left: 47px;
  display: flex;
  flex-direction: column;

  .progress {
    margin-bottom: 25px;
    .profile-completeness {
      display: flex;
      flex-direction: row;
      justify-content: space-between;

      .edit-button-2 {
        display: flex;
        margin-right: 17px;
      }
    }
    .progress-bar-container {
      .el-progress {
        display: flex;
        gap: 11px;
        width: 205px;

        :deep(.el-progress__text) {
          font-size: 14px;
          font-family: $text-font-family;
          line-height: 28px;
          color: black;
        }

        :deep(.el-progress-bar__outer) {
          border: 1px solid $gray-700;
          border-radius: 20px;
          background: transparent;
          width: 205px;
          padding-left: 2.9px;
          padding-right: 2.9px;
        }

        :deep(.el-progress-bar__inner) {
          background-color: $blue-700;
          border-radius: 20px;
          height: 12px;
          position: relative;
          top: 2.6px;
        }
      }
    }
  }

  .section-header {
    color: $gray-500;
  }

  .self-introduction {
    display: flex;
    flex-direction: column;
    gap: 16px;
    margin-bottom: 32px;

    .self-introduction-content {
      font-size: 16px;
      font-family: $text-font-family;
      font-weight: 350;
      line-height: 28px;
      color: $text-color-neutral;
      word-wrap: break-word;
      padding-right: 30px;
    }
  }

  .work-experience {
    display: flex;
    flex-direction: column;
    gap: 12px;
    margin-bottom: 32px;

    .el-timeline {
      padding-left: 0px;
    }

    :deep(.el-timeline-item) {
      padding-bottom: 0px;
    }

    :deep(.el-timeline-item__content) {
      display: flex;
      flex-direction: column;
      gap: 8px;
      color: $text-color-neutral;
    }

    :deep(.el-timeline-item__wrapper) {
      padding-left: 16px;
      position: relative;
      top: 0px;
    }

    :deep(.el-timeline-item__node) {
      background-color: $gray-300;
      width: 8px;
      height: 8px;
      margin-left: -8px;
      margin-top: 10px;
    }

    :deep(.el-timeline-item__tail) {
      border-left: 1px solid $gray-300;
      left: -6px;
      height: 100%;
      margin-top: 18px;
    }

    :deep(.el-timeline-item:last-child .el-timeline-item__tail) {
      display: flex;
      height: 75%;
    }
  }

  .education-experience {
    display: flex;
    flex-direction: column;
    gap: 12px;
    .experience-contents {
      display: flex;
      flex-direction: column;
      gap: 8px;
      color: $text-color-neutral;
    }
  }

  .date,
  .institution-name,
  .company-name {
    font-family: $text-font-family;
    font-size: 16px;
    font-weight: 350;
    line-height: 28px;
  }

  .edit-profile-icon {
    width: 32px;
    height: 32px;
    color: $gray-500;
    cursor: pointer;
  }
}

.blurring {
  filter: blur(10px);
}
.blocked-content {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 9999;
}
</style>
