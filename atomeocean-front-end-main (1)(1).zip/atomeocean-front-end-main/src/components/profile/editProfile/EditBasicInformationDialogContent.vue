<template>
  <div class="text-medium">
    <div class="header">修改基本资料</div>
    <div class="content-box">
      <div class="avatar-bio">
        <AvatarComponent
          :avatar-src="avatarLink"
          :avatar-height="90"
          :avatar-width="90"
        />
        <div class="user-description">
          <div class="user-name">{{ userInformationStore.getNickname }}</div>
          <div class="user-title">{{ userInformationStore.getMotto }}</div>
        </div>
      </div>
      <div class="changes-btn">
        <el-popover
          ref="avatarPopover"
          popper-class="upload-file-popover"
          trigger="click"
          @hide="hideCropper"
        >
          <template #reference>
            <el-button>修改头像</el-button>
          </template>
          <el-upload
            ref="originalAvatarFile"
            :auto-upload="false"
            :limit="1"
            :on-change="onSelectAvatarFile"
            :show-file-list="false"
            class="upload-popover-div"
          >
            <template #trigger>
              <el-button class="select-file-button">选择文件</el-button>
            </template>
            <div class="upload-tip">
              请选择jpg，jpeg或png格式的文件，文件最大为1MB。
            </div>
          </el-upload>
          <CropperEditor
            v-show="showAvatarCropper"
            :img="cropperAvatarImg"
            @update:hide-cropper="hideCropper"
            @save-cropped-img="sendCroppedImg"
          />
        </el-popover>

        <!--              TODO: 实现修改背景图功能-->
        <!--                <el-popover popper-class="upload-file-popover" trigger="click">-->
        <!--                    <template #reference>-->
        <!--                        <el-button class="change-background-button">修改背景图</el-button>-->
        <!--                    </template>-->
        <!--                    <el-upload -->
        <!--                        ref="backgroundImageFile"-->
        <!--                        :before-upload="beforeBackgroundImageFileUpload" -->
        <!--                        :auto-upload="false" -->
        <!--                        :limit="1" -->
        <!--                        :on-change="onSelectBackgroundImageFile"-->
        <!--                        :show-file-list="true"-->
        <!--                        class="upload-popover-div"-->
        <!--                    >-->
        <!--                    <template #trigger>                 -->
        <!--                        <el-button  class="select-file-button">选择文件</el-button> -->
        <!--                        <div v-if="!selectedBackgroundImageFile" class="select-file-text">请选择文件</div>  -->
        <!--                    </template>-->
        <!--                    <div class="upload-tip">-->
        <!--                        请选择jpg或png格式的文件，文件最大为800K。-->
        <!--                    </div>-->
        <!--                    <el-button v-if="selectedBackgroundImageFile" @click="uploadBackgroundImageFile">上传文件</el-button>-->
        <!--                    <el-button v-else class="upload-file-button-disabled">上传文件</el-button>-->
        <!--                    </el-upload>   -->
        <!--                </el-popover>  -->
      </div>
      <div class="change-name">
        <div class="section-title">修改名字</div>
        <el-input v-model="newNameData"></el-input>
        <div class="section-tips">*每60天只能修改一次名字</div>
        <el-button @click="saveNewName">保存修改</el-button>
      </div>
      <div class="change-bio">
        <div class="section-title">修改简介</div>
        <el-input v-model="newMotto" maxlength="20"></el-input>
        <div class="section-tips">请用一句话介绍自己，最多20字。</div>
        <el-button @click="saveNewMotto">保存修改</el-button>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { useUserInformationStore } from '@/store/userInformation'
import { ElMessage, UploadInstance, UploadProps } from 'element-plus'
import { ref, watch } from 'vue'
import to from 'await-to-js'
import CropperEditor from '@/components/CropperEditor.vue'
import { encryptMD5 } from '@/utils/crypto'
import {
  FILE_LOAD_FAILED,
  REQUEST_TOO_OFTEN,
  UPDATE_SUCCESS,
  USER_NOT_EXIST,
} from '@/constant/userInformationMessageConstant'
import { load } from '@/utils'
import { AxiosError } from 'axios'
import { useRouter } from 'vue-router'
import { FILE_UPLOAD_FAILED } from '@/constant/FileOperationMessageConstant'
import { usePermissionStore } from '@/store/permission'
import { useArticleStore } from '@/store/article'
import { UPLOADING } from '@/constant/loadingConstant'
import { useProfileStore } from '@/store/profile'
import AvatarComponent from '@/components/AvatarComponent.vue'

// 获取用户名和其他信息
// TODO: 添加到template里，取代Momo, Front End Developer, 头像src
const userInformationStore = useUserInformationStore()
const profileStore = useProfileStore()

// 用户上传文件
const originalAvatarFile = ref<UploadInstance>()
//该变量用于保存用户上传的文件在浏览器中的相对路径
const cropperAvatarImg = ref<any>()
const showAvatarCropper = ref(false)
const avatarPopover = ref()
const router = useRouter()
const permissionStore = usePermissionStore()
const articleStore = useArticleStore()
const avatarLink = ref(userInformationStore.getAvatarLink)

//监听store中头像链接的变化，如果发生改变，则同步更新为新头像
watch(
  () => userInformationStore.avatarLink,
  (newLink) => {
    avatarLink.value = newLink ? newLink : avatarLink.value
  },
)

// 用户在选择头像文件时触发
const onSelectAvatarFile = (file: any) => {
  //检查文件类型和大小
  const { raw } = file
  const allowedTypes = ['image/jpg', 'image/jpeg', 'image/png']
  const maxSize = 1
  if (!allowedTypes.includes(raw.type)) {
    ElMessage.error('文件必须是jpg或png的格式')
    originalAvatarFile.value?.clearFiles()
    return
  } else if (raw.size / 1024 / 1024 > maxSize) {
    ElMessage.error(`文件大小不能超过${maxSize}MB`)
    originalAvatarFile.value?.clearFiles()
    return
  }
  //打开图片裁剪界面
  openCropper(raw)
}

//触发后读取文件，并打开图片剪切界面
function openCropper(file: File) {
  const reader = new FileReader()
  //为file reader设置监听函数，触发后执行
  reader.onload = (e) => {
    let data
    if (
      e &&
      e.target &&
      e.target.result &&
      typeof e.target.result === 'object'
    ) {
      // 把Array Buffer转化为blob 如果是base64不需要
      data = window.URL.createObjectURL(new Blob([e.target.result]))
    } else if (e && e.target && e.target.result) {
      data = e.target.result
    }
    //为cropper弹窗设置image-url(data)
    cropperAvatarImg.value = data
  }
  //读取图片，触发上面定义的监听函数
  reader.readAsArrayBuffer(file)
  //打开cropper弹窗
  showAvatarCropper.value = true
}

//隐藏剪裁界面
const hideCropper = () => {
  //隐藏剪裁板
  showAvatarCropper.value = false
  //清除cropperImg的值
  cropperAvatarImg.value = ''
  //清空当前组件上传的文件
  originalAvatarFile.value?.clearFiles()
}

//子组件传递回剪裁后的图片，计算图片md5并发送请求
const sendCroppedImg = async (croppedImg: Blob) => {
  //隐藏popover
  avatarPopover.value.hide()
  //隐藏剪裁界面
  hideCropper()

  let md5Hash
  try {
    //计算剪切后图片的md5值
    md5Hash = await encryptMD5(croppedImg)
  } catch (error) {
    ElMessage.error(FILE_LOAD_FAILED)
    return
  }

  //构造参数
  const params = new FormData()
  const extension = croppedImg.type === 'image/jpeg' ? '.jpg' : '.png'
  const fileName = 'avatar' + extension
  params.append('avatar', croppedImg, fileName)
  params.append('hash', md5Hash)

  //添加loading动画
  load.show(UPLOADING)
  //发送请求
  const [error, resultData] = await to(
    userInformationStore.updateAvatar(params),
  )
  //关闭加载动画
  load.hide()

  //网络请求异常
  if (error) {
    const errorMessage = (error as AxiosError).message
    ElMessage.error(errorMessage)
    await router.replace('/error')
  } else if (resultData) {
    switch (resultData.status) {
      //修改成功
      case 100: {
        ElMessage.success(UPDATE_SUCCESS)
        userInformationStore.setAvatar(resultData.data)
        profileStore.setAvatar(resultData.data)
        break
      }
      //上传失败
      case 1017: {
        ElMessage.error(FILE_UPLOAD_FAILED)
        break
      }
      //账号信息异常，退出登录状态
      default:
        break
    }
  }
}

// 修改背景图
// TODO: 需要修改上传的obj
const backgroundImageFile = ref<UploadInstance>()
const selectedBackgroundImageFile = ref(false)
const uploadBackgroundImageFile = () => {
  // TODO: 调用后端api
  backgroundImageFile.value?.submit()
}

// 提交文件前的检查
const beforeBackgroundImageFileUpload: UploadProps['beforeUpload'] = (
  rawFile,
) => {
  const allowedTypes = ['image/jpeg', 'image/png']
  const maxSize = 800
  if (!allowedTypes.includes(rawFile.type)) {
    ElMessage.error('文件必须是jpg或png的格式!')
    selectedBackgroundImageFile.value = false
    return false
  } else if (rawFile.size / 1024 > maxSize) {
    ElMessage.error(`文件大小不能超过${maxSize}K!`)
    selectedBackgroundImageFile.value = false
    return false
  }
  return true
}

// 上传, 提交文件都会触发
const onSelectBackgroundImageFile = () => {
  selectedBackgroundImageFile.value = !selectedBackgroundImageFile.value
}

// 修改名字
const newNameData = ref('')
const saveNewName = async () => {
  // TODO:  用户名限制长度
  if (newNameData.value) {
    const [error, resultData] = await to(
      userInformationStore.modifyNickname(newNameData.value),
    )

    //网络请求异常
    if (error) {
      const errorMessage = (error as AxiosError).message
      ElMessage.error(errorMessage)
      await router.replace('/error')
    } else if (resultData) {
      switch (resultData.status) {
        //修改成功
        case 100: {
          userInformationStore.setNickname(newNameData.value)
          profileStore.setNickname(newNameData.value)
          newNameData.value = ''
          ElMessage.success(UPDATE_SUCCESS)
          break
        }
        //用户不存在
        case 1015: {
          ElMessage.error(USER_NOT_EXIST)
          break
        }
        //修改时间少于60天
        case 1022: {
          ElMessage.error(REQUEST_TOO_OFTEN)
          break
        }
        //账号信息异常，退出登录状态
        default:
          break
      }
    }
  }
}

// 修改简介
const newMotto = ref('')
const saveNewMotto = async () => {
  // TODO: 描述限制长度
  if (newMotto.value) {
    const [error, resultData] = await to(
      userInformationStore.modifyMotto(newMotto.value),
    )

    //网络请求异常
    if (error) {
      const errorMessage = (error as AxiosError).message
      ElMessage.error(errorMessage)
      await router.replace('/error')
    } else if (resultData) {
      switch (resultData.status) {
        //修改成功
        case 100: {
          userInformationStore.setMotto(newMotto.value)
          profileStore.setMotto(newMotto.value)
          newMotto.value = ''
          ElMessage.success(UPDATE_SUCCESS)
          break
        }
        //用户不存在
        case 1015: {
          ElMessage.error(USER_NOT_EXIST)
          break
        }
        //账号信息异常，退出登录状态
        default:
          break
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.header {
  font-size: 16px;
  color: $blue-900;
}
.content-box {
  margin: 29px 103px 0px 22px;
}
.avatar-bio {
  display: flex;
  align-items: start;
  margin-bottom: 41px;

  .user-description {
    margin-left: 23.18px;
    margin-top: 23px;
    color: #000000;
    .user-name {
      font-weight: 700;
      font-size: 16px;
    }
    .user-title {
      font-weight: 350;
      font-size: 16px;
      margin-top: -5px;
    }
  }
}

.changes-btn {
  .change-background-button {
    width: 100px;
    margin-left: 34px;
  }
}

.change-name,
.change-bio {
  margin-top: 41px;
  .section-title {
    font-size: 16px;
    color: $gray-700;
    padding-bottom: 8px;
  }

  :deep(.el-input__wrapper) {
    border-radius: 0;
    padding: 0;
    border-color: $gray-500;
    border-bottom: 1px solid $gray-500;
    box-shadow: none;
  }
  :deep(.el-input__inner) {
    font-family: $text-font-family;
    font-weight: 500;
    font-size: 16px;
    line-height: 28px;
    color: $text-color-neutral;
  }
  .section-tips {
    font-size: 14px;
    color: $text-color-disabled;
    padding-top: 4px;
    padding-bottom: 8px;
  }
}

.upload-popover-div {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  font-family: $text-font-family;
  font-style: normal;

  .select-file-text {
    margin-left: 12px;
    font-weight: 400;
    font-size: 14px;
    line-height: 28px;
    color: $text-color-neutral;
  }
  .select-file-button {
    width: 76px;
    height: 30px;
    border: 1px solid $text-color-disabled;
    border-radius: 3px;
    background: transparent;
    color: #000000;
    font-weight: 400;
  }
  .upload-file-button-disabled {
    background-color: $text-color-disabled;
  }
  .upload-tip {
    font-weight: 400;
    font-size: 14px;
    line-height: 28px;
    color: #000000;
    padding-top: 14px;
    margin-bottom: 11px;
  }

  // file list的位置
  :deep(.el-upload-list) {
    position: absolute;
    bottom: 122px;
    left: 100px;
    width: 150px;
    background-color: transparent;
  }

  // file list名字
  :deep(.el-upload-list__item-name) {
    font-weight: 400;
    font-size: 14px;
    line-height: 28px;
    color: $text-color-neutral;
    background: transparent;
    .el-icon {
      display: none;
    }
  }

  :deep(.el-upload-list__item:hover) {
    background: transparent;
  }
}
// 按钮的基本样式，可以写class override
.el-button {
  font-family: $text-font-family;
  font-style: normal;
  font-weight: 500;
  font-size: 14px;
  line-height: 28px;
  background-color: $blue-900;
  color: white;
  border-radius: 6px;
  border: 0px;
  height: 34px;
  width: 87px;
  padding: 2px 24px;
}
</style>

<style lang="scss">
.el-popper.upload-file-popover {
  transform: translate(65px, -70px);
  min-width: 257px;
  height: 175px;
  background-color: #ffffff;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border-radius: 0px;
  border: 0px;
  padding: 19px 13px 15px 20px;
  .el-popper__arrow {
    display: none;
  }
}
</style>
