<template>
  <div class="text-medium">
    <div class="header">完善详细信息，获得更多关注和机会。</div>
    <div class="content-box">
      <div class="change-self-intro-container">
        <div class="change-self-intro-header">修改自我介绍（不超过300字）</div>
        <el-input
          v-model="newSelfIntroduction"
          type="textarea"
          maxlength="300"
        ></el-input>
        <el-button @click="saveNewSelfIntroduction">保存修改</el-button>
        <el-button class="cancel-button" @click="resetTextInput"
          >放弃修改</el-button
        >
      </div>

      <div class="work-experience-container">
        <div class="experience-container-header">职业经历</div>
        <div
          class="experience-contents"
          v-for="experience in profileStore.careerExperience"
          :key="experience.careerId"
        >
          <div class="first-row-container">
            <div class="job-or-degree">{{ experience.position }}</div>
            <div class="modify-experience-content">
              <el-popconfirm
                popper-class="delete-confirmation-popup"
                confirm-button-text="确定"
                cancel-button-text="取消"
                title="确定删除此经历？"
                :hide-icon="true"
                @confirm="deleteCareerExperience(experience.careerId || '')"
              >
                <template #reference>
                  <div class="delete-text">删除</div>
                </template>
              </el-popconfirm>
              <div class="modify-text" @click="openCareerPopover(experience)">
                修改
              </div>
            </div>
          </div>
          <div class="date" v-if="experience.isCompleted">
            {{ experience.startDate?.slice(0, 4) }} 年
            {{ experience.startDate?.slice(5, 7) }} 月 至
            {{ experience.endDate?.slice(0, 4) }} 年
            {{ experience.endDate?.slice(5, 7) }} 月
          </div>
          <div class="date" v-else>
            {{ experience.startDate?.slice(0, 4) }} 年
            {{ experience.startDate?.slice(5, 7) }} 月 至今
          </div>
          <div class="company-or-university">
            {{ experience.companyName }}
          </div>
        </div>

        <el-popover
          popper-class="add-experience-popover"
          trigger="manual"
          v-model="newCareerExperience"
          v-model:visible="careerPopoverVisible"
        >
          <template #reference>
            <div class="add-experience" @click="openCareerPopover(null)">
              <Icon icon="carbon:add-filled" class="add-icon" />添加职业经历
            </div>
          </template>
          <div class="row-container-in-popover">
            <div>职位</div>
            <div>
              <el-input v-model="newCareerExperience.position"></el-input>
            </div>
          </div>
          <div class="row-container-in-popover">
            <div>公司</div>
            <div>
              <el-input v-model="newCareerExperience.companyName"></el-input>
            </div>
          </div>
          <div class="date-container-in-popover">
            <div class="start-date">
              <div>起始</div>
              <el-date-picker
                v-model="newCareerExperience.startDate"
                type="month"
                format="YYYY年MM月"
                value-format="YYYY-MM-DD"
                :teleported="false"
                :clearable="false"
              />
            </div>
            <div class="end-date">
              <div class="disabled-text">结束</div>
              <div
                v-if="!newCareerExperience.isCompleted"
                class="dash-not-completed"
              >
                ---------------
              </div>
              <div class="year-and-month-container" v-else>
                <el-date-picker
                  v-model="newCareerExperience.endDate"
                  type="month"
                  format="YYYY年MM月"
                  value-format="YYYY-MM-DD"
                  :teleported="false"
                  :clearable="false"
                />
              </div>
            </div>
            <div class="check-box">
              <el-checkbox
                v-model="isCareerChecked"
                @Change="toggleCareerIsCompleted"
              />至今
            </div>
          </div>
          <div class="btns-in-popover">
            <el-button
              class="popover-add-btn"
              @click="saveOrUpdateCareerExperience"
              >添加</el-button
            >
            <el-button
              class="popover-cancel-btn"
              @click="resetNewCareerExperience"
              >放弃</el-button
            >
          </div>
        </el-popover>
      </div>

      <div class="education-experience-container">
        <div class="experience-container-header">教育经历</div>
        <div
          class="experience-contents"
          v-for="experience in profileStore.educationExperience"
          :key="experience.educationId"
        >
          <div class="first-row-container">
            <div class="job-or-degree">
              {{ DEGREE_LEVEL[Number(experience.degreeLevel)].label }} in
              {{ experience.major }}
            </div>
            <div class="modify-experience-content">
              <el-popconfirm
                popper-class="delete-confirmation-popup"
                confirm-button-text="确定"
                cancel-button-text="取消"
                title="确定删除此经历？"
                :hide-icon="true"
                @confirm="
                  deleteEducationExperience(experience.educationId || '')
                "
              >
                <template #reference>
                  <div class="delete-text">删除</div>
                </template>
              </el-popconfirm>
              <div
                class="modify-text"
                @click="openEducationPopover(experience)"
              >
                修改
              </div>
            </div>
          </div>
          <div class="date" v-if="experience.isCompleted">
            {{ experience.startDate?.slice(0, 4) }} 年
            {{ experience.startDate?.slice(5, 7) }} 月 至
            {{ experience.endDate?.slice(0, 4) }} 年
            {{ experience.endDate?.slice(5, 7) }} 月
          </div>
          <div class="date" v-else>
            {{ experience.startDate?.slice(0, 4) }} 年
            {{ experience.startDate?.slice(5, 7) }} 月 至今
          </div>
          <div class="company-or-university">
            {{ experience.institutionName }}
          </div>
        </div>

        <el-popover
          popper-class="add-experience-popover education"
          trigger="manual"
          v-model="newEducationExperience"
          v-model:visible="educationPopoverVisible"
        >
          <template #reference>
            <div class="add-experience" @click="openEducationPopover(null)">
              <Icon icon="carbon:add-filled" class="add-icon" />添加教育经历
            </div>
          </template>
          <div class="row-container-in-popover">
            <div>学校</div>
            <div>
              <el-input
                v-model="newEducationExperience.institutionName"
              ></el-input>
            </div>
          </div>
          <div class="row-degree-levels row-container-in-popover">
            <div class="degree-text">学位</div>
            <div class="degree-dropdown">
              <el-select
                v-model="newEducationExperience.degreeLevel"
                :teleported="false"
                placeholder="请选择学位"
              >
                <el-option
                  v-for="degree in DEGREE_LEVEL"
                  :key="degree.value"
                  :label="degree.label"
                  :value="degree.value"
                />
              </el-select>
            </div>
          </div>
          <div class="row-container-in-popover">
            <div>专业</div>
            <div>
              <el-input v-model="newEducationExperience.major"></el-input>
            </div>
          </div>
          <div class="date-container-in-popover">
            <div class="start-date">
              <div>起始</div>
              <div class="year-and-month-container">
                <el-date-picker
                  v-model="newEducationExperience.startDate"
                  type="month"
                  format="YYYY年MM月"
                  value-format="YYYY-MM-DD"
                  :teleported="false"
                  :clearable="false"
                />
              </div>
            </div>
            <div class="end-date">
              <div class="disabled-text">结束</div>
              <div
                v-if="!newEducationExperience.isCompleted"
                class="dash-not-completed"
              >
                ---------------
              </div>
              <div class="year-and-month-container" v-else>
                <el-date-picker
                  v-model="newEducationExperience.endDate"
                  type="month"
                  format="YYYY年MM月"
                  value-format="YYYY-MM-DD"
                  :teleported="false"
                  :clearable="false"
                />
              </div>
            </div>
            <div class="check-box">
              <el-checkbox
                v-model="isEducationChecked"
                @Change="toggleEducationIsCompleted"
              />至今
            </div>
          </div>

          <div class="btns-in-popover">
            <el-button
              class="popover-add-btn"
              @click="saveOrUpdateEducationExperience"
            >
              添加
            </el-button>
            <el-button
              class="popover-cancel-btn"
              @click="resetNewEducationExperience"
            >
              放弃
            </el-button>
          </div>
        </el-popover>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { reactive, ref, watchEffect } from 'vue'
import { Icon } from '@iconify/vue'
import { useUserInformationStore } from '@/store/userInformation'
import { useProfileStore } from '@/store/profile'
import { AxiosError } from 'axios'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import to from 'await-to-js'
import {
  UPDATE_SUCCESS,
  EXPERIENCE_EXISTED,
  EXPERIENCE_NOT_EXISTED,
  INVALID_INPUT,
  UNAUTHORIZED_ACCESS,
  USER_NOT_EXIST,
} from '@/constant/userInformationMessageConstant'
import { DEGREE_LEVEL } from '@/constant/detailedInformationConstant'
import { CareerExperience, EducationExperience } from '@/store/profile/types'
import dayjs from 'dayjs'

const userInformationStore = useUserInformationStore()
const profileStore = useProfileStore()
const router = useRouter()

// 自我介绍
const newSelfIntroduction = ref('')
const saveNewSelfIntroduction = async () => {
  // TODO: 描述限制长度
  if (newSelfIntroduction.value) {
    const [error, resultData] = await to(
      userInformationStore.modifySelfIntroduction(newSelfIntroduction.value),
    )

    //网络请求异常
    if (error) {
      const errorMessage = (error as AxiosError).message
      ElMessage.error(errorMessage)
      await router.replace('/error')
    } else if (resultData) {
      switch (resultData.status) {
        //修改成功
        case 100: {
          userInformationStore.setSelfIntroduction(newSelfIntroduction.value)
          profileStore.setSelfIntroduction(newSelfIntroduction.value)
          ElMessage.success(UPDATE_SUCCESS)
          resetTextInput()
          break
        }
        //用户不存在
        case 1015: {
          ElMessage.error(USER_NOT_EXIST)
          break
        }

        default:
          break
      }
    }
  }
}

const resetTextInput = () => {
  newSelfIntroduction.value = ''
}

/**
 * 职业经历
 */
const newCareerExperience = reactive({
  careerId: '',
  companyName: '',
  position: '',
  startDate: '',
  endDate: '',
  isCompleted: true,
})

// 更改isCompleted值 + 同步checkbox
const isCareerChecked = ref(!newCareerExperience.isCompleted)
watchEffect(() => {
  isCareerChecked.value = !newCareerExperience.isCompleted
})
const toggleCareerIsCompleted = () => {
  newCareerExperience.isCompleted = !newCareerExperience.isCompleted
}

// 打开编辑经历页面
const careerPopoverVisible = ref(false)
const openCareerPopover = (selectedExperience: CareerExperience | null) => {
  if (!selectedExperience) {
    resetNewCareerExperience()
  } else {
    Object.assign(newCareerExperience, selectedExperience)
  }
  careerPopoverVisible.value = !careerPopoverVisible.value
}

// 添加 或 修改当前职业经历
const saveOrUpdateCareerExperience = async () => {
  if (!validateNewCareerExperience()) {
    ElMessage.error(INVALID_INPUT)
    return
  }

  // 发送请求
  const [error, resultData] = await to(
    profileStore.saveOrUpdateCareerExperience(newCareerExperience),
  )

  //网络请求异常
  if (error) {
    const errorMessage = (error as AxiosError).message
    ElMessage.error(errorMessage)
    await router.replace('/error')
  } else if (resultData) {
    switch (resultData.status) {
      //修改成功
      case 100: {
        // 更新经历 -> 已经有careerId -> 先从store删除
        if (newCareerExperience.careerId) {
          profileStore.deleteCareerExperienceInStore(
            newCareerExperience.careerId,
          )
        }
        // 新的经历 -> careerId空 -> 把返回结果里的id添加到当前经历
        else {
          newCareerExperience.careerId = resultData.data
        }
        // 更新到store
        profileStore.addCareerExperienceInStore(newCareerExperience)
        // 重置表格
        resetNewCareerExperience()
        // 关闭表格
        careerPopoverVisible.value = false
        ElMessage.success(UPDATE_SUCCESS)
        break
      }
      //无权限
      case 1008: {
        ElMessage.error(UNAUTHORIZED_ACCESS)
        break
      }
      //用户不存在
      case 1015: {
        ElMessage.error(USER_NOT_EXIST)
        break
      }
      //经历已存在
      case 1020: {
        ElMessage.error(EXPERIENCE_EXISTED)
        break
      }
      //经历不存在
      case 1021: {
        ElMessage.error(EXPERIENCE_NOT_EXISTED)
        break
      }

      default:
        break
    }
  }
}

const validateNewCareerExperience = () => {
  // 检查有没有输入对应的资料
  if (!newCareerExperience.companyName || !newCareerExperience.position) {
    return false
  }
  // 检查起始 结束时间
  const startDate = dayjs(newCareerExperience.startDate)
  const endDate = dayjs(newCareerExperience.endDate)

  // 经历还没完成 -> 不应该有endDate + 一定要有startDate
  if (!newCareerExperience.isCompleted && newCareerExperience.startDate) {
    newCareerExperience.endDate = ''
    return true
  }
  return startDate.isBefore(endDate)
}

// 删除当前职业经历
const deleteCareerExperience = async (careerId: string) => {
  // 发送请求
  const [error, resultData] = await to(
    profileStore.deleteCareerExperience(careerId),
  )

  //网络请求异常
  if (error) {
    const errorMessage = (error as AxiosError).message
    ElMessage.error(errorMessage)
    await router.replace('/error')
  } else if (resultData) {
    switch (resultData.status) {
      //修改成功
      case 100: {
        profileStore.deleteCareerExperienceInStore(careerId)
        ElMessage.success(UPDATE_SUCCESS)
        break
      }
      //无权限
      case 1008: {
        ElMessage.error(UNAUTHORIZED_ACCESS)
        break
      }
      //用户不存在
      case 1015: {
        ElMessage.error(USER_NOT_EXIST)
        break
      }
      //经历已存在
      case 1020: {
        ElMessage.error(EXPERIENCE_EXISTED)
        break
      }
      //经历不存在
      case 1021: {
        ElMessage.error(EXPERIENCE_NOT_EXISTED)
        break
      }
      default:
        break
    }
  }
}

// 重置新职业经历
const resetNewCareerExperience = () => {
  Object.assign(newCareerExperience, {
    careerId: '',
    companyName: '',
    position: '',
    startDate: '',
    endDate: '',
    isCompleted: true,
  })
  isCareerChecked.value = false
}

/**
 * 教育经历
 */
const newEducationExperience = reactive({
  educationId: '',
  institutionName: '',
  degreeLevel: '',
  major: '',
  startDate: '',
  endDate: '',
  isCompleted: true,
})

// 更改isComplete值 + 同步checkbox
const isEducationChecked = ref(!newEducationExperience.isCompleted)
watchEffect(() => {
  isEducationChecked.value = !newEducationExperience.isCompleted
})
const toggleEducationIsCompleted = () => {
  newEducationExperience.isCompleted = !newEducationExperience.isCompleted
}

// 打开教育经历编辑
const educationPopoverVisible = ref(false)
const openEducationPopover = (
  selectedExperience: EducationExperience | null,
) => {
  if (!selectedExperience) {
    resetNewEducationExperience()
  } else {
    Object.assign(newEducationExperience, selectedExperience)
  }
  educationPopoverVisible.value = !educationPopoverVisible.value
}

// 添加 或 修改当前教育经历
const saveOrUpdateEducationExperience = async () => {
  if (!validateNewEducationExperience()) {
    ElMessage.error(INVALID_INPUT)
    return
  }

  // 发送请求
  const [error, resultData] = await to(
    profileStore.saveOrUpdateEducationExperience(newEducationExperience),
  )

  //网络请求异常
  if (error) {
    const errorMessage = (error as AxiosError).message
    ElMessage.error(errorMessage)
    await router.replace('/error')
  } else if (resultData) {
    switch (resultData.status) {
      //修改成功
      case 100: {
        // 更新经历 -> 已经有educationId -> 先从store删除
        if (newEducationExperience.educationId) {
          profileStore.deleteEducationExperienceInStore(
            newEducationExperience.educationId,
          )
        }
        // 新的经历 -> educationId空 -> 把返回结果里的id添加到当前经历
        else {
          newEducationExperience.educationId = resultData.data
        }
        // 更新到store
        profileStore.addEducationExperienceInStore(newEducationExperience)
        // 重置表格
        resetNewEducationExperience()
        // 关闭表格
        educationPopoverVisible.value = false
        ElMessage.success(UPDATE_SUCCESS)
        break
      }
      //无权限
      case 1008: {
        ElMessage.error(UNAUTHORIZED_ACCESS)
        break
      }
      //用户不存在
      case 1015: {
        ElMessage.error(USER_NOT_EXIST)
        break
      }
      //经历已存在
      case 1020: {
        ElMessage.error(EXPERIENCE_EXISTED)
        break
      }
      //经历不存在
      case 1021: {
        ElMessage.error(EXPERIENCE_NOT_EXISTED)
        break
      }

      default:
        break
    }
  }
}

const validateNewEducationExperience = () => {
  // 检查有没有输入对应的资料
  if (
    !newEducationExperience.institutionName ||
    !newEducationExperience.degreeLevel ||
    !newEducationExperience.major
  ) {
    return false
  }
  // 检查起始 结束时间
  const startDate = dayjs(newEducationExperience.startDate)
  const endDate = dayjs(newEducationExperience.endDate)

  // 经历还没完成 -> 不应该有endDate + 一定要有startDate
  if (!newEducationExperience.isCompleted && newEducationExperience.startDate) {
    newEducationExperience.endDate = ''
    return true
  }
  return startDate.isBefore(endDate)
}

// 删除当前教育经历
const deleteEducationExperience = async (educationId: string) => {
  // 发送请求
  const [error, resultData] = await to(
    profileStore.deleteEducationExperience(educationId),
  )

  //网络请求异常
  if (error) {
    const errorMessage = (error as AxiosError).message
    ElMessage.error(errorMessage)
    await router.replace('/error')
  } else if (resultData) {
    switch (resultData.status) {
      //修改成功
      case 100: {
        profileStore.deleteEducationExperienceInStore(educationId)
        ElMessage.success(UPDATE_SUCCESS)
        break
      }
      //无权限
      case 1008: {
        ElMessage.error(UNAUTHORIZED_ACCESS)
        break
      }
      //用户不存在
      case 1015: {
        ElMessage.error(USER_NOT_EXIST)
        break
      }
      //经历已存在
      case 1020: {
        ElMessage.error(EXPERIENCE_EXISTED)
        break
      }
      //经历不存在
      case 1021: {
        ElMessage.error(EXPERIENCE_NOT_EXISTED)
        break
      }
      default:
        break
    }
  }
}

// 重置新教育经历
const resetNewEducationExperience = () => {
  Object.assign(newEducationExperience, {
    educationId: '',
    institutionName: '',
    degreeLevel: '',
    major: '',
    startDate: '',
    endDate: '',
    isCompleted: true,
  })
  isEducationChecked.value = false
}
</script>

<style lang="scss" scoped>
.header {
  font-size: 16px;
  color: $blue-900;
}

.content-box {
  margin: 26px 44px 10px 22px;
}

.change-self-intro-container {
  .change-self-intro-header {
    font-size: 16px;
    color: $gray-700;
    margin-bottom: 5px;
  }

  :deep(.el-textarea__inner) {
    font-family: $text-font-family;
    font-weight: 500;
    font-size: 16px;
    line-height: 28px;
    color: $text-color-neutral;
    border-radius: 6px;
    border: 1px solid $gray-300;
    width: 408px;
    height: 94px;
    box-shadow: none;
    margin-bottom: 20px;

    &:focus {
      box-shadow: none;
    }
  }
}

.experience-container-header {
  font-size: 16px;
  color: $gray-700;
  margin-top: 32px;
  margin-bottom: 5px;
}

.add-experience {
  display: flex;
  align-items: center;
  color: $blue-900;
  font-weight: 700;
  size: 16px;
  margin-bottom: 16px;
  cursor: pointer;
  .add-icon {
    width: 21.84px;
    height: 22.67px;
    margin-right: 8px;
  }
}

.experience-contents {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 16px;
  .first-row-container {
    display: flex;
    justify-content: space-between;
    .job-or-degree {
      font-size: 16px;
      color: $text-color-neutral;
    }
    .modify-experience-content {
      display: flex;
      flex-direction: row;
      gap: 23px;
      font-size: 14px;
      font-weight: 700;
      color: $blue-900;

      .delete-text {
        cursor: pointer;
      }

      .modify-text {
        cursor: pointer;
      }
    }
  }

  .date {
    font-size: 16px;
    font-weight: 350;
    color: $text-color-neutral;
  }

  .company-or-university {
    font-size: 16px;
    font-weight: 350;
    color: $text-color-neutral;
  }
}

.row-container-in-popover {
  display: flex;
  align-items: end;
  font-family: $text-font-family;
  font-style: normal;
  font-weight: 500;
  font-size: 14px;
  line-height: 28px;
  color: $text-color-disabled;
  margin-bottom: 16px;

  :deep(.el-input__wrapper) {
    border-radius: 0;
    border-bottom: 1px solid $text-color-disabled;
    box-shadow: none;
    width: 312px;
    padding-left: 0px;
    margin-left: 17px;
  }

  :deep(.el-input__inner) {
    font-family: $text-font-family;
    font-weight: 350;
    font-size: 16px;
    line-height: 28px;
    color: $text-color-neutral;
  }
}

.row-degree-levels {
  margin-bottom: 9px !important;
  .degree-text {
    margin-bottom: 7px;
  }
  .degree-dropdown {
    :deep(.el-input__wrapper) {
      border-radius: 3px;
      box-shadow: none;
      border: 1px solid $gray-300;
      width: 173px;
      padding-top: 0px;
      padding-bottom: 0px;
    }

    :deep(.el-input__inner) {
      font-family: $text-font-family;
      font-size: 16px;
      font-style: normal;
      font-weight: 350;
      line-height: 28px;
      color: $text-color-neutral;
      height: 39px;
      border-right: 1px solid $gray-300;
      padding: 5px 0px 6px 8px;
    }

    :deep(.el-select-dropdown__item) {
      font-family: $text-font-family;
      font-size: 16px;
      font-style: normal;
      font-weight: 350;
      color: $text-color-neutral;
    }
  }
}

.date-container-in-popover {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  margin-bottom: 20px;
  margin-top: 10px;

  .start-date,
  .end-date {
    display: flex;
    gap: 11px;
    color: $text-color-disabled;

    .year-and-month-container {
      display: flex;
      gap: 5px;
    }

    .dash-not-completed {
      font-size: 18px;
      font-weight: 500;
      line-height: 28px;
      color: $text-color-disabled;
    }
  }

  // date picker style
  :deep(.el-input__inner) {
    width: 95px;
    color: $blue-900;
    font-size: 18px;
    font-family: $text-font-family;
    font-weight: 500;
    line-height: 28px;
  }
  :deep(.el-input__wrapper) {
    border-bottom: 1px solid $text-color-disabled;
    border-radius: 0px;
    box-shadow: none;
    padding: 0px;
    height: inherit;
    display: flex;
    align-items: normal;
  }
  :deep(.el-date-editor) {
    width: 96px;
    border: none;
  }
  :deep(.el-input__prefix-inner) {
    display: none;
  }

  .check-box {
    color: $blue-900;
    display: flex;
    align-items: center;
    gap: 11px;

    :deep(.el-checkbox__inner) {
      width: 20px;
      height: 20px;
      border: 3px solid $blue-900;
      border-radius: 4px;
    }

    :deep(.el-checkbox__inner::after) {
      border: 3px solid white;
      height: 13px;
      width: 4.5px;
      left: 4px;
      top: -2px;
      border-left: 0;
      border-top: 0;
    }

    :deep(.el-checkbox__input.is-checked .el-checkbox__inner) {
      background-color: $blue-900;
    }
  }
}
.btns-in-popover {
  display: flex;
  gap: 16px;
  .popover-add-btn {
    width: 70px;
    height: 34px;
  }

  .popover-cancel-btn {
    width: 70px;
    height: 34px;
    background: transparent;
    color: $blue-900;
    border: 1px solid $blue-900;
  }
}
// 按钮的基本样式，可以写class override
.el-button {
  font-family: $text-font-family;
  font-style: normal;
  font-weight: 500;
  font-size: 14px;
  line-height: 28px;
  background-color: $blue-900;
  color: white;
  border-radius: 6px;
  border: 0px;
  height: 34px;
  width: 87px;
  padding: 2px 24px;
}

.cancel-button {
  background: transparent;
  color: $blue-900;
  border-radius: 6px;
  border: 1px solid $blue-900;
  margin-left: 18px;
}
</style>

<style lang="scss">
.el-popper.add-experience-popover {
  transform: translate(0px, -12px);
  min-width: 434px;
  height: 221px;
  background-color: #ffffff;
  box-shadow: 0px 4px 4px 0px rgba(0, 0, 0, 0.25);
  border-radius: 0px;
  border: 0px;
  padding: 17px 45px 24px 19px;
  font-size: 14px;
  font-family: $text-font-family;
  font-weight: 500;
  line-height: 28px;

  .el-popper__arrow {
    display: none;
  }
}

.el-popper.add-experience-popover.education {
  height: 264px;
}

.el-popper.delete-confirmation-popup {
  max-width: 120px;
  font-size: 14px;
  font-family: $text-font-family;
  line-height: 28px;

  .el-popconfirm__main {
    justify-content: end;
    color: $text-color-neutral;
  }

  .el-popconfirm__action {
    display: flex;
    flex-direction: row-reverse;
    justify-content: flex-start;
    margin-left: 0;

    .el-button:nth-child(1) {
      width: 50px;
      height: 28px;
      background: transparent;
      color: $blue-900;
      border-radius: 6px;
      border: 1px solid $blue-900;
      margin-left: 18px;
    }

    .el-button:nth-child(2) {
      width: 50px;
      height: 28px;
      background-color: $blue-900;
      color: white;
      border-radius: 6px;
      border: 0px;
      padding: 2px 24px;
    }
  }

  .el-popper__arrow {
    display: none;
  }
}
</style>
