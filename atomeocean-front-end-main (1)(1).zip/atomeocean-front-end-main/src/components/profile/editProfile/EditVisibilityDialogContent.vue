<template>
  <div class="visibility-dialog">
    <h2>修改可见性</h2>
    <el-form
      ref="detailsVisibilityFormRef"
      :model="detailsVisibilityForm"
      class="visibility-form"
      :size="formSize"
      status-icon
    >
      <section>
        <h3>详细资料</h3>
        <div class="tips">{{ DETAILS_MAP[detailsVisibilityForm.value] }}</div>
        <el-form-item prop="details">
          <el-radio-group v-model="detailsVisibilityForm.value">
            <el-radio
              v-for="item in VISIBILITY"
              :key="item.value"
              :label="item.value"
            >
              {{ item.label }}
            </el-radio>
          </el-radio-group>
        </el-form-item>
      </section>
      <el-button @click="submitDetailsVisibilityForm(detailsVisibilityFormRef)"
        >保存修改</el-button
      >
    </el-form>
  </div>
</template>

<script lang="ts" setup>
import { reactive, ref } from 'vue'
import { FormInstance, ElMessage, FormRules } from 'element-plus'
import { useUserInformationStore } from '@/store/userInformation'
import to from 'await-to-js'
import { UPDATE_SUCCESS } from '@/constant/userInformationMessageConstant'
import { DETAILS_MAP, VISIBILITY } from '@/constant/VisibilityConstant'
import { useRouter } from 'vue-router'

const userInformationStore = useUserInformationStore()
const router = useRouter()

const formSize = ref('default')

const detailsVisibilityFormRef = ref<FormInstance>()

const detailsVisibilityForm = reactive<FormRules>({
  value: userInformationStore.getVisibility,
})

// 提交用户信息可见性的修改
const submitDetailsVisibilityForm = async (
  formEl: FormInstance | undefined,
) => {
  if (!formEl) return
  await formEl.validate(async (valid) => {
    if (valid) {
      //发送请求
      const visibilityId = detailsVisibilityForm.value
      const params = new URLSearchParams()
      params.append('id', visibilityId)
      const [error, resultData] = await to(
        userInformationStore.modifyVisibility(params),
      )

      if (error) {
        ElMessage.error(error.message)
        await router.replace('/error')
      } else if (resultData) {
        userInformationStore.setVisibility(visibilityId)
        ElMessage.success(UPDATE_SUCCESS)
      }
    } else {
      return false
    }
  })
}
</script>

<style scoped lang="scss">
h2 {
  font-family: $text-font-family;
  font-size: 16px;
  font-weight: 500;
  line-height: 28px;
  letter-spacing: 0em;
  text-align: left;
  margin-bottom: 16px;
  color: #154a6f;
  margin-top: 0px;
}
.visibility-form {
  padding: 0 0 0 19px;
  box-sizing: border-box;
  h3 {
    font-family: $text-font-family;
    font-size: 16px;
    font-weight: 500;
    line-height: 28px;
    letter-spacing: 0em;
    text-align: left;
    margin-bottom: 7px;
    color: #535353;
  }
  .tips {
    font-family: $text-font-family;
    font-size: 14px;
    font-weight: 500;
    line-height: 28px;
    letter-spacing: 0em;
    text-align: left;
    color: #535353;
    margin-bottom: 7px;
  }
  .el-form-item--default {
    margin-bottom: 0;
  }
  ::v-deep .el-radio {
    width: 143px;
    height: 28px;
    font-family: $text-font-family;
    font-size: 14px;
    font-weight: 500;
    line-height: 28px;
    letter-spacing: 0em;
    text-align: left;
    color: #535353;
    margin-bottom: 4px;

    &:not(:last-child) {
      margin-right: 3px;
    }
    &:nth-child(2) {
      margin-right: 100px;
    }
    &:nth-child(n + 3) {
      margin-bottom: 0;
    }
    &.is-checked {
      .el-radio__label {
        color: #154a6f;
      }
      .el-radio__inner {
        border-color: #154a6f;
      }
    }
    .el-radio__label {
      padding-left: 10px;
    }
    .el-radio__inner {
      width: 16px;
      height: 16px;
      background: #154a6f;
      &::after {
        width: 6px;
        height: 6px;
      }
    }
  }
  ::v-deep .el-checkbox {
    &.is-checked {
      color: #154a6f;
      .el-checkbox__inner {
        border-color: #154a6f;
        background-color: #154a6f;
      }
      .el-checkbox__label {
        color: #154a6f;
      }
    }
    //styleName: Text-2-medium;
    font-family: $text-font-family;
    font-size: 14px;
    font-weight: 500;
    line-height: 28px;
    letter-spacing: 0em;
    text-align: left;
    color: #535353;
    margin-top: 12px;

    .el-checkbox__inner {
      background: #154a6f;
      border-color: #154a6f;
      width: 20px;
      height: 20px;
      border-radius: 4px;
      &::after {
        font-size: 16px;
        height: 12px;
        left: 5px;
        border-width: 2px;
        width: 6px;
        top: 0;
      }
    }
  }
  section {
    margin-left: 3px;
    &:nth-child(1) {
      margin-top: 16px;
      margin-bottom: 28px;
    }
    &:nth-child(2) {
      margin-bottom: 30px;
    }
    &:nth-child(3) {
      margin-bottom: 51px;
    }
  }
  .el-button {
    height: 34px;
    box-sizing: border-box;
    color: #fff;
    padding: 3px 15.5px;
    border-radius: 6px;
    background: #154a6f;
    font-family: $text-font-family;
    font-size: 14px;
    font-weight: 500;
    line-height: 28px;
    letter-spacing: 0em;
    text-align: left;
  }
}
</style>
