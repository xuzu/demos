<template>
  <div class="basic-information">
    <div class="edit-button-1" v-show="props.isCurrentUser">
      <Icon
        icon="mdi:account-edit-outline"
        class="edit-profile-icon"
        @click="openProfileEditor('0')"
      />
      <ProfileEditorDialogView
        v-if="isProfileEditorOpen"
        @close="toggleProfileEditorOpen"
        :activeIndexProps="activeMenuItemIndex"
      ></ProfileEditorDialogView>
    </div>
    <div class="name heading-5-bold">{{ profileStore.getNickname }}</div>
    <div class="motto paragraph-2-medium">{{ profileStore.getMotto }}</div>
    <div class="user-id text-2-normal"># {{ route.params.userId }}</div>
    <div class="followings-followers-container">
      <div class="following-container">
        <div class="follow-counts heading-4-bold">110</div>
        <div class="follow-text text-1-medium">关注</div>
      </div>
      <div class="followers-container">
        <div class="follow-counts heading-4-bold">110</div>
        <div class="follow-text text-1-medium">粉丝</div>
      </div>
    </div>
    <div class="button-container" v-show="!props.isCurrentUser">
      <el-button
        @mouseover="showUnfollowButton = true"
        @mouseleave="showUnfollowButton = false"
        class="unfollow-button"
        v-if="isFollowed"
      >
        <div v-if="showUnfollowButton" class="button-content">
          <Icon
            icon="material-symbols:cancel-outline"
            class="cancel-icon"
          />取消关注
        </div>
        <div v-else class="button-content">
          <Icon
            icon="material-symbols:check-circle-outline"
            class="check-icon"
          />已关注
        </div>
      </el-button>
      <el-button v-else>
        <Icon icon="material-symbols:add" class="follow-icon" />关注
      </el-button>
      <el-button class="direct-message-button">
        <Icon
          icon="material-symbols:mail-outline-rounded"
          class="mail-icon"
        />私信
      </el-button>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, defineProps } from 'vue'
import ProfileEditorDialogView from '@/views/ProfileEditorDialogView.vue'
import { useProfileStore } from '@/store/profile'
import { useRoute } from 'vue-router'
import { Icon } from '@iconify/vue'

const props = defineProps({
  isCurrentUser: {
    type: Boolean,
    required: true,
  },
})

const profileStore = useProfileStore()
const route = useRoute()

// 点击进入编辑个人页组建
const isProfileEditorOpen = ref(false)
const activeMenuItemIndex = ref('0')
const openProfileEditor = (index: string) => {
  isProfileEditorOpen.value = true
  activeMenuItemIndex.value = index
}
const toggleProfileEditorOpen = () => {
  isProfileEditorOpen.value = !isProfileEditorOpen.value
}

// 当前浏览的用户是否已关注
const showUnfollowButton = ref(false)
const isFollowed = ref(false)
</script>

<style lang="scss" scoped>
.basic-information {
  box-sizing: border-box;
  border-bottom: 1px solid $gray-100;
  padding-top: 61px;
  padding-left: 47px;
  padding-bottom: 18px;
  display: flex;
  flex-direction: column;

  .edit-button-1 {
    position: relative;
    align-self: flex-end;
    margin-right: 15px;
    margin-bottom: -21px;
    margin-top: -21px;

    .edit-profile-icon {
      width: 32px;
      height: 32px;
      color: $gray-500;
      cursor: pointer;
    }
  }
  .name {
    margin-bottom: 8px;
  }
  .motto {
    margin-bottom: 8px;
  }
  .user-id {
    color: $text-color-neutral;
    margin-bottom: 8px;
  }

  .followings-followers-container {
    display: inline-flex;
    gap: 82px;
    .follow-text {
      color: $text-color-neutral;
      padding-left: 2px;
    }
  }

  .button-container {
    display: flex;
    flex-direction: row;
    gap: 25px;
    margin-top: 12px;
    margin-bottom: 6px;
    .follow-icon {
      width: 24px;
      height: 24px;
      margin-right: 6px;
    }
    .direct-message-button {
      background-color: $blue-700;
      border-color: $blue-700;
      .mail-icon {
        width: 24px;
        height: 24px;
        margin-right: 8px;
      }
    }

    .unfollow-button {
      background-color: white;
      color: $blue-900;
      border: 1px solid $blue-900;
      padding: 2px 32px;
      .button-content {
        display: flex;
        justify-content: center;
        align-items: center;
      }
      .check-icon {
        width: 24px;
        height: 24px;
        margin-right: 10px;
      }
      .cancel-icon {
        width: 24px;
        height: 24px;
        margin-right: 4px;
      }
    }
  }
}

// 按钮的基本样式，可以写class override
.el-button {
  font-family: $text-font-family;
  font-style: normal;
  font-weight: 500;
  font-size: 16px;
  line-height: 28px;
  background-color: $blue-900;
  color: white;
  border: 1px solid $blue-900;
  border-radius: 20px;
  display: flex;
  width: 114px;
  height: 40px;
  padding: 2px 32px 2px 24px;
}
</style>
