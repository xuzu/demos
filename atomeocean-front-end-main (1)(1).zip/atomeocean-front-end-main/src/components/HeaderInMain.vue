<!-- 在main div中的header -->
<template>
  <div class="header-div">
    <el-carousel arrow="never">
      <el-carousel-item v-for="item in carouselItems" :key="item.title">
        <img :src="item.path" :alt="item.title" class="carousel-image" />
      </el-carousel-item>
    </el-carousel>
  </div>
</template>

<script setup lang="ts">
// 添加轮播图图片
const carouselItems = [
  { title: 'item 1', path: require('../assets/the_office.png') },
  { title: 'item 2', path: require('../assets/the_office.png') },
  { title: 'item 3', path: require('../assets/the_office.png') },
  { title: 'item 4', path: require('../assets/the_office.png') },
  { title: 'item 5', path: require('../assets/the_office.png') },
]
</script>

<style lang="scss" scoped>
.header-div {
  // 图片大小
  .carousel-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  // 装图片的盒子
  :deep(.el-carousel__container) {
    height: 376px;

    // 更改左右箭头
    .el-carousel__arrow {
      background-color: transparent;
      width: 32px;
      height: 48px;

      svg {
        display: none;
      }

      &--left {
        background-image: url('data:image/svg+xml,%3Csvg xmlns="http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg" width="24" height="24" viewBox="0 0 24 24"%3E%3Cpath fill="currentColor" d="M14.71 15.88L10.83 12l3.88-3.88a.996.996 0 1 0-1.41-1.41L8.71 11.3a.996.996 0 0 0 0 1.41l4.59 4.59c.39.39 1.02.39 1.41 0c.38-.39.39-1.03 0-1.42z"%2F%3E%3C%2Fsvg%3E');
        background-repeat: no-repeat;
        background-size: 32px 48px;
        margin-left: -16px;
      }

      &--right {
        background-image: url('data:image/svg+xml,%3Csvg xmlns="http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg" width="24" height="24" viewBox="0 0 24 24"%3E%3Cpath fill="currentColor" d="M9.29 15.88L13.17 12L9.29 8.12a.996.996 0 1 1 1.41-1.41l4.59 4.59c.39.39.39 1.02 0 1.41L10.7 17.3a.996.996 0 0 1-1.41 0c-.38-.39-.39-1.03 0-1.42z"%2F%3E%3C%2Fsvg%3E');
        background-repeat: no-repeat;
        background-size: 32px 48px;
        margin-right: -16px;
      }
    }
  }

  // 更改indicator小点点样式
  :deep(.el-carousel__button) {
    width: 8px;
    height: 8px;
    margin-bottom: 3px;
    border-radius: 50%;
    background-color: $gray-700;
    opacity: 0.25;
  }

  :deep(.el-carousel__indicator.is-active button) {
    background-color: $gray-700;
    opacity: 1;
  }
}
</style>
