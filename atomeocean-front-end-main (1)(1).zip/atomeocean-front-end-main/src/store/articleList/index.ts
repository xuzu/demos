import { defineStore } from 'pinia'
import { ArticleData, ArticleListResponse } from '@/store/article/types'
import { RequestArticleListParams } from '@/api/articleList/model'
import articleListApi from '@/api/articleList'
import { formatDateString } from '@/utils/dayjs'
import { calculateReadMinutes } from '@/utils/article'
import to from 'await-to-js'
import { AxiosError } from 'axios'
import { ElMessage } from 'element-plus'
import router from '@/router'

/**
 * 文章列表
 */
export const useArticleListStore = defineStore('articleList', {
  state: (): ArticleListResponse => {
    return {
      paginationToken: undefined,
      articleList: [] as ArticleData[],
    }
  },
  persist: true,
  getters: {
    articleListLength: (state) => state.articleList.length,
  },
  actions: {
    // 本地加载文章列表缓存
    // todo: 检查缓存过期时间
    async loadArticleList(articleListParams: RequestArticleListParams) {
      // todo：可以不每次都请求后端
      await this.fetchArticleList(articleListParams)
    },
    // 从后端获取文章列表
    async fetchArticleList(articleListParams: RequestArticleListParams) {
      const [error, result] = await to(
        articleListApi.getArticleList(articleListParams || {}),
      )

      if (error) {
        const errorMessage = (error as AxiosError).message
        ElMessage.error(errorMessage)
        await router.replace('/error')
        return
      }

      // 返回可能为null，这时不做更新
      if (!result) {
        return
      }

      const articleListResponse = result.data

      // 更新pinia中的文章列表
      const fetchedArticleList = articleListResponse.articleList
      for (let index = 0; index < fetchedArticleList.length; index++) {
        const articleResponse = fetchedArticleList[index]

        this.articleList[index] = fetchedArticleList[index]

        // 转换时间格式
        this.articleList[index].createTime = formatDateString(
          articleResponse.createTime,
        )
        this.articleList[index].latestUpdateTime = formatDateString(
          articleResponse.latestUpdateTime,
        )
        this.articleList[index].readMinutes = calculateReadMinutes(
          articleResponse.wordCount || 0,
        )
      }
    },
    deleteArticleWithIndex(index: number) {
      if (index === -1 || index >= this.articleListLength) {
        return
      }
      this.articleList[index].isDeleted = true
    },
    updateArticleWithIndex(index: number, updatedArticle: ArticleData) {
      if (index === -1 || index >= this.articleListLength) {
        return
      }
      this.articleList[index] = updatedArticle
    },
    // 将新文章填充到数组里面
    addNewArticle(newArticle: ArticleData) {
      this.articleList.splice(0, 0, newArticle)
    },
  },
})
