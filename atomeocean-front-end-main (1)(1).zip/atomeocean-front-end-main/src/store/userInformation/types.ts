export interface BaseProfileBasicInformation {
  avatarLink?: string
  nickname?: string
  motto?: string
  selfIntroduction?: string
}

/**
 * 保存登录用户的信息
 */
export interface UserInformationState extends BaseProfileBasicInformation {
  backgroundImageLink?: string
  visibility?: number
}

export interface UserInformationResponse {
  nickname?: string
  avatarLink?: string
  motto?: string
  backgroundImageLink?: string
  selfIntroduction?: string
  careerVoSet?: CareerResponse[]
  educationVoSet?: EducationResponse[]
  visibilityId?: number
}

/**
 * 对接返回的json字段 careerVoSet部分
 */
interface CareerResponse {
  careerId?: string
  companyName?: string
  position?: string
  startDate?: string
  endDate?: string
  isCompleted?: boolean
}

/**
 * 对接返回的json字段 educationVoSet部分
 */
interface EducationResponse {
  educationId?: string
  institutionName?: string
  degreeLevel?: string
  major?: string
  startDate?: string
  endDate?: string
  isCompleted?: boolean
}
