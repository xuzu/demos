import { defineStore } from 'pinia'
import { UserInformationState } from './types'
import {
  ModifyProfileParams,
  RequestUserInformationParams,
} from '@/api/userInformation/model'
import userInformationApi from '@/api/userInformation'
import imageAndFileApi from '@/api/imageAndFile'
import {
  DEFAULT_MOTTO,
  DEFAULT_VISIBILITY,
} from '@/constant/userInformationMessageConstant'

//引入默认头像图片
const avatarImage = { path: require('../../assets/seal_profile.png') }
const defaultMotto = DEFAULT_MOTTO
const backgroundImage = { path: require('../../assets/blue300_background.png') }
/**
 * 维护用户登录认证无关的信息
 */

export const useUserInformationStore = defineStore('userInfo', {
  state: (): UserInformationState => {
    return {
      avatarLink: avatarImage.path,
      nickname: '',
      motto: defaultMotto,
      backgroundImageLink: backgroundImage.path,
      selfIntroduction: '',
      visibility: 1,
    }
  },
  persist: true,
  getters: {
    getAvatarLink(state: UserInformationState): string {
      return state.avatarLink ?? ''
    },
    getNickname(state: UserInformationState): string {
      return state.nickname ?? ''
    },
    getMotto(state: UserInformationState): string {
      return state.motto ?? ''
    },
    getBackgroundImageLink(state: UserInformationState): string {
      return state.backgroundImageLink ?? ''
    },
    getSelfIntroduction(state: UserInformationState): string {
      return state.selfIntroduction ?? ''
    },
    getVisibility(state: UserInformationState): number {
      return state.visibility ?? 1
    },
  },
  actions: {
    setAvatar(avatarLink: string) {
      this.avatarLink = avatarLink ? avatarLink : this.avatarLink
    },
    setNickname(nickname: string) {
      this.nickname = nickname ? nickname : this.nickname
    },
    setMotto(motto: string) {
      this.motto = motto ? motto : this.motto
    },
    setBackgroundImageLink(backgroundImageLink: string) {
      this.backgroundImageLink = backgroundImageLink
        ? backgroundImageLink
        : this.backgroundImageLink
    },
    setSelfIntroduction(selfIntroduction: string) {
      this.selfIntroduction = selfIntroduction ?? this.selfIntroduction
    },
    setVisibility(visibility: number) {
      this.visibility = visibility ? visibility : this.visibility
    },

    async getUserInformation(params: RequestUserInformationParams) {
      const userInformationResponse =
        await userInformationApi.getUserInformation(params)
      if (userInformationResponse?.data) {
        this.$patch({
          nickname: userInformationResponse.data.nickname
            ? userInformationResponse.data.nickname
            : this.nickname,
          avatarLink: userInformationResponse.data.avatarLink
            ? userInformationResponse.data.avatarLink
            : this.avatarLink,
          motto: userInformationResponse.data.motto
            ? userInformationResponse.data.motto
            : this.motto,
          backgroundImageLink: userInformationResponse.data.backgroundImageLink
            ? userInformationResponse.data.backgroundImageLink
            : this.backgroundImageLink,
          selfIntroduction:
            userInformationResponse.data.selfIntroduction ??
            this.selfIntroduction,
          visibility:
            userInformationResponse.data.visibilityId ?? DEFAULT_VISIBILITY,
        })
      }
      return userInformationResponse
    },

    /**
     * 更新用户名
     */
    async modifyNickname(newNickname: string) {
      const modifyProfileParams: ModifyProfileParams = {
        fieldsModified: ['nickname'],
        nickname: newNickname,
      }
      const modifyNicknameResponse =
        await userInformationApi.modifyUserInformation(modifyProfileParams)

      return modifyNicknameResponse
    },

    /**
     * 更新用户头像
     */
    async updateAvatar(params: FormData) {
      const updateAvatarResponse = await imageAndFileApi.updateAvatar(params)

      return updateAvatarResponse
    },

    /**
     * 更新简介
     */
    async modifyMotto(newMotto: string) {
      const modifyProfileParams: ModifyProfileParams = {
        fieldsModified: ['motto'],
        motto: newMotto,
      }
      const modifyMottoResponse =
        await userInformationApi.modifyUserInformation(modifyProfileParams)

      return modifyMottoResponse
    },

    /**
     * 更新自我介绍
     */
    async modifySelfIntroduction(newSelfIntroduction: string) {
      const modifyProfileParams: ModifyProfileParams = {
        fieldsModified: ['selfIntroduction'],
        selfIntroduction: newSelfIntroduction,
      }
      const modifyMottoResponse =
        await userInformationApi.modifyUserInformation(modifyProfileParams)

      return modifyMottoResponse
    },

    /**
     * 更新用户信息可见性
     */
    async modifyVisibility(params: URLSearchParams) {
      return await userInformationApi.modifyVisibility(params)
    },
  },
})
