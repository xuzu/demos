/**
 * 图片上传成功返回结果
 */
export interface imageUploadResponse {
  imageUrl: string
}
