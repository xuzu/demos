export interface UserState {
  userId?: string
  userEmail?: string
  password?: string
  // gender?: string;
  // fans?: number;
  // follow?: number;
  // score?: number;
  // github?: string;
  // qqNumber?: string;
  // commentState?: number;
  // userTag?: number;
  // state?: number;
}

export interface UserResponse {
  userId?: string
}
