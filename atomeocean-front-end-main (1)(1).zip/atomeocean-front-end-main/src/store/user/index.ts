import { defineStore } from 'pinia'
import userApi from '@/api/user'
import { UserState } from '@/store/user/types'
import {
  LoginRequestParams,
  RegisterRequestParams,
  ResetPasswordParams,
} from '@/api/user/model'
import { usePermissionStore } from '@/store/permission'

/**
 * 维护用户登录信息
 */
export const useUserStore = defineStore('user', {
  state: (): UserState => {
    return {
      userId: '',
      userEmail: '',
      password: '',
    }
  },
  persist: true,
  getters: {
    getUserId(state: UserState): string {
      return state.userId ?? ''
    },
    getUserEmail(state: UserState): string {
      return state.userEmail ?? ''
    },
    getPassword(state: UserState): string {
      return state.password ?? ''
    },
  },
  actions: {
    setUserId(userId: string) {
      this.userId = userId
    },
    setUserEmail(userEmail: string) {
      this.userEmail = userEmail
    },
    setPassword(password: string) {
      this.password = password
    },

    // 注册新用户
    // 需要保证user email globally unique
    async register(params: RegisterRequestParams) {
      const registerResponse = await userApi.register(params)
      return registerResponse
    },

    //验证用户邮箱
    async verifyEmail(params: URLSearchParams) {
      const verificationResponse = await userApi.verify(params)
      return verificationResponse
    },

    //重新发送验证码
    async resendVerificationCode(params: URLSearchParams) {
      const resendCodeResponse = await userApi.resendVerificationCode(params)
      return resendCodeResponse
    },

    // 用户登录
    async signIn(logInRequestParams: LoginRequestParams) {
      const permissionStore = usePermissionStore()
      const authenticationResponse = await userApi.login(logInRequestParams)

      this.$patch({
        userEmail: logInRequestParams.userEmail,
        userId: authenticationResponse.userId,
      })

      permissionStore.setToken(authenticationResponse.token)

      return authenticationResponse
    },

    // 重置密码
    // Step 1: 检查用户输入的邮箱是否满足重置密码的要求
    async emailVerify(params: ResetPasswordParams) {
      const verificationResponse = await userApi.emailVerify(params)
      return verificationResponse
    },
    // Step 2: 检查输入的验证码是否正确，如果正确则修改用户密码
    async codeVerify(params: URLSearchParams) {
      const verificationResponse = await userApi.codeVerify(params)
      return verificationResponse
    },
  },
})
