import { defineStore } from 'pinia'

/**
 * 静态路径
 */
export const useRouteStore = defineStore('route', {
  state: () => {
    return {
      logInPath: '/signin',
      homePagePath: '/',
      registerPath: '/register',
      profileName: 'profile',
    }
  },
  persist: true,
})
