import { BaseProfileBasicInformation } from '@/store/userInformation/types'

/**
 * 保存profile页面信息
 */
export interface ProfileState extends BaseProfileBasicInformation {
  backgroundImageLink?: string
  // 职业经历
  careerExperience?: CareerExperience[]
  educationExperience?: EducationExperience[]
  visibility?: number
}

/**
 * profile中职业经历类型
 * 保存在store中
 */
export interface CareerExperience {
  careerId?: string
  companyName?: string
  position?: string
  startDate?: string
  endDate?: string
  isCompleted?: boolean
}

/**
 * profile中学业经历类型
 * 保存在store中
 */
export interface EducationExperience {
  educationId?: string
  institutionName?: string
  degreeLevel?: string
  major?: string
  startDate?: string
  endDate?: string
  isCompleted?: boolean
}
