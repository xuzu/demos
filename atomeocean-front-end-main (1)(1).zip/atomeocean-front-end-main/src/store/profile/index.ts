import { defineStore } from 'pinia'
import {
  CareerExperience,
  EducationExperience,
  ProfileState,
} from '@/store/profile/types'
import {
  DEFAULT_MOTTO,
  DEFAULT_NICKNAME,
  DEFAULT_SELF_INTRODUCTION,
  DEFAULT_VISIBILITY,
} from '@/constant/userInformationMessageConstant'
import {
  PostCareerExperienceParams,
  PostEducationExperienceParams,
  RequestUserInformationParams,
} from '@/api/userInformation/model'
import userInformationApi from '@/api/userInformation'
import { ResourceOperationType } from '@/api/ResourceOperationType'
import { sortExperience } from '@/utils/profile'

/**
 * profile页面本地缓存
 */
//引入默认头像图片
const avatarImage = { path: require('../../assets/seal_profile.png') }
const backgroundImage = { path: require('../../assets/blue300_background.png') }

export const useProfileStore = defineStore('profile', {
  state: (): ProfileState => {
    return {
      avatarLink: avatarImage.path,
      nickname: DEFAULT_NICKNAME,
      motto: DEFAULT_MOTTO,
      backgroundImageLink: backgroundImage.path,
      selfIntroduction: DEFAULT_SELF_INTRODUCTION,
      careerExperience: undefined as CareerExperience[] | undefined,
      educationExperience: undefined as EducationExperience[] | undefined,
      visibility: DEFAULT_VISIBILITY,
    }
  },
  // 使用session storage，tab关闭自动清除
  persist: {
    storage: sessionStorage,
  },
  getters: {
    getAvatarLink(state: ProfileState): string {
      return state.avatarLink ?? avatarImage.path
    },
    getNickname(state: ProfileState): string {
      return state.nickname ?? DEFAULT_NICKNAME
    },
    getMotto(state: ProfileState): string {
      return state.motto ?? DEFAULT_MOTTO
    },
    getBackgroundImageLink(state: ProfileState): string {
      return state.backgroundImageLink ?? backgroundImage.path
    },
    getSelfIntroduction(state: ProfileState): string {
      return state.selfIntroduction ?? DEFAULT_SELF_INTRODUCTION
    },
    getVisibility(state: ProfileState): number {
      return state.visibility ?? DEFAULT_VISIBILITY
    },
    getProfileCompleteness(): number {
      const totalComponents = 3
      let completedComponents = 0
      completedComponents += this.selfIntroduction ? 1 : 0
      completedComponents +=
        this.educationExperience && this.educationExperience.length > 0 ? 1 : 0
      completedComponents +=
        this.careerExperience && this.careerExperience.length > 0 ? 1 : 0
      return Math.ceil((completedComponents / totalComponents) * 100)
    },
  },
  actions: {
    setAvatar(avatarLink: string) {
      this.avatarLink = avatarLink ?? avatarImage.path
    },
    setNickname(nickname: string) {
      this.nickname = nickname ?? DEFAULT_NICKNAME
    },
    setMotto(motto: string) {
      this.motto = motto ?? DEFAULT_MOTTO
    },
    setBackgroundImageLink(backgroundImageLink: string) {
      this.backgroundImageLink = backgroundImageLink ?? backgroundImage.path
    },
    setSelfIntroduction(selfIntroduction: string) {
      this.selfIntroduction = selfIntroduction ?? DEFAULT_SELF_INTRODUCTION
    },
    setVisibility(visibility: number) {
      this.visibility = visibility ?? DEFAULT_VISIBILITY
    },
    /**
     * 保存当前被访问用户的userInformation
     */
    async getUserInformation(params: RequestUserInformationParams) {
      const userInformationResponse =
        await userInformationApi.getUserInformation(params)
      if (userInformationResponse?.data) {
        this.$patch({
          nickname: userInformationResponse.data.nickname ?? DEFAULT_NICKNAME,
          avatarLink: userInformationResponse.data.avatarLink
            ? userInformationResponse.data.avatarLink
            : avatarImage.path,
          motto: userInformationResponse.data.motto
            ? userInformationResponse.data.motto
            : DEFAULT_MOTTO,
          backgroundImageLink: userInformationResponse.data.backgroundImageLink
            ? userInformationResponse.data.backgroundImageLink
            : backgroundImage.path,
          selfIntroduction:
            userInformationResponse.data.selfIntroduction ??
            DEFAULT_SELF_INTRODUCTION,
          careerExperience:
            userInformationResponse.data.careerVoSet ??
            (undefined as CareerExperience[] | undefined),
          educationExperience:
            userInformationResponse.data.educationVoSet ??
            (undefined as EducationExperience[] | undefined),
          visibility:
            userInformationResponse.data.visibilityId ?? DEFAULT_VISIBILITY,
        })
        sortExperience(this.careerExperience as CareerExperience[])
        sortExperience(this.educationExperience as EducationExperience[])
      }
      return userInformationResponse
    },

    /**
     * 通知后端删除当前用户的careerExperience
     */
    async deleteCareerExperience(careerId: string) {
      const deleteCareerExperienceParams: PostCareerExperienceParams = {
        operationType: ResourceOperationType.Delete,
        careerId: careerId,
      }
      const deleteCareerExperienceResponse =
        await userInformationApi.modifyCareerExperience(
          deleteCareerExperienceParams,
        )
      return deleteCareerExperienceResponse
    },

    /**
     * 从当前用户的careerExperience store删除一段经历
     */
    deleteCareerExperienceInStore(careerId: string) {
      const index = this.careerExperience?.findIndex(
        (experience) => experience.careerId === careerId,
      )
      if (index !== undefined && index !== -1) {
        this.careerExperience?.splice(index, 1)
        sortExperience(this.careerExperience as CareerExperience[])
      }
    },

    /**
     * 添加 或 更新 职业经历到数据库
     */
    async saveOrUpdateCareerExperience(newCareerExperience: CareerExperience) {
      const CareerExperienceParam: PostCareerExperienceParams =
        newCareerExperience
      if (newCareerExperience.careerId) {
        // 有careerId = 更新
        CareerExperienceParam.operationType = ResourceOperationType.Patch
      } else {
        // 无careerId = 添加
        CareerExperienceParam.operationType = ResourceOperationType.Post
      }
      const deleteCareerExperienceResponse =
        await userInformationApi.modifyCareerExperience(CareerExperienceParam)
      return deleteCareerExperienceResponse
    },

    /**
     * 添加新职业经历到数据库
     */
    addCareerExperienceInStore(newCareerExperience: CareerExperience) {
      this.careerExperience?.push({ ...newCareerExperience })
      sortExperience(this.careerExperience as CareerExperience[])
    },

    /**
     * 通知后端删除当前用户的Education Experience
     */
    async deleteEducationExperience(educationId: string) {
      const deleteEducationExperienceParams: PostEducationExperienceParams = {
        operationType: ResourceOperationType.Delete,
        educationId: educationId,
      }
      const deleteEducationExperienceResponse =
        await userInformationApi.modifyEducationExperience(
          deleteEducationExperienceParams,
        )
      return deleteEducationExperienceResponse
    },

    /**
     * 从当前用户的Education Experience store删除一段经历
     */
    deleteEducationExperienceInStore(educationId: string) {
      const index = this.educationExperience?.findIndex(
        (experience) => experience.educationId === educationId,
      )
      if (index !== undefined && index !== -1) {
        this.educationExperience?.splice(index, 1)
        sortExperience(this.educationExperience as EducationExperience[])
      }
    },

    /**
     * 添加 或 更新 教育经历到数据库
     */
    async saveOrUpdateEducationExperience(
      newEducationExperience: EducationExperience,
    ) {
      const EducationExperienceParam: PostEducationExperienceParams =
        newEducationExperience
      if (newEducationExperience.educationId) {
        // 有careerId = 更新
        EducationExperienceParam.operationType = ResourceOperationType.Patch
      } else {
        // 无careerId = 添加
        EducationExperienceParam.operationType = ResourceOperationType.Post
      }
      const deleteEducationExperienceResponse =
        await userInformationApi.modifyEducationExperience(
          EducationExperienceParam,
        )
      return deleteEducationExperienceResponse
    },

    /**
     * 添加新教育经历到数据库
     */
    addEducationExperienceInStore(newEducationExperience: EducationExperience) {
      this.educationExperience?.push({ ...newEducationExperience })
      sortExperience(this.educationExperience as EducationExperience[])
    },
  },
})
