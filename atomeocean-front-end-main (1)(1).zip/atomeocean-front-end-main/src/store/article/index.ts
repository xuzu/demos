import { defineStore } from 'pinia'
import { ArticleAuthor, ArticleData, ArticleState } from '@/store/article/types'
import articleApi from '@/api/article'
import { RequestArticleParams } from '@/api/article/model'
import { marked } from 'marked'
import { formatDateString } from '@/utils/dayjs'
import { calculateReadMinutes } from '@/utils/article'
import { ArticleCategory } from '@/constant/articleAndListConstant'
import { isEmpty } from '@/utils/general'

//引入默认头像图片
export const defaultAvatarImage = {
  path: require('../../assets/seal_profile.png'),
}

/**
 * 缓存文章信息
 */
export const useArticleStore = defineStore('article', {
  state: (): ArticleState => {
    return {
      // index的默认值为-1
      indexInArticleList: -1,
      article: {
        articleId: undefined,
        title: '',
        collapsedContent: '',
        contentId: undefined,
        content: '',
        articleAuthor: undefined as ArticleAuthor | undefined,
        isBeingEdited: false,
        isDeleted: false,
        wordCount: 0,
        readMinutes: 0,
        categoryName: ArticleCategory.Default,
        visibilityId: 1,
        viewCount: 0,
      },
    }
  },
  // 使用session storage，tab关闭自动清除
  persist: {
    storage: sessionStorage,
  },
  getters: {
    getArticleId(state: ArticleState): string {
      return state.article.articleId ?? ''
    },
  },
  actions: {
    setArticle(article: ArticleData) {
      this.article = article
    },
    refreshArticleId(articleId: string) {
      this.article.articleId = articleId
    },
    setTitle(title: string) {
      this.article.title = title
    },
    setContent(content: string) {
      this.article.content = content
    },
    setIsBeingEdited(isBeingEdited: boolean) {
      this.article.isBeingEdited = isBeingEdited
    },

    // 加载文章内容
    async loadFullArticle(requestArticleParams: RequestArticleParams) {
      // 调用文章api
      const articleResult = await articleApi.getArticle(requestArticleParams)

      if (!articleResult) {
        return
      }

      if (articleResult?.data) {
        const articleResponse = articleResult?.data
        // 已删除或无权限文章，后端的返回为空
        // TODO: 修改返回空文章的contract
        if (Object.keys(articleResponse.article).length === 0) {
          // 文章失效，清空本地缓存
          this.$reset()
          this.article.isDeleted = true
          return
        }
        this.setArticle(articleResponse.article)

        // 添加时间相关
        this.article.createTime = formatDateString(
          articleResponse.article.createTime,
        )
        this.article.latestUpdateTime = formatDateString(
          articleResponse.article.latestUpdateTime,
        )

        // 添加数字
        this.article.readMinutes = calculateReadMinutes(
          articleResponse.article.wordCount ?? 1,
        )
        this.article.viewCount = isEmpty(articleResponse.article.viewCount)
          ? 0
          : articleResponse.article.viewCount

        // 如果作者没有头像，填充默认头像
        if (isEmpty(this.article.articleAuthor?.avatarLink)) {
          this.article.articleAuthor!.avatarLink = defaultAvatarImage.path
        }

        // content格式转化
        this.convertContent()
      }

      return articleResult
    },

    convertContent() {
      marked.setOptions({
        renderer: new marked.Renderer(),
      })
      const rawContent = this.article.content
      this.$patch({
        article: {
          content: marked.parse(rawContent),
        },
      })
    },

    /**
     * 获取当前文章的分享链接
     */
    getArticleShareLink() {
      const articleLink =
        process.env.VUE_APP_BASE_URL + '/article/' + this.article.articleId
      return articleLink
    },
  },
})
