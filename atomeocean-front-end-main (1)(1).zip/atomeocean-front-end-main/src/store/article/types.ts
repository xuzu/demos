import { ResourceOperationType } from '@/api/ResourceOperationType'
import { BaseProfileBasicInformation } from '@/store/userInformation/types'

/**
 * article store中使用
 * indexInArticleList初始值为-1，即不在任何一个文章列表里面
 */
export interface ArticleState {
  indexInArticleList: number
  article: ArticleData
}

/**
 * article和editor store中使用
 * ArticleData和EditorData的父类
 */
export interface BaseArticleContent {
  wordCount?: number
  // 阅读时长，分钟为单位
  readMinutes?: number
  operationType?: ResourceOperationType
  // 文章Id 18位长度
  articleId?: string
  title?: string
  collapsedContent?: string
  contentId?: string
  content?: string

  isBeingEdited?: boolean
  isDeleted?: boolean
  // 文章类型
  categoryName?: string
  // 可读权限
  visibilityId?: number
}

/**
 * 定义Tag类型，用于addTag和hotTag
 */
export interface ArticleTag {
  title: string
  type: string
}

/**
 * 请求文章列表时从后端接收的数据类型
 */
export interface ArticleListResponse {
  paginationToken?: string
  articleList: ArticleData[]
}

// 单个文章请求返回结果类型
export interface ArticleResponse {
  article: ArticleData
}

// 文章类
export interface ArticleData extends BaseArticleContent {
  //文章的封面和摘要
  articleCoverImageLink?: string
  // 作者信息
  articleAuthor?: ArticleAuthor
  //add tag
  articleTagList?: Array<ArticleTag>
  //hot tag
  hotTagArray?: Array<ArticleTag>
  // 文章的浏览量
  viewCount: number

  // 新建和最后更新时间
  createTime?: string
  latestUpdateTime?: string
}

/**
 * 文章的作者信息
 */
export interface ArticleAuthor extends BaseProfileBasicInformation {
  /**
   * 文章作者的user id (62进制)
   */
  authorId?: string

  nickname?: string
}
