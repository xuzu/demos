import { RouteData } from '@/utils/routes'

export interface PermissionState {
  token: string
  dynamicRoutes: RouteData[]
  expired: boolean
}
