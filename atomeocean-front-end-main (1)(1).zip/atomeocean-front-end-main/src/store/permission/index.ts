import { defineStore } from 'pinia'
import userApi from '@/api/user'
import { DynamicRouteResponse } from '@/api/user/model'
import { arrayToRoutes, RouteData } from '@/utils/routes'
import { PermissionState } from '@/store/permission/types'

/**
 * 保存用户权限信息
 * 和权限路由表
 */
export const usePermissionStore = defineStore('permission', {
  state: (): PermissionState => {
    return {
      token: '',
      // 动态路由表数组
      dynamicRoutes: [] as RouteData[],
      expired: false,
    }
  },
  persist: true,
  getters: {
    getToken: (state: PermissionState) => state.token,
    getExpired: (state: PermissionState) => state.expired,
  },
  actions: {
    setToken(info: string) {
      this.token = info ?? ''
    },

    setExpired(expired: boolean) {
      this.expired = expired
    },

    /**
     * 返回符合权限的路由
     * 先扫本地缓存，如果为空，调用后端api获取动态路由表
     * 并保存到本地
     */
    async generateDynamicRoutes() {
      if (Array.isArray(this.dynamicRoutes) && this.dynamicRoutes.length > 0) {
        return this.dynamicRoutes
      }

      // 本地缓存为空，从后端获取动态路由
      const dynamicRoutesResponse = await userApi.fetchDynamicRoutes()
      this.setDynamicRoutes(dynamicRoutesResponse)
      return this.dynamicRoutes
    },

    // 缓存动态路由表
    setDynamicRoutes(dynamicRouteResponses: DynamicRouteResponse[]) {
      this.dynamicRoutes = arrayToRoutes(dynamicRouteResponses)
    },
  },
})
