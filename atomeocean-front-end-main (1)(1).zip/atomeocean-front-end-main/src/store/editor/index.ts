import { defineStore } from 'pinia'
import editorApi from '@/api/editor'
import { EditorState } from '@/store/editor/types'
import { ArticleData } from '@/store/article/types'
import { ResourceOperationType } from '@/api/ResourceOperationType'
import to from 'await-to-js'
import { ElMessage } from 'element-plus'
import { isEmpty } from '@/utils/general'
import { getCollapsedContent } from '@/utils/article'

/**
 * 保存编辑信息
 * 编辑文章时保存文章的内容
 */
export const useEditorStore = defineStore('editor', {
  state: (): EditorState => ({
    editorData: {
      // 默认情况下是Post请求
      operationType: ResourceOperationType.Post,
      articleCoverImageLink: '', //封面
      isBottom: false, // 是否到达底部
      wordCount: 0, // 编辑器字数
      content: '', // 编辑器中的正文内容
      title: '', // 页面标题
      collapsedContent: '', // 摘要
      label: '', // 标签
      addTagArray: [], //所有标签
      hotTagArray: [
        // 热门标签
        { title: '简历', type: 'isHot' },
        { title: '其他', type: 'isHot' },
      ],
      categoryName: '', // 分类列表value
      visibilityId: 1, // 可见性设置value
    },
  }),

  persist: {
    storage: window.localStorage,
  },
  getters: {},
  actions: {
    // 重置editor中对应的文章id
    refreshArticleId(articleId: string | undefined) {
      this.$reset()
      this.editorData.articleId = articleId
    },
    // 编辑文章时用ArticleData来初始化Editor
    loadFromArticle(articleData: ArticleData): void {
      this.$reset()
      this.$patch({
        editorData: {
          articleId: articleData.articleId,
          title: articleData.title,
          contentId: articleData.contentId,
          content: articleData.content,
          categoryName: articleData.categoryName,
          visibilityId: 1,
          articleCoverImageLink: articleData.articleCoverImageLink,
          collapsedContent: articleData.collapsedContent,
          addTagArray: articleData.articleTagList,
          operationType: ResourceOperationType.Patch,
        },
      })
    },

    // 上传文章前做前端检查
    validateArticleBeforeUpload(): boolean {
      if (isEmpty(this.editorData.title) || isEmpty(this.editorData.content)) {
        ElMessage({
          type: 'warning',
          message: '文章内容不全，请核对后再发布',
        })
        return false
      }
      if ((this.editorData.wordCount ?? 0) < 20) {
        ElMessage({
          type: 'warning',
          message: '正文内容最少不能少于20字',
        })
        return false
      }
      return true
    },

    // 上传或更新文章
    async uploadNewArticle() {
      // 前端检查是否具备所有必需的内容
      if (!this.validateArticleBeforeUpload()) {
        return
      }

      // 文章摘要部分如果summary为空，则选取文章前100个字
      if (isEmpty(this.editorData.summary)) {
        this.editorData.collapsedContent = getCollapsedContent(
          this.editorData.content,
        )
      } else {
        this.editorData.collapsedContent = this.editorData.summary
      }

      // 上传文章数据到后端
      const [error, uploadArticleResponse] = await to(
        editorApi.uploadArticle(this.editorData),
      )

      // 拦截上传失败的情况
      if (error) {
        ElMessage.error(error.message)
        return
      }
      // 文章上传成功弹出提示消息
      else if (uploadArticleResponse) {
        setTimeout(() => {
          ElMessage({
            message: '文章发布成功',
            type: 'success',
          })
        }, 1000)
      }
      // 发布成功后清空editor
      this.$reset()
      return uploadArticleResponse
    },
  },
})
