import { BaseArticleContent, ArticleTag } from '@/store/article/types'
import { ResourceOperationType } from '@/api/ResourceOperationType'

export interface EditorState {
  editorData: EditorData
}

/**
 * Editor View中绑定的数据类型
 */
export interface EditorData extends BaseArticleContent {
  operationType: ResourceOperationType
  //文章的封面
  articleCoverImageLink?: string
  // 编辑器输入的摘要
  summary?: string
  //add tag
  addTagArray?: Array<ArticleTag>
  //hot tag
  hotTagArray?: Array<ArticleTag>

  // 编辑器中填写tag的输入内容
  label?: string
  // bottom 表示editor显示文章设置部分
  isBottom?: boolean
}
