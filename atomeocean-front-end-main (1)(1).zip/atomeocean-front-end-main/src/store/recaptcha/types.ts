export interface RecaptchaState {
  recaptchaToken?: string | undefined
}
