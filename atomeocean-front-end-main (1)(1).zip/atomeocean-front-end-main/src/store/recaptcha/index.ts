import { defineStore } from 'pinia'
import { RecaptchaState } from '@/store/recaptcha/types'

export const useRecaptchaStore = defineStore('recaptcha', {
  state: (): RecaptchaState => {
    return {
      recaptchaToken: '',
    }
  },
  getters: {
    getRecaptchaToken: (recaptchaState: RecaptchaState) =>
      recaptchaState.recaptchaToken,
  },
  actions: {
    setRecaptchaToken(token: string | undefined) {
      this.recaptchaToken = token
    },
    clearRecaptchaToken() {
      this.recaptchaToken = ''
    },
  },
})
