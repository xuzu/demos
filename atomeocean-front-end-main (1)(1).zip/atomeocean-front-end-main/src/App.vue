<!-- 主页面 -->
<template>
  <div v-if="isCustomPage" class="app-container-div">
    <NotFoundView :isCustomPage="isCustomPage" />
  </div>
  <div v-else-if="isErrorPage" class="app-container-div">
    <ErrorPageView :isErrorPage="isErrorPage" />
  </div>
  <div v-else class="app-container-div">
    <el-row justify="center">
      <el-col>
        <div class="app-div">
          <el-container>
            <el-header>
              <NavigationBar />
            </el-header>
            <el-main class="display-flex-column-center">
              <router-view />
            </el-main>
          </el-container>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script lang="ts" setup>
import NavigationBar from '@/components/NavigationBar.vue'
import NotFoundView from '@/views/NotFoundView.vue'
import ErrorPageView from '@/views/ErrorPageView.vue'

import { ref, watchEffect } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()
const isCustomPage = ref(false)
const isErrorPage = ref(false)
watchEffect(() => {
  isCustomPage.value = route.meta.isCustomPage || false
  isErrorPage.value = route.meta.isErrorPage || false
})
</script>

<style lang="scss" scoped>
.app-container-div {
  :deep(.el-header) {
    padding: 0;
  }
}

.app-div {
  height: 100%;
  top: 0;
  left: 0;
}

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

.el-container {
  width: 100%;
  min-height: 100%;
  background-color: #fafafa;

  .el-main {
    height: 100%;
    padding: 0;
  }

  .el-aside {
    width: 200px;

    // 在移动端修改宽度
    @media screen and (max-width: 900px) {
      display: block;
    }
  }
}

nav a.router-link-exact-active {
  color: #42b983;
}
</style>
