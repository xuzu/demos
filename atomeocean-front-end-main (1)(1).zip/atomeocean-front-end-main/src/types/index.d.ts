// 作为javascript类型的补足，存放自定义的类
