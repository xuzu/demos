const plugins = 'lists image media table wordcount save preview'
const toolbar =
  'undo redo | h2 h1 | bold italic underline strikethrough forecolor |  bullist numlist outdent indent |  blockquote image media table removeformat'

/**
 * 默认的初始化tinymce editor配置
 */
export const init = {
  height: 400,
  language_url: './tinymce/langs/zh-Hans.js', // 语言包的路径
  language: 'zh-Hans',

  skin_url: './tinymce/skins/ui/oxide',
  plugins: plugins, // 插件配置
  toolbar: toolbar,

  menubar: false, // 隐藏顶部菜单栏
  branding: false, // 隐藏右下角
  elementpath: false, // 隐藏左下角元素路径
  content_style:
    'blockquote { margin-inline-start: 0;margin-inline-end: 0;padding-left: 40px;padding-right: 40px;border-left: 4px solid #333;}',
}

export const editorApiKey = process.env.VUE_APP_TINYMCE_API_KEY || ''
