import { createAxiosByInterceptors } from '@/utils/http'
import {
  AuthenticationResponse,
  DynamicRouteResponse,
  LoginRequestParams,
  RegisterRequestParams,
  ResetPasswordParams,
  StripePaymentParam,
} from '@/api/user/model'
import { ApiResponseType } from '@/api/ApiResponseType'

/**
 * user相关api
 */

// axios instance
const instance = createAxiosByInterceptors({
  baseURL: process.env.VUE_APP_ROOT_API,
})

enum URL {
  login = '/auth/emailLogin',
  emailRegister = '/signup/email/register',
  logout = '/auth/logout',
  permission = '/auth/permission', // 获取权限路由表
  verify = '/signup/email/verify',
  resendCode = '/auth/resendCode',
  // 重置密码相关2个URL
  emailVerify = 'resetPassword/verifyEmail', // 检查用户输入的邮箱是否满足重置密码的要求
  codeVerify = 'resetPassword/verifyCode', // 检查输入的验证码是否正确，如果正确则修改用户密码
  sendPayment = '/stripe/pay',
}

/**
 * Login Api
 * 返回结果类型为 AuthenticationResponse
 */
const login = async (
  params: LoginRequestParams,
): Promise<AuthenticationResponse> => {
  const loginResponse: ApiResponseType<AuthenticationResponse> =
    await instance.post(URL.login, params)
  return loginResponse.data
}
/**
 * Verification Api
 */
const verify = async (params: URLSearchParams): Promise<ApiResponseType> => {
  return await instance.post(URL.verify, params)
}

/**
 * Register Api
 */
const register = async (
  params: RegisterRequestParams,
): Promise<ApiResponseType> => {
  return await instance.post(URL.emailRegister, params)
}

/**
 * Resend code api
 */
const resendVerificationCode = async (
  params: URLSearchParams,
): Promise<ApiResponseType> => {
  return await instance.post(URL.resendCode, params)
}

/**
 * Logout Api
 */
const logout = async () => {
  return await instance.post(URL.logout)
}

/**
 * 调用动态路由表api，返回 DynamicRoutesResponse数组
 */
const fetchDynamicRoutes = async (): Promise<DynamicRouteResponse[]> => {
  return await instance.post(URL.permission)
}

/**
 * 重置密码的2个steps
 */
/**
 * Step 1: 检查用户输入的邮箱是否满足重置密码的要求
 */
const emailVerify = async (
  params: ResetPasswordParams,
): Promise<ApiResponseType> => {
  return await instance.post(URL.emailVerify, params)
}

/**
 * Step 2: 检查输入的验证码是否正确，如果正确则修改用户密码
 */
const codeVerify = async (
  params: URLSearchParams,
): Promise<ApiResponseType> => {
  return await instance.post(URL.codeVerify, params)
}

/**
 * Stripe Api
 */
const sendPayment = async (
  params: StripePaymentParam,
): Promise<ApiResponseType> => {
  return await instance.post(URL.sendPayment, params)
}

export default {
  login,
  verify,
  register,
  resendVerificationCode,
  logout,
  fetchDynamicRoutes,
  emailVerify,
  codeVerify,
  sendPayment,
}
