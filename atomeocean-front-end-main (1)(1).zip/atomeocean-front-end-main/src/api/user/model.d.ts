/**
 * 登录 request model
 */
export interface LoginRequestParams {
  userEmail: string
  password: string
}

/**
 * 注册请求中的参数
 */
export interface RegisterRequestParams {
  userEmail: string
  password: string
}

/**
 * 验证请求中的参数
 */
export interface VerifyRequestParams {
  email: string
  code: string
}

/**
 * 登录请求返回结果
 */
export interface AuthenticationResponse {
  userId: string
  authenticationCode: string
  token: string
}

/**
 * 重置密码中：记录邮箱和新密码
 */
export interface ResetPasswordParams {
  userEmail: string
  password: string
}

/**
 * 后端返回的动态路由表数据结构
 */
export interface DynamicRouteResponse {
  dynamicRouteId: string
  path: string
  name: string
  component: string
  parentRouteId: string
}

export interface StripePaymentParam {
  amount: number
  stripeToken: string
}
