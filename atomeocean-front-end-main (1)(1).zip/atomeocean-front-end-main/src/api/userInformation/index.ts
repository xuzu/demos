import { UserInformationResponse } from "@/store/userInformation/types"
import { createAxiosByInterceptors } from "@/utils/http"
import { buildUrl } from "@/utils/url"
import {ModifyProfileParams, PostCareerExperienceParams, PostEducationExperienceParams, RequestUserInformationParams} from "./model"
import { ApiResponseType } from "@/api/ApiResponseType"

/**
 * userInformation相关api
 */

// axios instance
const instance = createAxiosByInterceptors({
    baseURL: process.env.VUE_APP_ROOT_API,
})

enum URL {
    profileEndpoint = '/profile/info',
    modifyProfileEndpoint = '/profile/update',
    modifyVisibilityEndPoint = '/profile/visibility/update',
    modifyCareerExperienceEndpoint = '/career',
    modifyEducationExperienceEndpoint = '/education',
}

/**
 * Todo: 完成读取用户信息的方法
 * 根据用户名获取该用户的user Id
 */
const getUserInformation = async (params: RequestUserInformationParams): Promise<ApiResponseType<UserInformationResponse>> => {
    const getUserInformationUrl = buildUrl(URL.profileEndpoint, params)
    return await instance.get(getUserInformationUrl);
}

/**
 * 更新用户名
 */
const modifyUserInformation = async (params: ModifyProfileParams) => {
    const modifyUserInformationResponse = await instance.post(
        URL.modifyProfileEndpoint,
        params
    )

    return modifyUserInformationResponse;
}

/**
 * 更新用户信息可见性
 */
const modifyVisibility = async (params: URLSearchParams) => {
    return await instance.post(URL.modifyVisibilityEndPoint, params);
}


/**
 * 更新用户职业经历
 */
const modifyCareerExperience = async (params: PostCareerExperienceParams) => {
    return await instance.post(URL.modifyCareerExperienceEndpoint, params);
}

/**
 * 更新用户学业经历
 */
const modifyEducationExperience = async (params: PostEducationExperienceParams) => {
    return await instance.post(URL.modifyEducationExperienceEndpoint, params);
}

export default {
    getUserInformation,
    modifyUserInformation,
    modifyVisibility,
    modifyCareerExperience,
    modifyEducationExperience
}