/**
 * 根据用户名请求用户其他信息
 */
export interface RequestUserInformationParams {
    encodedUserId?: string
}

/**
 * 更新用户信息时的参数
 */
export interface ModifyProfileParams {
    fieldsModified?: string[],
    nickname?: string,
    motto?: string,
    selfIntroduction?: string
}

/** operationType 表示这个请求是上传新的经历
* 还是更新，或是删除经历
*/
export interface PostCareerExperienceParams {
   operationType?: ResourceOperationType
   careerId?: string
   companyName?: string 
   position?: string
   startDate?: string
   endDate?: string 
   isCompleted?: boolean 
}

/** operationType 表示这个请求是上传新的经历
* 还是更新，或是删除经历
*/
export interface PostEducationExperienceParams {
    operationType?: ResourceOperationType
    educationId?: string
    institutionName?: string 
    degreeLevel?: string
    major?: string
    startDate?: string
    endDate?: string 
    isCompleted?: boolean 
}