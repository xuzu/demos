// axios instance
import {createAxiosByInterceptors} from "@/utils/http";
import {ArticleResponse} from "@/store/article/types";
import {ApiResponseType} from "@/api/ApiResponseType";
import {EditorData} from "@/store/editor/types";

const instance = createAxiosByInterceptors({
    baseURL: process.env.VUE_APP_ROOT_API,
})

const editorEndPoint = '/editor'

/**
 * 在编辑器中上传单篇文章
 * @param params 上传请求中的参数
 */
const uploadArticle = async (params: EditorData) => {
    const response: ApiResponseType<ArticleResponse> = await instance.post(editorEndPoint, params)
    return response.data
}

enum URL {
  updateArticleCoverImg = 'editor/coverImage/update',
}

/**
 * 发送更新文章封面请求
 */
const updateArticleCoverImg = async (
  params: FormData
): Promise<ApiResponseType> => {
  const config = {
    headers: {
      "Content-Type": "multipart/form-data",
    },
  };
  return await instance.post(URL.updateArticleCoverImg, params, config);
};

export default {
    uploadArticle,
  updateArticleCoverImg,
}
