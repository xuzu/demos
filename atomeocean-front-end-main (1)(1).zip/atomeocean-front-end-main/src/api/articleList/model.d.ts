/**
 * 获取文章列表的请求
 *
 * @param authorId: 作者的userid
 * @param limit: 每次返回的文章数量
 */
export interface RequestArticleListParams {
  authorId?: string
  paginationToken?: string
}
