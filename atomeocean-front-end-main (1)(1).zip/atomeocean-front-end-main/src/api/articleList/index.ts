import { RequestArticleListParams } from '@/api/articleList/model'
import { ApiResponseType } from '@/api/ApiResponseType'
import { ArticleListResponse } from '@/store/article/types'
import { buildUrl } from '@/utils/url'
import { createAxiosByInterceptors } from '@/utils/http'

// axios instance
const instance = createAxiosByInterceptors({
  baseURL: process.env.VUE_APP_ROOT_API,
})

const articleListEndPoint = 'articles'

/**
 * 获取文章列表
 * @param params: 文章列表请求参数
 */
const getArticleList = async (
  params: RequestArticleListParams,
): Promise<ApiResponseType<ArticleListResponse>> => {
  const getArticleListUrl = buildUrl(articleListEndPoint, params)

  return await instance.get(getArticleListUrl)
}

export default {
  getArticleList,
}
