/**
 * 统一封装Api返回值
 * 对应后端返回类型为ResultData
 */
export interface ApiResponseType<T = any> {
    status: number,
    message: string,
    data: T,
    timestamp: Date
}