// 提交内容
import { createAxiosByInterceptors } from '@/utils/http'
import { RequestArticleParams } from '@/api/article/model'
import { buildUrl } from '@/utils/url'
import { ArticleResponse } from '@/store/article/types'
import { ApiResponseType } from '@/api/ApiResponseType'

// axios instance
const instance = createAxiosByInterceptors({
  baseURL: process.env.VUE_APP_ROOT_API,
})

const articleEndPoint = '/article'

/**
 * 单篇文章读取
 * @param path 文章路径
 */
const getArticle = async (
  params: RequestArticleParams,
): Promise<ApiResponseType<ArticleResponse>> => {
  const getArticleUrl = buildUrl(articleEndPoint, params)
  return await instance.get(getArticleUrl)
}

export default {
  getArticle,
}
