import { ResourceOperationType } from '@/api/ResourceOperationType'

/**
 * 文章上传时请求的参数
 * 包括标题，内容等
 *
 * operationType 表示这个请求是上传新的文章
 * 还是更新，或是删除文章
 */
export interface PostArticleParams {
  operationType?: ResourceOperationType
  authorId?: string // 作者id
  authorName?: string // 作者的名字
  articleId?: string
  title?: string // 题目
  contentId?: string // 内容id
  content?: string // 内容
  categoryName?: string // 分类名称
}

/**
 * 获取文章的请求
 */
export interface RequestArticleParams {
  articleId: string
}
