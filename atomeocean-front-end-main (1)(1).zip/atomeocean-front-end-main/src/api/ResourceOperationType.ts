/**
 * 资源操作的Enum
 * 方便后端识别操作是添加、更新还是删除
 *
 * 接口统一使用Post
 */
export enum ResourceOperationType {
    Post,
    Patch,
    Delete
}