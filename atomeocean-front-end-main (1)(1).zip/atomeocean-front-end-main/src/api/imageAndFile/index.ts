import {createAxiosByInterceptors} from "@/utils/http";
import {ApiResponseType} from "@/api/ApiResponseType";

/**
 * 处理图片和文件的API请求
 */

// axios instance
const instance = createAxiosByInterceptors({
    baseURL: process.env.VUE_APP_ROOT_API,
})

enum URL {
    updateAvatar = '/profile/avatar/update',
    updateArticleCoverImg = 'editor/coverImage/update',
}


/**
 * 发送更新头像请求
 */
const updateAvatar = async (params: FormData): Promise<ApiResponseType> => {
    const config = {
        headers: {
            'Content-Type': 'multipart/form-data'
        }
    }
    return await instance.post(URL.updateAvatar, params, config)
}

/**
 * 发送更新文章封面请求
 */
const updateArticleCoverImg = async (params: FormData): Promise<ApiResponseType> => {
  const config = {
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  }
  return await instance.post(URL.updateArticleCoverImg, params, config)
}

export default {
    updateAvatar,
  updateArticleCoverImg,
}
