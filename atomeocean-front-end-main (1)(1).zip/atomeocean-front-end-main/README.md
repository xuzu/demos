# AtomeOcean Front end

[![release information](https://img.shields.io/badge/release_version-2.0.0-blue)](https://github.com/foo-tech/foo-front-end)

Foo项目的前端，主要技术栈有以下但不限于
- vue3
- typescript
- element-plus
- pinia
- vue-router
- docker
- husky
- prettier

环境设置请参考[这个onboarding wiki](https://github.com/atomeocean/AtomeOcean-Wiki/blob/main/docs/onboarding/FrontEnd-onboarding.md)


## Project setup 
```
npm install
```

### Compiles and hot-reloads for development (部署支持热更新)
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Run your unit tests
we use 'jest' as unit test framework
```
npm run test:unit
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

[一套推荐的vue文件结构](https://lq782655835.github.io/blogs/team-standard/recommend-vue-project-structure.html)

