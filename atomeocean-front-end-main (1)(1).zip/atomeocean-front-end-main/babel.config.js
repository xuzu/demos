// only used by jest
module.exports = {presets: ['@babel/preset-env']}