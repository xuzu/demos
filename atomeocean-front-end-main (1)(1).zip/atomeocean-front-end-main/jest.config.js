module.exports = {
    moduleFileExtensions: [
        'ts',
        'tsx',
        'js',
        'jsx',
        'vue'
    ],
    preset: 'ts-jest',
    testEnvironment: 'jsdom',
    testEnvironmentOptions: {
        customExportConditions: ["node", "node-addons"],
    },
    transform: {
        '^.+\\.vue$': '<rootDir>/node_modules/@vue/vue3-jest',
        // 'babel-jest'处理js文件
        '^.+\\.js$': '<rootDir>/node_modules/babel-jest',
        '^.+\\.ts$': '<rootDir>/node_modules/ts-jest',
    },
    moduleNameMapper: {
        '^@/(.*)$': '<rootDir>/src/$1'
    },
    snapshotSerializers: [
        'jest-serializer-vue'
    ],
    testMatch: ["**/__tests__/**/*.[jt]s?(x)", "**/?(*.)+(spec|test).[tj]s?(x)"],
    transformIgnorePatterns: ['<rootDir>/node_modules/']
}